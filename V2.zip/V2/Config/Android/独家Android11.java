 
import os

def create_sav_file(file_path, game_data):
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        encrypted_data = bytes([byte ^ 0xFF for byte in game_data.encode()])
        
        with open(file_path, 'wb') as file:
            file.write(encrypted_data)
        
        print("SAV文件已成功创建并加密写入内容。")
    except Exception as e:
        print(f"创建SAV文件时发生错误: {e}")

if __name__ == "__main__":
    sav_file_path = "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav"
    game_data = "和平精英数据\n安卓11\n增强效果\n更多详细信息...\n"
    create_sav_file(sav_file_path, game_data)
