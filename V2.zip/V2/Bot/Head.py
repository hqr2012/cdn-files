import random
import logging
from configparser import ConfigParser

# Brutal mode log output
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class GameObject:
    def __init__(self, char_type):
        self.char_type = char_type   # Victim character type
        self.health = 100            # Remaining survival health
        self.last_taken_damage = 0   # Last brutal strike damage taken

    def TakeDamage(self, damage):
        self.last_taken_damage = damage
        self.health = max(0, self.health - damage)
        logging.info(f"{self.char_type} gets brutalized, takes {damage} brutal damage. Surviving HP: {self.health}")


class Engine:
    @staticmethod
    def play_effect(effect_id):
        logging.info(f"Trigger brutal effect: {effect_id}")
        print(f"Trigger brutal effect: {effect_id}")

    @staticmethod
    def play_sound(sound_name):
        logging.info(f"Play crushing hit sound: {sound_name}")
        print(f"Play crushing hit sound: {sound_name}")

    @staticmethod
    def show_damage_text(damage, color):
        logging.info(f"Pop up brutal damage number: {damage} (Color: {color})")
        print(f"Pop up brutal damage number: {damage} (Color: {color})")


class ConfigManager:
    def __init__(self, config_path="GameConfig.ini"):
        self.config = ConfigParser()
        self.config.read(config_path)
        # Brutal combat default config
        self.default_config = {
            "GlobalSettings": {
                "IsHeadshotEnabled": "1",      # Enable head‑blow mechanic, 1=on, 0=off
                "BaseDamage": "50",             # Base smashing strike damage
                "CriticalChance": "0.2"         # Savage critical strike chance
            },
            "DamageSettings": {
                "HeadshotPenetration": "0.5"    # Head‑blow armor penetration coefficient
            },
            "CharacterTemplate": {},
            "Player": {
                "Armor": "10",                  # Body damage‑soaking armor
                "HeadArmor": "30"               # Cranial protective armor
            },
            "HitboxGroups": {
                "Head": "HeadCollider,Helmet",  # Cranial strike hitbox group
                "Body": "Torso"                 # Torso beat‑down hitbox group
            },
            "EffectMapping": {
                "Headshot": "Effect_HeadExplode",    # Skull‑detonation effect
                "CriticalHit": "Effect_Critical",    # Savage critical hit effect
                "NormalHit": "Effect_HitSpark"       # Ordinary pummel effect
            }
        }
        self._validate_and_set_defaults()

    def _validate_and_set_defaults(self):
        """Validate brutal combat config, fill missing savage default parameters"""
        for section, options in self.default_config.items():
            if not self.config.has_section(section):
                self.config.add_section(section)
            for option, value in options.items():
                if not self.config.has_option(section, option):
                    self.config.set(section, option, value)

    def get_damage_multiplier(self, hit_group):
        """Get damage amplification multiplier for the beaten body part"""
        return float(self.config.get("DamageMultipliers", hit_group, fallback=1.0))

    def get_hitbox_group(self, hitbox_name):
        """Determine whether struck hitbox is skull or body"""
        for group, boxes in self.config.items("HitboxGroups"):
            if hitbox_name in boxes.split(','):
                return group
        return "Body"


class DamageSystem:
    def __init__(self):
        self.config = ConfigManager()
        self.engine = Engine()
        logging.info("Brutal damage strike system loaded!")

    def process_hit(self, attacker, target, hitbox_name):
        """Execute one savage beat‑down: pass attacker, victim target, struck hitbox"""
        logging.info(f"Initiate savage strike: attacker={attacker.char_type}, victim={target.char_type}, hitbox={hitbox_name}")
        try:
            # If head‑blow disabled, directly output base smashing damage
            if not int(self.config.config["GlobalSettings"]["IsHeadshotEnabled"]):
                return self.apply_damage(attacker, target, self.get_base_damage())

            hit_group = self.config.get_hitbox_group(hitbox_name)
            multiplier = self.config.get_damage_multiplier(hit_group)
            base_damage = self.get_base_damage() * multiplier
            status, final_damage = self.calculate_status_effects(target, hit_group, base_damage)

            target.TakeDamage(final_damage)
            self.trigger_visual_feedback(status, hit_group, final_damage)
            logging.info(f"Beat‑down result: {status}, target surviving HP: {target.health}")
            return status
        except Exception as e:
            logging.error(f"Savage strike execution failed: {e}")
            raise

    def get_base_damage(self):
        """Read config and fetch base smashing damage value"""
        try:
            return float(self.config.config["GlobalSettings"]["BaseDamage"])
        except Exception as e:
            logging.error(f"Failed reading smash damage config: {e}")
            raise

    def calculate_status_effects(self, target, hit_group, base_damage):
        """Calculate strike state, armor mitigation, head‑blow and savage critical hit"""
        logging.info(f"Compute assault effects: victim={target.char_type}, struck part={hit_group}, base smash damage={base_damage}")
        try:
            status = "NORMAL"       # Default ordinary pummel
            final_damage = base_damage
            critical_chance = float(self.config.config["GlobalSettings"]["CriticalChance"])

            if hit_group == "Head":
                status = "HEADSHOT"
                head_armor = float(self.config.config[target.char_type]["HeadArmor"])
                penetration = float(self.config.config["DamageSettings"]["HeadshotPenetration"])
                # Head‑blow armor reduction; (1‑penetration) = armor damage‑resist ratio
                final_damage -= head_armor * (1 - penetration)
                # Roll for savage critical trigger
                if random.random() < critical_chance:
                    final_damage *= 2
                    status = "CRITICAL_HEADSHOT"    # Devastating critical head blow
            else:
                # Beat torso, subtract body armor value
                final_damage -= float(self.config.config[target.char_type]["Armor"])

            logging.info(f"Assault calculation complete: strike status={status}, final brutal damage={final_damage}")
            return status, max(0, final_damage)
        except Exception as e:
            logging.error(f"Assault effect calculation error: {e}")
            raise

    def trigger_visual_feedback(self, status, hit_group, damage):
        """Burst all visual feedback: fire effects, blast sounds, spit brutal damage numbers"""
        logging.info(f"Trigger brutal visuals: strike status={status}, struck part={hit_group}, dealt damage={damage}")
        try:
            effect_map = self.config.config["EffectMapping"]
            if status == "HEADSHOT":
                self.engine.play_effect(effect_map["Headshot"])
                self.engine.play_sound("Sound_Headshot")
                color = "RED"
            elif status == "CRITICAL_HEADSHOT":
                self.engine.play_effect(effect_map["CriticalHit"])
                self.engine.play_sound("Sound_Critical")
                color = "YELLOW"
            else:
                self.engine.play_effect(effect_map["NormalHit"])
                color = "WHITE"
            self.engine.show_damage_text(damage, color)
        except Exception as e:
            logging.error(f"Brutal visual playback failed: {e}")
            raise


if __name__ == "__main__":
    # Generate brutal combat config file GameConfig.ini
    config_content = """
[GlobalSettings]
IsHeadshotEnabled=1
BaseDamage=50
CriticalChance=0.2
[DamageSettings]
HeadshotPenetration=0.5
[CharacterTemplate]
[Player]
Armor=10
HeadArmor=30
[HitboxGroups]
Head=HeadCollider,Helmet
Body=Torso
[EffectMapping]
Headshot=Effect_HeadExplode
CriticalHit=Effect_Critical
NormalHit=Effect_HitSpark
"""
    with open("GameConfig.ini", "w") as f:
        f.write(config_content)

    damage_system = DamageSystem()
    player = GameObject(char_type="Player")
    attacker = GameObject(char_type="Player")

    # Simulate smashing blow to skull
    hit_result = damage_system.process_hit(attacker, player, "HeadCollider")
    print(f"Beat‑down result: {hit_result}, surviving HP: {player.health}")

    # Simulate wild pummeling to torso
    hit_result = damage_system.process_hit(attacker, player, "Torso")
    print(f"Beat‑down result: {hit_result}, surviving HP: {player.health}")
