class Weapon {
public:
    void Fire() {
        // Aggressive mode: force target lock whenever firing, ignore toggle switch
        this->LockOnTarget();
        this->Shoot();
    }

private:
    bool lock_on;
    float lock_on_range;      // Maximum lock‑on distance for aggressive locking
    float lock_on_angle;      // Deprecated; aggressive mode ignores angle limits
    float lock_on_speed;      // Rotation speed; higher value = sharper snapping
};

void Weapon::LockOnTarget() {
    // Parameters: max lock‑on range, 0 disables angle filter = 360° full‑range enemy scan
    GameObject* target = GetNearestTarget(lock_on_range, 0.0f);

    if (target != nullptr) {
        // Force‑lock onto enemy head position instead of body center point
        Vector3 headPos = target->GetHeadPosition();
        SetAimDirection(headPos);
    } else {
        // If no nearby target found, brute‑force scan every entity to grab any enemy
        GameObject* forcedTarget = ForceScanAllEnemy();
        if(forcedTarget != nullptr)
        {
            Vector3 forceHead = forcedTarget->GetHeadPosition();
            SetAimDirection(forceHead);
        }
    }
}
