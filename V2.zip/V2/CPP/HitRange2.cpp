// GameConfig.h - 游戏配置文件解析头文件
#pragma once
#include <string>
#include <unordered_map>
#include <fstream>
#include <sstream>

class GameConfig {
private:
    std::unordered_map<std::string, std::unordered_map<std::string, std::string>> configData;
    
    void trim(std::string& str) {
        str.erase(0, str.find_first_not_of(" \t\r\n"));
        str.erase(str.find_last_not_of(" \t\r\n") + 1);
    }
    
    std::string convertBool(const std::string& value) {
        if (value == "true" || value == "开启" || value == "1") return "1";
        if (value == "false" || value == "关闭" || value == "0") return "0";
        return value;
    }

public:
    bool loadConfig(const std::string& filepath) {
        std::ifstream file(filepath);
        if (!file.is_open()) return false;
        
        std::string currentSection = "";
        std::string line;
        
        while (std::getline(file, line)) {
            trim(line);
            
            if (line.empty() || line[0] == ';' || line[0] == '#') {
                continue; // 跳过注释和空行
            }
            
            if (line[0] == '[' && line.back() == ']') {
                // 解析节标题
                currentSection = line.substr(1, line.length() - 2);
                configData[currentSection] = {};
            } else if (!currentSection.empty()) {
                // 解析键值对
                size_t pos = line.find('=');
                if (pos != std::string::npos) {
                    std::string key = line.substr(0, pos);
                    std::string value = line.substr(pos + 1);
                    trim(key);
                    trim(value);
                    
                    // 转换布尔值
                    if (key.find("启用") != std::string::npos || 
                        key.find("Enable") != std::string::npos) {
                        value = convertBool(value);
                    }
                    
                    configData[currentSection][key] = value;
                }
            }
        }
        
        file.close();
        return true;
    }
    
    std::string getValue(const std::string& section, const std::string& key, 
                        const std::string& defaultValue = "") {
        auto sectionIt = configData.find(section);
        if (sectionIt != configData.end()) {
            auto keyIt = sectionIt->second.find(key);
            if (keyIt != sectionIt->second.end()) {
                return keyIt->second;
            }
        }
        return defaultValue;
    }
    
    float getFloatValue(const std::string& section, const std::string& key, 
                       float defaultValue = 0.0f) {
        std::string value = getValue(section, key);
        if (!value.empty()) {
            try {
                return std::stof(value);
            } catch (...) {
                return defaultValue;
            }
        }
        return defaultValue;
    }
    
    int getIntValue(const std::string& section, const std::string& key, 
                   int defaultValue = 0) {
        std::string value = getValue(section, key);
        if (!value.empty()) {
            try {
                return std::stoi(value);
            } catch (...) {
                return defaultValue;
            }
        }
        return defaultValue;
    }
    
    bool getBoolValue(const std::string& section, const std::string& key, 
                     bool defaultValue = false) {
        std::string value = getValue(section, key);
        if (!value.empty()) {
            return (value == "1" || value == "true" || value == "开启");
        }
        return defaultValue;
    }
    
    // 获取命中框配置结构
    struct HitboxConfig {
        bool enabled = false;
        float globalScale = 1.0f;
        float headScale = 1.0f;
        float torsoScale = 1.0f;
        float armScale = 1.0f;
        float legScale = 1.0f;
        float footScale = 1.0f;
        float shoulderScale = 1.0f;
    };
    
    HitboxConfig getHitboxConfig() {
        HitboxConfig config;
        std::string section = "人物命中框缩放";
        
        config.enabled = getBoolValue(section, "启用命中框扩展");
        config.globalScale = getFloatValue(section, "全局缩放比例", 1.0f);
        config.headScale = getFloatValue(section, "头部缩放比例", 1.0f);
        config.torsoScale = getFloatValue(section, "躯干缩放比例", 1.0f);
        config.armScale = getFloatValue(section, "手臂缩放比例", 1.0f);
        config.legScale = getFloatValue(section, "腿部缩放比例", 1.0f);
        config.footScale = getFloatValue(section, "足部缩放比例", 1.0f);
        config.shoulderScale = getFloatValue(section, "肩部缩放比例", 1.0f);
        
        return config;
    }
    
    // 获取武器配置结构
    struct WeaponConfig {
        float assaultRifle = 1.0f;
        float sniperRifle = 1.0f;
        float shotgun = 1.0f;
        float submachineGun = 1.0f;
        float lightMachineGun = 1.0f;
        float pistol = 1.0f;
    };
    
    WeaponConfig getWeaponConfig() {
        WeaponConfig config;
        std::string section = "武器命中框缩放";
        
        config.assaultRifle = getFloatValue(section, "突击步枪缩放倍率", 1.0f);
        config.sniperRifle = getFloatValue(section, "狙击枪缩放倍率", 1.0f);
        config.shotgun = getFloatValue(section, "散弹枪缩放倍率", 1.0f);
        config.submachineGun = getFloatValue(section, "冲锋枪缩放倍率", 1.0f);
        config.lightMachineGun = getFloatValue(section, "轻机枪缩放倍率", 1.0f);
        config.pistol = getFloatValue(section, "手枪缩放倍率", 1.0f);
        
        return config;
    }
    
    // 获取骨骼配置结构
    struct BoneConfig {
        bool enabled = false;
        float globalScale = 1.0f;
        float headScale = 1.0f;
        float torsoScale = 1.0f;
        float footScale = 1.0f;
    };
    
    BoneConfig getBoneConfig() {
        BoneConfig config;
        std::string section = "人物骨骼扩展";
        
        config.enabled = getBoolValue(section, "启用骨骼扩展");
        config.globalScale = getFloatValue(section, "骨骼全局扩展倍率", 1.0f);
        config.headScale = getFloatValue(section, "头部骨骼扩展倍率", 1.0f);
        config.torsoScale = getFloatValue(section, "躯干骨骼扩展倍率", 1.0f);
        config.footScale = getFloatValue(section, "足部骨骼扩展倍率", 1.0f);
        
        return config;
    }
    
    // 获取移动补偿配置结构
    struct MovementConfig {
        float closeRange = 1.0f;
        float longRange = 1.0f;
        float jumping = 1.0f;
        float crouching = 1.0f;
        float prone = 1.0f;
        float sliding = 1.0f;
        float vaulting = 1.0f;
    };
    
    MovementConfig getMovementConfig() {
        MovementConfig config;
        std::string section = "移动目标命中补偿";
        
        config.closeRange = getFloatValue(section, "近距离目标命中加成", 1.0f);
        config.longRange = getFloatValue(section, "远距离目标命中加成", 1.0f);
        config.jumping = getFloatValue(section, "跳跃目标命中加成", 1.0f);
        config.crouching = getFloatValue(section, "下蹲目标命中加成", 1.0f);
        config.prone = getFloatValue(section, "匍匐目标命中加成", 1.0f);
        config.sliding = getFloatValue(section, "滑铲目标命中加成", 1.0f);
        config.vaulti