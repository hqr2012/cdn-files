#ifndef _PLAYER_HITBOX_CONFIG_H_
#define _PLAYER_HITBOX_CONFIG_H_

struct Vector3 {
    float x, y, z; // 用于表示3D空间中的坐标和尺寸
};

struct HitBox {
    Vector3 center;      // 命中框中心点相对于角色原点的偏移
    Vector3 extent;      // 命中框的半尺寸（缩放程度）
    float radius;        // 如果是球形或胶囊体碰撞框，此项有效
    int boneIndex;       // 关联的骨骼索引（如头部、胸部、四肢）
    int hitBoxType;      // 命中框类型：0=头部, 1=身体, 2=四肢
    float scaleFactor;   // 缩放系数（理论上放大命中框的关键参数）
};

class PlayerHitBoxConfig {
private:
    int playerID;
    HitBox hitBoxes[6];  // 假设一个角色有6个主要命中框（头、胸、腹、左右臂、左右腿）

public:
    // 构造函数：初始化默认命中框参数
    PlayerHitBoxConfig() : playerID(0) {
        // 头部命中框 (默认)
        hitBoxes[0] = { {0.0f, 0.35f, 0.0f}, {0.12f, 0.15f, 0.1f}, 0.15f, 6, 0, 1.0f };
        // 胸部命中框
        hitBoxes[1] = { {0.0f, 0.15f, 0.0f}, {0.18f, 0.2f, 0.12f}, 0.0f, 4, 1, 1.0f };
        // 腹部命中框
        hitBoxes[2] = { {0.0f, 0.0f, 0.0f}, {0.16f, 0.15f, 0.1f}, 0.0f, 3, 1, 1.0f };
        // 左臂、右臂、左腿、右腿...
        hitBoxes[3] = { {-0.22f, 0.15f, 0.0f}, {0.08f, 0.15f, 0.08f}, 0.08f, 12, 2, 1.0f };
        hitBoxes[4] = { {0.22f, 0.15f, 0.0f}, {0.08f, 0.15f, 0.08f}, 0.08f, 33, 2, 1.0f };
        hitBoxes[5] = { {-0.08f, -0.4f, 0.0f}, {0.07f, 0.25f, 0.07f}, 0.07f, 51, 2, 1.0f };
    }

    // 理论上的命中框缩放函数 (此函数在真实游戏中无法生效)
    void ScaleHitBox(int index, float scale) {
        if (index >= 0 && index < 6) {
            hitBoxes[index].extent.x *= scale;
            hitBoxes[index].extent.y *= scale;
            hitBoxes[index].extent.z *= scale;
            hitBoxes[index].radius *= scale;
            hitBoxes[index].scaleFactor = scale; // 更新缩放系数
        }
    }

    // 获取命中框信息 (用于调试或显示)
    HitBox GetHitBox(int index) const {
        if (index >= 0 && index < 6) {
            return hitBoxes[index];
        }
        return HitBox();
    }

    // 序列化配置（理论上用于保存/加载配置）
    void SerializeToFile(const char* filename) const;
    void DeserializeFromFile(const char* filename);
};

#endif // _PLAYER_HITBOX_CONFIG_H_
