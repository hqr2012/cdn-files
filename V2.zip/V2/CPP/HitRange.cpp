#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <stdexcept>
#include <algorithm>
#include <cctype>

class GameConfigManager {
private:
    // 使用嵌套map存储配置数据：外层key为section，内层存储key-value对
    std::map<std::string, std::map<std::string, std::string>> configData;

    // 辅助函数：去除字符串首尾空白字符
    static std::string trim(const std::string& str) {
        size_t start = str.find_first_not_of(" \t");
        if (start == std::string::npos) return "";
        size_t end = str.find_last_not_of(" \t");
        return str.substr(start, end - start + 1);
    }

    // 辅助函数：将字符串转换为小写（用于大小写不敏感的配置项）
    static std::string toLower(const std::string& str) {
        std::string result = str;
        std::transform(result.begin(), result.end(), result.begin(), 
                      [](unsigned char c) { return std::tolower(c); });
        return result;
    }

public:
    GameConfigManager() {
        // 初始化默认配置（基于用户提供的配置）
        initializeDefaultConfig();
    }

    // 初始化默认配置
    void initializeDefaultConfig() {
        // Section: 人物命中框
        configData["人物命中框"]["人物命中框缩放"] = "启用";
        configData["人物命中框"]["人物命中框半径"] = "0.5";
        configData["人物命中框"]["人物命中框缩放"] = "0.9"; // 覆盖前一个值
        configData["人物命中框"]["人物动态命中框"] = "启用";
        configData["人物命中框"]["人物动态命中框缩放"] = "1.2";
        configData["人物命中框"]["人物静态命中框"] = "启用";

        // Section: 子弹渲染
        configData["子弹渲染"]["子弹渲染"] = "启用";
        configData["子弹渲染"]["渲染子弹碰撞箱面积"] = "\"MAX\""; // 保留引号
        configData["子弹渲染"]["渲染子弹命中框面积"] = "\"MAX\"";

        // Section: 碰撞箱
        configData["碰撞箱"]["人物碰撞箱缩放"] = "启用";
        configData["碰撞箱"]["人物碰撞箱半径"] = "480";
        configData["碰撞箱"]["子弹碰撞箱"] = "启用";
        configData["碰撞箱"]["子弹碰撞箱缩放"] = "1.3";
    }

    // 从文件加载配置
    bool loadFromFile(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "错误: 无法打开配置文件 " << filename << std::endl;
            return false;
        }

        configData.clear();
        std::string currentSection;
        std::string line;

        while (std::getline(file, line)) {
            line = trim(line);
            
            // 跳过空行和注释
            if (line.empty() || line[0] == ';' || line[0] == '#') {
                continue;
            }

            // 检查是否是section
            if (line[0] == '[' && line.back() == ']') {
                currentSection = trim(line.substr(1, line.length() - 2));
                configData[currentSection]; // 确保section存在
            }
            // 解析key=value对
            else if (currentSection != "") {
                size_t delimiterPos = line.find('=');
                if (delimiterPos != std::string::npos) {
                    std::string key = trim(line.substr(0, delimiterPos));
                    std::string value = trim(line.substr(delimiterPos + 1));
                    
                    // 处理值中的引号（保持原样）
                    if (!value.empty() && value.front() == '"' && value.back() == '"') {
                        value = "\"" + trim(value.substr(1, value.length() - 2)) + "\"";
                    }
                    
                    configData[currentSection][key] = value;
                }
            }
        }

        file.close();
        return true;
    }

    // 保存配置到文件
    bool saveToFile(const std::string& filename) const {
        std::ofstream file(filename, std::ios::out | std::ios::trunc);
        if (!file.is_open()) {
            std::cerr << "错误: 无法创建配置文件 " << filename << std::endl;
            return false;
        }

        for (const auto& [section, keyValues] : configData) {
            file << "[" << section << "]" << std::endl;
            
            for (const auto& [key, value] : keyValues) {
                file << key << "=" << value << std::endl;
            }
            
            file << std::endl; // section之间空行
        }

        file.close();
        return true;
    }

    // 获取配置值（字符串类型）
    std::string getString(const std::string& section, const std::string& key, 
                         const std::string& defaultValue = "") const {
        auto sectionIt = configData.find(section);
        if (sectionIt == configData.end()) {
            return defaultValue;
        }

        auto keyIt = sectionIt->second.find(key);
        if (keyIt == sectionIt->second.end()) {
            return defaultValue;
        }

        return keyIt->second;
    }

    // 获取配置值（整数类型）
    int getInt(const std::string& section, const std::string& key, int defaultValue = 0) const {
        std::string value = getString(section, key);
        if (value.empty()) return defaultValue;

        try {
            // 处理可能存在的引号
            if (value.front() == '"' && value.back() == '"') {
                value = value.substr(1, value.length() - 2);
            }
            return std::stoi(value);
        }
        catch (const std::exception& e) {
            std::cerr << "警告: 配置项 " << section << "." << key 
                      << " 转换为整数失败，使用默认值 " << defaultValue << std::endl;
            return defaultValue;
        }
    }

    // 获取配置值（浮点数类型）
    double getDouble(const std::string& section, const std::string& key, double defaultValue = 0.0) const {
        std::string value = getString(section, key);
        if (value.empty()) return defaultValue;

        try {
            if (value.front() == '"' && value.back() == '"') {
                value = value.substr(1, value.length() - 2);
            }
            return std::stod(value);
        }
        catch (const std::exception& e) {
            std::cerr << "警告: 配置项 " << section << "." << key 
                      << " 转换为浮点数失败，使用默认值 " << defaultValue << std::endl;
            return defaultValue;
        }
    }

    // 获取配置值（布尔类型）
    bool getBool(const std::string& section, const std::string& key, bool defaultValue = false) const {
        std::string value = toLower(getString(section, key));
        
        if (value.empty()) return defaultValue;
        
        // 处理可能存在的引号
        if (value.front() == '"' && value.back() == '"') {
            value = value.substr(1, value.length() - 2);
        }

        if (value == "启用" || value == "true" || value == "1" || value == "yes") {
            return true;
        }
        else if (value == "禁用" || value == "false" || value == "0" || value == "no") {
            return false;
        }

        return defaultValue;
    }

    // 设置配置值
    void setValue(const std::string& section, const std::string& key, const std::string& value) {
        configData[section][key] = value;
    }

    // 设置整数配置值
    void setInt(const std::string& section, const std::string& key, int value) {
        configData[section][key] = std::to_string(value);
    }

    // 设置浮点数配置值
    void setDouble(const std::string& section, const std::string& key, double value) {
        configData[section][key] = std::to_string(value);
    }

    // 设置布尔配置值
    void setBool(const std::string& sec