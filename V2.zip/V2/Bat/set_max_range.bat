@echo off
setlocal enabledelayedexpansion
:: 显示所有枪械已设置为超远射程
echo 所有武器射程已设置为最大：999999 米
echo.
for /f "tokens=*" %%a in (weapon_config.txt) do (
    echo %%a
)
echo.
echo 设置完成！
pause
