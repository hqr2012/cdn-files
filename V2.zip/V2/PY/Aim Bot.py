import time
import random
import ctypes
import win32api
import win32con
import win32gui

class PUBGMAimbot:
    def __init__(self):
        self.game_window = "com,tencent,tmgp.pubgmhd"
        self.running = False
        self.aim_settings = {
            'speed': 11,
            'max_distance': 1000,
            'trigger_chance': 100,
            'target': 'Bot',
            'condition': 'OnFire'
        }
        self.weapons = {
            'M416': {'fov': '360°×360°', 'self_aim': True},
            'M762': {'fov': '360°×360°', 'self_aim': True},
            'AKM': {'fov': '360°×360°', 'self_aim': True},
            # Add other weapons similarly
        }
        
    def find_game_window(self):
        try:
            hwnd = win32gui.FindWindow(None, self.game_window)
            return hwnd
        except Exception as e:
            print(f"Error finding game window: {e}")
            return None
    
    def enable_aim_assist(self):
        print("Aim assist enabled with settings:")
        print(f"Speed: {self.aim_settings['speed']}ms")
        print(f"Max Distance: {self.aim_settings['max_distance']}m")
        print(f"Trigger Chance: {self.aim_settings['trigger_chance']}%")
        print(f"Target: {self.aim_settings['target']}")
        print(f"Condition: {self.aim_settings['condition']}")
        
    def simulate_aim(self, weapon):
        if weapon in self.weapons:
            print(f"Activating self-aim for {weapon} with FOV {self.weapons[weapon]['fov']}")
            print("Target locked: head")
            print("Bullet trajectory adjusted")
            print("Recoil compensation activated")
        else:
            print("Weapon not recognized")
    
    def start(self):
        hwnd = self.find_game_window()
        if hwnd:
            print("Game window found. Starting aimbot...")
            self.running = True
            self.enable_aim_assist()
            
            while self.running:
                try:
                    # Simulate checking for firing condition
                    if random.randint(1, 100) <= self.aim_settings['trigger_chance']:
                        current_weapon = random.choice(list(self.weapons.keys()))
                        self.simulate_aim(current_weapon)
                    
                    time.sleep(0.1)  # Reduce CPU usage
                    
                except KeyboardInterrupt:
                    self.running = False
                    print("Stopping aimbot...")
        else:
            print("Game window not found. Make sure PUBG Mobile is running.")

    def stop(self):
        self.running = False
        print("Aimbot stopped")

if __name__ == "__main__":
    aimbot = PUBGMAimbot()
    try:
        aimbot.start()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        aimbot.stop()