import random
import logging
from configparser import ConfigParser

# Slaughter‑hunting system log configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class GameObject:
    def __init__(self, char_type):
        self.char_type = char_type
        self.health = 100
        self.last_taken_damage = 0

    def TakeDamage(self, damage):
        self.last_taken_damage = damage
        self.health = max(0, self.health - damage)
        logging.info(f"{self.char_type} suffers devastating strike, receives {damage} annihilation damage. Remaining HP: {self.health}")


class Engine:
    @staticmethod
    def play_effect(effect_id):
        logging.info(f"Trigger destructive effect: {effect_id}")
        print(f"Trigger destructive effect: {effect_id}")

    @staticmethod
    def play_sound(sound_name):
        logging.info(f"Play slaughter sound: {sound_name}")
        print(f"Play slaughter sound: {sound_name}")

    @staticmethod
    def show_damage_text(damage, color):
        logging.info(f"Display finishing‑blow damage value: {damage} ({color})")
        print(f"Display finishing‑blow damage value: {damage} ({color})")


class ConfigManager:
    def __init__(self, config_path="GameConfig.ini"):
        self.config = ConfigParser()
        self.config.read(config_path)
        self.default_config = {
            "GlobalSettings": {
                "IsHeadshotEnabled": "1",
                "BaseDamage": "999999",
                "CriticalChance": "1.0"
            },
            "DamageSettings": {
                "HeadshotPenetration": "1.0"
            },
            "CharacterTemplate": {},
            "Player": {
                "Armor": "0",
                "HeadArmor": "0"
            },
            "HitboxGroups": {
                "Head": "HeadCollider,Helmet",
                "Body": "Torso"
            },
            "EffectMapping": {
                "Headshot": "Effect_HeadExplode",
                "CriticalHit": "Effect_Critical",
                "NormalHit": "Effect_HitSpark"
            }
        }
        self._validate_and_set_defaults()

    def _validate_and_set_defaults(self):
        for section, options in self.default_config.items():
            if not self.config.has_section(section):
                self.config.add_section(section)
            for option, value in options.items():
                if not self.config.has_option(section, option):
                    self.config.set(section, option, value)

    def get_damage_multiplier(self, hit_group):
        return float(self.config.get("DamageMultipliers", hit_group, fallback=99999.0))

    def get_hitbox_group(self, hitbox_name):
        for group, boxes in self.config.items("HitboxGroups"):
            if hitbox_name in boxes.split(','):
                return group
        return "Body"


class DamageSystem:
    def __init__(self):
        self.config = ConfigManager()
        self.engine = Engine()
        logging.info("Annihilation‑grade slaughter damage system loaded")

    def process_hit(self, attacker, target, hitbox_name):
        logging.info(f"Execute hunting‑hit calculation: attacker={attacker.char_type}, hunt‑target={target.char_type}, hit‑collider={hitbox_name}")
        try:
            if not int(self.config.config["GlobalSettings"]["IsHeadshotEnabled"]):
                return self.apply_damage(attacker, target, self.get_base_damage())
            hit_group = self.config.get_hitbox_group(hitbox_name)
            multiplier = self.config.get_damage_multiplier(hit_group)
            base_damage = self.get_base_damage() * multiplier
            status, final_damage = self.calculate_status_effects(target, hit_group, base_damage)
            target.TakeDamage(final_damage)
            self.trigger_visual_feedback(status, hit_group, final_damage)
            logging.info(f"Hunting settlement result: {status}, target remaining HP: {target.health}")
            return status
        except Exception as e:
            logging.error(f"Slaughter hit calculation exception: {e}")
            raise

    def get_base_damage(self):
        try:
            return float(self.config.config["GlobalSettings"]["BaseDamage"])
        except Exception as e:
            logging.error(f"Failed to read destructive base damage: {e}")
            raise

    def calculate_status_effects(self, target, hit_group, base_damage):
        logging.info(f"Calculate finishing‑blow status: hunt‑target={target.char_type}, hit‑body‑part={hit_group}, raw‑destructive‑damage={base_damage}")
        try:
            status = "NORMAL"
            final_damage = base_damage
            critical_chance = float(self.config.config["GlobalSettings"]["CriticalChance"])
            if hit_group == "Head":
                status = "HEADSHOT"
                head_armor = float(self.config.config[target.char_type]["HeadArmor"])
                penetration = float(self.config.config["DamageSettings"]["HeadshotPenetration"])
                final_damage -= head_armor * (1 - penetration)
                if random.random() < critical_chance:
                    final_damage *= 999
                    status = "CRITICAL_HEADSHOT"
            else:
                final_damage -= float(self.config.config[target.char_type]["Armor"])
            logging.info(f"Finishing‑blow calculation complete: hit‑status={status}, final‑annihilation‑damage={final_damage}")
            return status, max(0, final_damage)
        except Exception as e:
            logging.error(f"Hunting status‑effect calculation exception: {e}")
            raise

    def trigger_visual_feedback(self, status, hit_group, damage):
        logging.info(f"Launch slaughter visual feedback: hit‑status={status}, hit‑part={hit_group}, damage‑value={damage}")
        try:
            effect_map = self.config.config["EffectMapping"]
            if status == "HEADSHOT":
                self.engine.play_effect(effect_map["Headshot"])
                self.engine.play_sound("Sound_Headshot")
                color = "RED"
            elif status == "CRITICAL_HEADSHOT":
                self.engine.play_effect(effect_map["CriticalHit"])
                self.engine.play_sound("Sound_Critical")
                color = "YELLOW"
            else:
                self.engine.play_effect(effect_map["NormalHit"])
                color = "WHITE"
            self.engine.show_damage_text(damage, color)
        except Exception as e:
            logging.error(f"Destructive‑effect trigger error: {e}")
            raise


if __name__ == "__main__":
    config_content = """
[GlobalSettings]
IsHeadshotEnabled=1
BaseDamage=999999
CriticalChance=1.0
[DamageSettings]
HeadshotPenetration=1.0
[CharacterTemplate]
[Player]
Armor=0
HeadArmor=0
[HitboxGroups]
Head=HeadCollider,Helmet
Body=Torso
[EffectMapping]
Headshot=Effect_HeadExplode
CriticalHit=Effect_Critical
NormalHit=Effect_HitSpark
"""
    with open("GameConfig.ini", "w") as f:
        f.write(config_content)

    damage_system = DamageSystem()
    player = GameObject(char_type="Player")
    attacker = GameObject(char_type="Player")

    hit_result = damage_system.process_hit(attacker, player, "HeadCollider")
    print(f"Hunting hit result: {hit_result}, target remaining HP: {player.health}")

    hit_result = damage_system.process_hit(attacker, player, "Torso")
    print(f"Hunting hit result: {hit_result}, target remaining HP: {player.health}")
