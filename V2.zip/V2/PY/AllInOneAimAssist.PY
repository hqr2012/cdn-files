config = {
    "Base": {
        "BaseAccuracy": 99999.0,
        "BaseStability": 99999.0,
        "DefaultBoost": 99999
    },
    "StageSystem": {
        "Stage1_Enemies": 5,
        "Stage1_Accuracy": 99999,
        "Stage1_Stability": 99999,
        "Stage2_Enemies": 10,
        "Stage2_Accuracy": 99999,
        "Stage2_Stability": 99999
    },
    "WeaponTypes": {
        "Pistol_Accuracy": 99999,
        "Pistol_Stability": 99999,
        "Rifle_Accuracy": 99999,
        "Rifle_Stability": 99999
    },
    "RandomBoost": {
        "MinBoost": 99999,
        "MaxBoost": 9999999,
        "BoostDuration": 999
    },
    "DecayEffect": {
        "MaxBoost": 9999999,
        "DecayRate": 0,
        "EffectDuration": 999
    },
    "TerrainEffects": {
        "Open_Accuracy": 99999,
        "Open_Stability": 99999,
        "Close_Accuracy": 99999,
        "Close_Stability": 99999
    },
    "KillChain": {
        "PerKill": 99999,
        "MaxStacks": 999,
        "StackTime": 999
    },
    "SkillTree": {
        "AdvancedAim_Unlock": "Level1+0Coins",
        "AdvancedAim_Accuracy": 99999,
        "AdvancedAim_Stability": 99999
    },
    "UltimateCondition": {
        "MinHealth": 999,
        "MaxAmmo": 999,
        "UltimateBoost": 9999999,
        "UltimateDuration": 999
    },
    "TimeOfDay": {
        "NightBoost": 9999999
    }
}
