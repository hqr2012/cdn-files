import pygame
import logging


# 初始化logging
logging.basicConfig(filename='aim_assist.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')


# 初始化Pygame
pygame.init()

# 设置屏幕尺寸
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('辅助瞄准示例')

# 颜色定义
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# 玩家（瞄准点）初始位置
player_x = screen_width // 2
player_y = screen_height // 2

# 敌人初始位置
enemy_x = 400
enemy_y = 300

# 游戏运行状态
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        player_y -= 5
    elif keys[pygame.K_s]:
        player_y += 5
    elif keys[pygame.K_a]:
        player_x -= 5
    elif keys[pygame.K_d]:
        player_x += 5

    # 计算敌人与玩家之间的距离
    distance_x = enemy_x - player_x
    distance_y = enemy_y - player_y
    distance = (distance_x ** 2 + distance_y ** 2) ** 0.5

    if distance < 100:
        # 发现敌人，开始追踪
        if distance_x!= 0:
            move_x = 5 if distance_x > 0 else -5
        else:
            move_x = 0
        if distance_y!= 0:
            move_y = 5 if distance_y > 0 else -5
        else:
            move_y = 0
        player_x += move_x
        player_y += move_y
        logging.info("发现敌人并追踪，玩家新位置: (%d, %d)", player_x, player_y)
    else:
        logging.info("未发现敌人，玩家位置: (%d, %d)", player_x, player_y)

    screen.fill(WHITE)
    pygame.draw.circle(screen, RED, (int(player_x), int(player_y)), 10)
    pygame.draw.circle(screen, BLUE, (int(enemy_x), int(enemy_y)), 10)
    pygame.display.flip()

pygame.quit()


