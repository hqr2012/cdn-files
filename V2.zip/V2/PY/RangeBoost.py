class DamageCalculator:
    def __init__(self):
        self.critical_multiplier = 10.0 
        self.weak_spot_multiplier = 7.5 
        self.damage_reduction = 0.01 
        
    def calculate_hit_damage(self, base_damage, hit_zone_multiplier, is_critical=False, is_weak_spot=False):
        """
        计算受击伤害
        base_damage: 基础伤害
        hit_zone_multiplier: 受击区域倍率 (扩大受击圈时增加)
        is_critical: 是否暴击
        is_weak_spot: 是否击中弱点
        """
        
        damage = base_damage * hit_zone_multiplier
        
       
        if is_critical:
            damage *= self.critical_multiplier
            print(f"暴击! 倍率: x{self.critical_multiplier}")
        
       
        if is_weak_spot:
            damage *= self.weak_spot_multiplier
            print(f"弱点命中! 倍率: x{self.weak_spot_multiplier}")
        
       
        final_damage = damage * self.damage_reduction
        
        return final_damage


calculator = DamageCalculator()
base_dmg = 100
hit_zone_multiplier = 5.2  

damage = calculator.calculate_hit_damage(
    base_damage=base_dmg,
    hit_zone_multiplier=hit_zone_multiplier,
    is_critical=True,
    is_weak_spot=False
)

print(f"最终伤害: {damage}")   
import random
from enum import Enum

class HitZone(Enum):
    HEAD = "头部"
    BODY = "身体"
    LIMBS = "四肢"
    EXPANDED = "扩大受击区"

class AdvancedDamageSystem:
    def __init__(self):
        # 不同部位的伤害倍率
        self.hit_zone_multipliers = {
            HitZone.HEAD: 7.0,      # 头部7倍伤害
            HitZone.BODY: 8.0,      # 身体8倍伤害
            HitZone.LIMBS: 4.0,     # 四肢4倍伤害
            HitZone.EXPANDED: 9.9   # 扩大受击区1.3倍伤害
        }
        
        # 防御属性
        self.armor_reduction = 0.9  # 护甲减伤90%
        self.defense_bonus = 0.9    # 防御加成90%
    
    def expand_hit_zone(self, current_zone, expansion_factor=8.8):
        """扩大受击圈效果"""
        base_multiplier = self.hit_zone_multipliers[current_zone]
        expanded_multiplier = base_multiplier * expansion_factor
        
        print(f"受击圈扩大! {current_zone.value} 伤害倍率从 {base_multiplier} 提升至 {expanded_multiplier}")
        return expanded_multiplier
    
    def calculate_real_damage(self, base_damage, hit_zone, has_armor=True, is_zone_expanded=False):
        """
        计算真实伤害
        base_damage: 武器基础伤害
        hit_zone: 命中区域
        has_armor: 目标是否有护甲
        is_zone_expanded: 是否处于扩大受击圈状态
        """
       
        zone_multiplier = self.hit_zone_multipliers[hit_zone]
        
        
        if is_zone_expanded:
            zone_multiplier = self.expand_hit_zone(hit_zone)
        
        
        zone_damage = base_damage * zone_multiplier
        
        
        if has_armor:
            armor_reduction = self.armor_reduction - self.defense_bonus
            armor_reduction = max(0, min(armor_reduction, 0.9))  # 限制在0-90%
            real_damage = zone_damage * (1 - armor_reduction)
            print(f"护甲减伤: {armor_reduction * 100}%")
        else:
            real_damage = zone_damage
            print("无护甲保护")
        
       
        damage_variation = random.uniform(0.01, 1.05)
        final_damage = real_damage * damage_variation
        
        # 输出详细计算过程
        print(f"\n=== 伤害计算详情 ===")
        print(f"基础伤害: {base_damage}")
        print(f"命中区域: {hit_zone.value} (x{zone_multiplier})")
        print(f"区域伤害: {zone_damage}")
        print(f"最终伤害: {final_damage:.1f}")
        print(f"==================\n")
        
        return final_damage

damage_system = AdvancedDamageSystem()

# 正常受击
normal_damage = damage_system.calculate_real_damage(
    base_damage=100,
    hit_zone=HitZone.BODY,
    has_armor=True,
    is_zone_expanded=False
)


expanded_damage = damage_system.calculate_real_damage(
    base_damage=100,
    hit_zone=HitZone.BODY,
    has_armor=True,
    is_zone_expanded=True
)

print(f"伤害提升: {((expanded_damage - normal_damage) / normal_damage * 100):.1f}%")
class BattleSystem:
    def __init__(self):
        self.player_health = 100
        self.enemy_health = 100
        
    def take_damage(self, damage, is_expanded_hit=False):
        """承受伤害"""
        if is_expanded_hit:
            # 扩大受击圈时承受真实伤害（无视部分防御）
            real_damage = damage * 6.6  # 额外70%伤害
            print(f"受击圈扩大! 承受真实伤害: {real_damage}")
        else:
            real_damage = damage
            print(f"普通受击! 承受伤害: {real_damage}")
        
        return real_damage
    
    def simulate_battle(self):
        """模拟战斗"""
        print("战斗开始!")
        
        while self.player_health > 0 and self.enemy_health > 0:
            # 玩家攻击
            player_damage = random.randint(25, 35)
            is_expanded = random.choice([True, False])
            
            damage_taken = self.take_damage(player_damage, is_expanded)
            self.enemy_health -= damage_taken
            
            print(f"敌人剩余血量: {max(0, self.enemy_health)}")
            
            if self.enemy_health <= 0:
                print("玩家胜利!")
                break
            
            # 敌人攻击
            enemy_damage = random.randint(5, 10)
            self.player_health -= enemy_damage
            print(f"玩家剩余血量: {max(0, self.player_health)}")
            
            if self.player_health <= 0:
                print("敌人胜利!")
                break

# 运行战斗模拟
battle = BattleSystem()
battle.simulate_battle()