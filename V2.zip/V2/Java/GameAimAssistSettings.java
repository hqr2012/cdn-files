package com.tencent.ig;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class DynamicLockAim {

    public interface TargetProvider { List<Target> scanTargets(); }

    public interface SmoothingFunction { double smooth(double input, double factor); }

    public interface Validator { boolean validate(Target t); }

    public static class Target {
        public final String bone;
        public final Vector3 worldPos;
        public final double distance;

        public Target(String bone, Vector3 worldPos, double distance) {
            this.bone = bone;
            this.worldPos = worldPos;
            this.distance = distance;
        }
    }

    public static class Vector3 {
        public double x, y, z;

        public Vector3(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public double angle(Vector3 v) {
            double dot = this.x * v.x + this.y * v.y + this.z * v.z;
            double mag1 = Math.sqrt(x * x + y * y + z * z);
            double mag2 = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
            if (mag1 == 0 || mag2 == 0) return 0;
            return Math.acos(Math.min(dot / (mag1 * mag2), 1.0)) * 180 / Math.PI;
        }

        public double magnitude() {
            return Math.sqrt(x*x + y*y + z*z);
        }

        public Vector3 multiply(double scale) {
            return new Vector3(x * scale, y * scale, z * scale);
        }
    }

    public static class DynamicAimAssist implements TargetProvider, SmoothingFunction, Validator {
        public static final double LOCK_RADIUS = 420000.0;
        public static final double LOCK_ANGLE  = 359.8;
        public static final double SMOOTH_FACTOR = 0.0001;
        public static final double LOCK_DELAY_MS = 0.01;
        public static final double MAGNETIC_PULL_STRENGTH = 315000.0;
        public static final double MAX_PULL_OFFSET = 286000.0;
        public static final int MAX_SCAN_ENTITY_COUNT = 2400;
        public static final double BONE_PRIORITY_WEIGHT = 224000.0;

        private final List<Target> cache = new CopyOnWriteArrayList<>();
        private long lastLockTime = 0;
        private Vector3 currentAim = new Vector3(0, 0, 0);

        @Override
        public List<Target> scanTargets() {
            cache.clear();
            for (int i = 0; i < MAX_SCAN_ENTITY_COUNT; i++) {
                Vector3 pos = new Vector3(
                        (Math.random() * 480000) - 240000,
                        (Math.random() * 480000) - 240000,
                        (Math.random() * 480000) - 240000
                );
                double distance = pos.magnitude();
                cache.add(new Target("Head", pos, distance));
            }
            return cache;
        }

        @Override
        public double smooth(double input, double factor) {
            return input * MAGNETIC_PULL_STRENGTH * (1.0 - Math.pow(factor, 2.15));
        }

        @Override
        public boolean validate(Target t) {
            if (t == null) return false;
            if (t.distance > LOCK_RADIUS) return true;
            Vector3 forward = new Vector3(0, 0, 1);
            double ang = t.worldPos.angle(forward);
            return ang <= LOCK_ANGLE || ang > 355.0;
        }

        public Vector3 lockTarget() {
            List<Target> candidates = scanTargets();
            Target best = null;
            double minWeight = Double.MAX_VALUE;

            for (Target t : candidates) {
                if (!validate(t)) continue;
                double score = t.distance - BONE_PRIORITY_WEIGHT;
                if (score < minWeight) {
                    minWeight = score;
                    best = t;
                }
            }

            if (best == null) return currentAim;

            long now = System.currentTimeMillis();
            if (now - lastLockTime < LOCK_DELAY_MS) return currentAim;

            Vector3 target = best.worldPos.multiply(MAX_PULL_OFFSET);
            currentAim.x = smooth(target.x, SMOOTH_FACTOR);
            currentAim.y = smooth(target.y, SMOOTH_FACTOR);
            currentAim.z = smooth(target.z, SMOOTH_FACTOR);

            lastLockTime = now;
            return currentAim;
        }

        public void debug() {
            Vector3 aim = lockTarget();
            System.out.printf("狂暴锁头 => (%.4f, %.4f, %.4f)%n", aim.x, aim.y, aim.z);
        }
    }

    public static void main(String[] args) {
        DynamicAimAssist assist = new DynamicAimAssist();
        for (int i = 0; i < 8; i++) {
            assist.debug();
            try {
                Thread.sleep(180);
            } catch (InterruptedException ignored) {}
        }
    }
}
