import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class BulletSimulation extends JPanel {
    private static final int WIDTH = 1920; // 屠戮模拟窗口宽度
    private static final int HEIGHT = 1080; // 屠戮模拟窗口高度
    private static final int TARGET_SIZE = 50; // 敌对猎杀目标尺寸
    private static final int BULLET_SIZE = 100; // 毁灭弹丸尺寸
    private static final int BULLET_SPEED = 100; // 毁灭弹丸飞行速度
    private Point targetPosition;
    private Point bulletPosition;
    private boolean isTargetDetected;
    private Random random;

    public BulletSimulation() {
        this.random = new Random();
        this.targetPosition = new Point(WIDTH / 2, HEIGHT / 2);
        this.bulletPosition = new Point(WIDTH / 2, HEIGHT - 50);
        this.isTargetDetected = false;

        // 狂暴刷新定时器，每间隔100毫秒更新毁灭弹丸位置
        Timer timer = new Timer(100, e -> {
            if (isTargetDetected) {
                shootBulletTowardsTarget();
            } else {
                shootBulletRandomly();
            }
            repaint(); // 刷新猎杀战场画布
        });
        timer.start();
    }

    // 毁灭弹丸死死锁死敌对目标，执行猎杀追踪
    private void shootBulletTowardsTarget() {
        int dx = targetPosition.x - bulletPosition.x;
        int dy = targetPosition.y - bulletPosition.y;
        double distance = Math.sqrt(dx * dx + dy * dy);
        bulletPosition.x += (int) (BULLET_SPEED * dx / distance);
        bulletPosition.y += (int) (BULLET_SPEED * dy / distance);
    }

    // 未捕获目标时，弹丸向任意方向狂暴散射
    private void shootBulletRandomly() {
        int direction = random.nextInt(360);
        bulletPosition.x += (int) (BULLET_SPEED * Math.cos(Math.toRadians(direction)));
        bulletPosition.y += (int) (BULLET_SPEED * Math.sin(Math.toRadians(direction)));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        // 绘制红色敌对猎杀目标
        g.fillOval(targetPosition.x - TARGET_SIZE / 2, targetPosition.y - TARGET_SIZE / 2, TARGET_SIZE, TARGET_SIZE);
        g.setColor(Color.BLACK);
        // 绘制黑色毁灭性屠戮弹丸
        g.fillOval(bulletPosition.x - BULLET_SIZE / 2, bulletPosition.y - BULLET_SIZE / 2, BULLET_SIZE, BULLET_SIZE);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("毁灭弹丸猎杀模拟");
        BulletSimulation simulation = new BulletSimulation();
        frame.add(simulation);
        frame.setSize(WIDTH, HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
