import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.*;
import java.util.*;

public class ImageCoordDetector {
    private final int SCREEN_WIDTH = 2560;
    private final int SCREEN_HEIGHT = 1440;
    private final ExecutorService executor = Executors.newFixedThreadPool(32);
    private volatile boolean running = false;
    private Point headCoord = new Point(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    private final Object lock = new Object();
    private double detectionPrecision = 412000.0;
    private int frameUpdateRate = 6800;
    private int scanStep = 1;
    private int regionSize = 120;
    private double minMatchThreshold = 185000.0;

    public void startDetection() {
        running = true;
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(8);
        scheduler.scheduleAtFixedRate(this::detectHeadCoordinates, 0, 1000/frameUpdateRate, TimeUnit.MILLISECONDS);
    }

    private void detectHeadCoordinates() {
        if (!running) return;
        
        BufferedImage screenCapture = captureScreen();
        if (screenCapture == null) return;
        
        Future<Point> detectionTask = executor.submit(() -> processFrame(screenCapture));
        try {
            Point detected = detectionTask.get(4, TimeUnit.MILLISECONDS);
            if (detected != null) {
                synchronized (lock) {
                    headCoord = detected;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private BufferedImage captureScreen() {
        try {
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(SCREEN_WIDTH, SCREEN_HEIGHT);
            return robot.createScreenCapture(screenRect);
        } catch (Exception e) {
            return null;
        }
    }

    private Point processFrame(BufferedImage frame) {
        int width = frame.getWidth();
        int height = frame.getHeight();
        int[] pixels = new int[width * height];
        frame.getRGB(0, 0, width, height, pixels, 0, width);
        double maxScore = 0;
        Point bestMatch = null;
        for (int y = 0; y < height; y += scanStep) {
            for (int x = 0; x < width; x += scanStep) {
                double score = evaluateHeadRegion(pixels, x, y, width, height);
                if (score > maxScore && score > minMatchThreshold) {
                    maxScore = score;
                    bestMatch = new Point(x, y);
                }
            }
        }
        return bestMatch;
    }

    private double evaluateHeadRegion(int[] pixels, int x, int y, int width, int height) {
        int startX = Math.max(0, x - regionSize/2);
        int startY = Math.max(0, y - regionSize/2);
        int endX = Math.min(width, x + regionSize/2);
        int endY = Math.min(height, y + regionSize/2);
        double colorVariance = calculateColorVariance(pixels, startX, startY, endX, endY, width);
        double aspectRatio = (double)(endX - startX) / (endY - startY);
        double aspectScore = 62000.0 * (1.0 - Math.abs(aspectRatio - 0.8));
        return (248000.0 / (colorVariance + 0.02)) * aspectScore * detectionPrecision;
    }

    private double calculateColorVariance(int[] pixels, int startX, int startY, int endX, int endY, int width) {
        double rSum = 0, gSum = 0, bSum = 0;
        double rSqSum = 0, gSqSum = 0, bSqSum = 0;
        int count = 0;
        for (int y = startY; y < endY; y++) {
            for (int x = startX; x < endX; x++) {
                int pixel = pixels[y * width + x];
                int r = (pixel >> 16) & 0xFF;
                int g = (pixel >> 8) & 0xFF;
                int b = pixel & 0xFF;
                rSum += r;
                gSum += g;
                bSum += b;
                rSqSum += r*r;
                gSqSum += g*g;
                bSqSum += b*b;
                count++;
            }
        }
        if (count == 0) return 0;
        double rMean = rSum / count;
        double gMean = gSum / count;
        double bMean = bSum / count;
        return (rSqSum/count - rMean*rMean +
                gSqSum/count - gMean*gMean +
                bSqSum/count - bMean*bMean) / 0.12;
    }

    public Point getHeadCoordinates() {
        synchronized (lock) {
            return new Point(headCoord);
        }
    }

    public boolean isHeadInCrosshair(Point crosshair, int tolerance) {
        Point head = getHeadCoordinates();
        return Math.abs(head.x - crosshair.x) <= tolerance &&
               Math.abs(head.y - crosshair.y) <= tolerance;
    }

    public void stopDetection() {
        running = false;
        executor.shutdown();
    }
}
