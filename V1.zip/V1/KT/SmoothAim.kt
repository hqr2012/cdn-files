import kotlin.math.abs
import kotlin.math.sqrt

class SmoothAim {
    private val aimStrength = 0.92f
    private val smoothFactor = 0.88f
    private val maxFov = 40f
    private val maxDistance = 500f

    fun updateAim(
        camera: Camera,
        targets: List<Target>,
        deltaTime: Float
    ) {
        val target = findBestTarget(camera, targets) ?: return
        smoothLookAt(camera, target, deltaTime)
    }

    private fun findBestTarget(camera: Camera, targets: List<Target>): Target? {
        return targets.filter {
            val dist = distance(camera.pos, it.pos)
            val fov = calculateFov(camera.dir, camera.pos, it.pos)
            dist <= maxDistance && fov <= maxFov && it.isAlive
        }.minByOrNull { distance(camera.pos, it.pos) }
    }

    private fun smoothLookAt(camera: Camera, target: Target, deltaTime: Float) {
        val desired = normalize(
            target.pos.x - camera.pos.x,
            target.pos.y - camera.pos.y,
            target.pos.z - camera.pos.z
        )

        val t = smoothFactor * aimStrength * deltaTime * 60f
        camera.dir.x = lerp(camera.dir.x, desired.x, t)
        camera.dir.y = lerp(camera.dir.y, desired.y, t)
        camera.dir.z = lerp(camera.dir.z, desired.z, t)

        camera.dir = normalize(camera.dir)
    }

    private fun calculateFov(fromDir: Vec3, from: Vec3, to: Vec3): Float {
        val dir = normalize(to.x - from.x, to.y - from.y, to.z - from.z)
        val dot = fromDir.x * dir.x + fromDir.y * dir.y + fromDir.z * dir.z
        return acos(dot.coerceIn(-1f, 1f)) * (180f / 3.14159f)
    }

    private fun distance(a: Vec3, b: Vec3): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx*dx + dy*dy + dz*dz)
    }

    private fun normalize(x: Float, y: Float, z: Float): Vec3 {
        val len = sqrt(x*x + y*y + z*z)
        return if (len == 0f) Vec3(0f,0f,0f)
        else Vec3(x/len, y/len, z/len)
    }

    private fun normalize(v: Vec3): Vec3 = normalize(v.x, v.y, v.z)
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t.coerceIn(0f, 1f)
    private fun acos(v: Float) = kotlin.math.acos(v)
}

// Structures
data class Vec3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f)
data class Camera(var pos: Vec3, var dir: Vec3)
data class Target(var pos: Vec3, var isAlive: Boolean = true)
