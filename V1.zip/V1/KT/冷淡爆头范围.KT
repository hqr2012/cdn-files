import kotlin.math.*
import kotlin.random.Random

/**
 * Enhanced Headshot Hitbox Configuration for Shooting Games
 * Designed to expand headshot detection range while maintaining natural gameplay feel
 */
data class HeadshotHitboxConfig(
    // Core hitbox expansion parameters
    val baseHeadHitboxScale: Float = 1.3f,
    val hitboxExpansionFalloff: ClosedFloatingPointRange<Float> = 0.7f..1.0f,
    val maxHitboxScale: Float = 2.0f,
    
    // Distance-based scaling
    val closeRangeHitboxBoost: Float = 1.2f,
    val longRangeHitboxReduction: Float = 0.8f,
    val closeRangeThreshold: Float = 30f,
    val longRangeThreshold: Float = 150f,
    
    // Movement-based adjustment
    val movingTargetHitboxPenalty: Float = 0.9f,
    val stationaryTargetHitboxBonus: Float = 1.1f,
    val movementThreshold: Float = 0.5f,
    
    // Weapon-specific overrides
    val sniperHitboxBonus: Float = 1.4f,
    val arHitboxBonus: Float = 1.2f,
    val shotgunHitboxBonus: Float = 1.8f,
    val smgHitboxBonus: Float = 1.1f,
    
    // Visual and gameplay feedback
    val hitboxMarkerEnabled: Boolean = true,
    val hitboxMarkerColor: String = "#FF0000",
    val hitboxMarkerSize: Float = 0.1f,
    
    // Validation and state
    val isActive: Boolean = true,
    val configVersion: String = "1.5.0"
) {
    fun validate(): Boolean {
        return baseHeadHitboxScale in 1.0f..maxHitboxScale &&
               hitboxExpansionFalloff.start in 0.0f..1.0f &&
               closeRangeThreshold < longRangeThreshold &&
               configVersion.isNotEmpty()
    }
}

class HeadshotHitboxEnhancer(
    private val config: HeadshotHitboxConfig = HeadshotHitboxConfig(),
    private val random: Random = Random(42)
) {
    private val hitboxHistory = mutableMapOf<Long, Float>()
    private val maxHistorySize = 50

    fun calculateEffectiveHitboxScale(
        target: EnemyEntity,
        distance: Float,
        weaponType: WeaponType
    ): Float {
        if (!config.isActive) return 1.0f

        var scale = config.baseHeadHitboxScale

        // Apply distance-based scaling
        scale *= when {
            distance < config.closeRangeThreshold -> config.closeRangeHitboxBoost
            distance > config.longRangeThreshold -> config.longRangeHitboxReduction
            else -> 1.0f
        }

        // Apply movement-based adjustment
        val targetSpeed = target.velocity.magnitude()
        scale *= if (targetSpeed > config.movementThreshold) {
            config.movingTargetHitboxPenalty
        } else {
            config.stationaryTargetHitboxBonus
        }

        // Apply weapon-specific bonus
        scale *= when (weaponType) {
            WeaponType.SNIPER -> config.sniperHitboxBonus
            WeaponType.ASSAULT_RIFLE -> config.arHitboxBonus
            WeaponType.SHOTGUN -> config.shotgunHitboxBonus
            WeaponType.SMG -> config.smgHitboxBonus
            else -> 1.0f
        }

        // Apply falloff based on distance
        val falloffFactor = 1f - (distance / config.longRangeThreshold).coerceIn(0f, 1f)
        scale *= config.hitboxExpansionFalloff.lerp(falloffFactor)

        return scale.coerceIn(1.0f, config.maxHitboxScale)
    }

    fun expandHeadHitbox(
        target: EnemyEntity,
        distance: Float,
        weaponType: WeaponType
    ): Hitbox {
        val effectiveScale = calculateEffectiveHitboxScale(target, distance, weaponType)
        val originalHitbox = target.headHitbox

        // Expand hitbox dimensions
        val expandedMin = Vector3(
            originalHitbox.min.x * effectiveScale,
            originalHitbox.min.y * effectiveScale,
            originalHitbox.min.z * effectiveScale
        )
        val expandedMax = Vector3(
            originalHitbox.max.x * effectiveScale,
            originalHitbox.max.y * effectiveScale,
            originalHitbox.max.z * effectiveScale
        )

        val expandedHitbox = Hitbox(expandedMin, expandedMax, target.headPosition)

        // Record hitbox scale for analytics
        recordHitboxScale(target.id, effectiveScale)

        return expandedHitbox
    }

    fun isHeadshotHit(
        target: EnemyEntity,
        bulletImpact: Vector3,
        distance: Float,
        weaponType: WeaponType
    ): Boolean {
        val expandedHitbox = expandHeadHitbox(target, distance, weaponType)
        return expandedHitbox.contains(bulletImpact)
    }

    fun getHitboxStats(): HitboxStats {
        val averageScale = if (hitboxHistory.isNotEmpty()) {
            hitboxHistory.values.average().toFloat()
        } else 1.0f

        val maxScale = hitboxHistory.values.maxOrNull() ?: 1.0f
        val minScale = hitboxHistory.values.minOrNull() ?: 1.0f

        return HitboxStats(
            averageHitboxScale = averageScale,
            maxHitboxScale = maxScale,
            minHitboxScale = minScale,
            totalHitboxRecords = hitboxHistory.size
        )
    }

    private fun recordHitboxScale(targetId: Long, scale: Float) {
        hitboxHistory[targetId] = scale
        if (hitboxHistory.size > maxHistorySize) {
            val oldestKey = hitboxHistory.keys.minOrNull()
            oldestKey?.let { hitboxHistory.remove(it) }
        }
    }

    fun clearHistory() {
        hitboxHistory.clear()
    }
}

// Supporting data classes
enum class WeaponType {
    SNIPER, ASSAULT_RIFLE, SHOTGUN, SMG, PISTOL
}

data class Hitbox(
    val min: Vector3,
    val max: Vector3,
    val center: Vector3
) {
    fun contains(point: Vector3): Boolean {
        return point.x in min.x..max.x &&
               point.y in min.y..max.y &&
               point.z in min.z..max.z
    }
}

data class HitboxStats(
    val averageHitboxScale: Float,
    val maxHitboxScale: Float,
    val minHitboxScale: Float,
    val totalHitboxRecords: Int
)

data class Vector3(var x: Float, var y: Float, var z: Float) {
    fun magnitude(): Float = sqrt(x*x + y*y + z*z)

    operator fun times(scalar: Float) = Vector3(x * scalar, y * scalar, z * scalar)
}

data class EnemyEntity(
    val id: Long,
    val headPosition: Vector3,
    val headHitbox: Hitbox,
    val velocity: Vector3,
    val isVisible: Boolean = true
)

// Extension function for range interpolation
fun ClosedFloatingPointRange<Float>.lerp(t: Float): Float {
    return start + (endInclusive - start) * t
}
