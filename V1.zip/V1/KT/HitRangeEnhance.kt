import kotlin.math.sqrt

class HitRangeEnhance {
    private val HITBOX_SCALE = 1.9f
    private val HEAD_HITBOX_SCALE = 1.9f
    private val BODY_HITBOX_SCALE = 1.9f
    private val MAX_DISTANCE = 500.0f

    fun checkHit(camera: Camera, bulletPos: Vector3, enemy: Enemy): Boolean {
        if (!enemy.isAlive) return false
        
        val dist = distance(camera.position, enemy.headPosition)
        if (dist > MAX_DISTANCE) return false

        val expandedHead = expandBox(enemy.headPosition, enemy.headSize, HEAD_HITBOX_SCALE)
        val expandedBody = expandBox(enemy.bodyPosition, enemy.bodySize, BODY_HITBOX_SCALE)

        return pointInBox(bulletPos, expandedHead) || pointInBox(bulletPos, expandedBody)
    }

    fun checkHeadshot(bulletPos: Vector3, enemy: Enemy): Boolean {
        if (!enemy.isAlive) return false
        val expandedHead = expandBox(enemy.headPosition, enemy.headSize, HEAD_HITBOX_SCALE)
        return pointInBox(bulletPos, expandedHead)
    }

    private fun expandBox(center: Vector3, size: Vector3, scale: Float): Bounds {
        val halfX = size.x * scale * 0.5f
        val halfY = size.y * scale * 0.5f
        val halfZ = size.z * scale * 0.5f
        
        return Bounds(
            min = Vector3(center.x - halfX, center.y - halfY, center.z - halfZ),
            max = Vector3(center.x + halfX, center.y + halfY, center.z + halfZ)
        )
    }

    private fun pointInBox(point: Vector3, bounds: Bounds): Boolean {
        return (point.x >= bounds.min.x && point.x <= bounds.max.x) &&
               (point.y >= bounds.min.y && point.y <= bounds.max.y) &&
               (point.z >= bounds.min.z && point.z <= bounds.max.z)
    }

    private fun distance(a: Vector3, b: Vector3): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }
}

// Data Classes
data class Vector3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f)
data class Bounds(val min: Vector3, val max: Vector3)
data class Camera(val position: Vector3)
data class Enemy(
    val isAlive: Boolean,
    val headPosition: Vector3,
    val bodyPosition: Vector3,
    val headSize: Vector3,
    val bodySize: Vector3
)
