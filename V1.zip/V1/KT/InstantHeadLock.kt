import kotlin.math.sqrt

class InstantHeadLock {
    private val maxDistance = 9999f

    fun update(camera: Camera, targets: List<Entity>) {
        val best = findBestHeadTarget(camera, targets) ?: return
        instantLockHead(camera, best)
    }

    private fun findBestHeadTarget(camera: Camera, targets: List<Entity>): Entity? {
        return targets.filter {
            it.isAlive && distance(camera.pos, it.headPos) <= maxDistance
        }.minByOrNull {
            distance(camera.pos, it.headPos)
        }
    }

    private fun instantLockHead(camera: Camera, target: Entity) {
        val dir = target.headPos.copy().apply {
            x -= camera.pos.x
            y -= camera.pos.y
            z -= camera.pos.z
        }
        val len = sqrt(dir.x*dir.x + dir.y*dir.y + dir.z*dir.z)
        if (len > 0) {
            dir.x /= len
            dir.y /= len
            dir.z /= len
        }
        camera.dir.x = dir.x
        camera.dir.y = dir.y
        camera.dir.z = dir.z
    }

    private fun distance(a: Vec3, b: Vec3): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx*dx + dy*dy + dz*dz)
    }
}

data class Vec3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    fun copy() = Vec3(x, y, z)
}

data class Camera(val pos: Vec3, val dir: Vec3)
data class Entity(val headPos: Vec3, val isAlive: Boolean = true)
