import kotlin.math.*
import kotlin.random.Random

/**
 * Enhanced Headshot Priority Configuration for Shooting Games
 * Designed to increase headshot accuracy while maintaining natural, human-like behavior
 */
data class HeadshotEnhanceParams(
    // Core targeting parameters
    val headshotPriorityMultiplier: Float = 2.5f,
    val headHitboxExpansion: Float = 1.2f,
    val headAimBias: Float = 0.85f,
    
    // Distance-based accuracy scaling
    val closeRangeThreshold: Float = 50f,
    val longRangeThreshold: Float = 200f,
    val closeRangeAccuracyBoost: Float = 1.3f,
    val longRangeAccuracyPenalty: Float = 0.7f,
    
    // Movement prediction for moving targets
    val headMovementPrediction: ClosedFloatingPointRange<Float> = 0.9f..1.5f,
    val predictionSmoothing: Float = 0.8f,
    
    // Recoil control for sustained headshots
    val headshotRecoilReduction: Float = 0.6f,
    val sustainedFireStability: Float = 0.9f,
    
    // Visual feedback and humanization
    val headshotMarkerEnabled: Boolean = true,
    val humanizationJitter: Float = 0.15f,
    val reactionTimeDelay: ClosedFloatingPointRange<Float> = 0.05f..0.15f,
    
    // Weapon-specific overrides
    val sniperHeadshotBonus: Float = 1.5f,
    val arHeadshotBonus: Float = 1.2f,
    val shotgunHeadshotBonus: Float = 2.0f,
    
    // Validation and state
    val isActive: Boolean = true,
    val configVersion: String = "2.1.0"
) {
    fun validate(): Boolean {
        return headshotPriorityMultiplier > 0f &&
               headHitboxExpansion in 1.0f..2.0f &&
               headAimBias in 0.0f..1.0f &&
               closeRangeThreshold < longRangeThreshold &&
               humanizationJitter in 0.0f..0.5f &&
               configVersion.isNotEmpty()
    }
}

class HeadshotEnhancer(
    private val params: HeadshotEnhanceParams = HeadshotEnhanceParams(),
    private val random: Random = Random(42)
) {
    private var lastHeadshotTime: Long = 0
    private var consecutiveHeadshots: Int = 0
    private val headshotHistory = mutableListOf<Long>()
    private val maxHistorySize = 10

    fun calculateTargetPriority(
        target: EnemyEntity,
        currentWeapon: WeaponType,
        distance: Float
    ): Float {
        if (!params.isActive) return 1.0f

        var priority = 1.0f
        
        // Apply headshot priority multiplier
        priority *= params.headshotPriorityMultiplier
        
        // Apply distance-based accuracy scaling
        priority *= when {
            distance < params.closeRangeThreshold -> params.closeRangeAccuracyBoost
            distance > params.longRangeThreshold -> params.longRangeAccuracyPenalty
            else -> 1.0f
        }
        
        // Apply weapon-specific headshot bonus
        priority *= when (currentWeapon) {
            WeaponType.SNIPER -> params.sniperHeadshotBonus
            WeaponType.ASSAULT_RIFLE -> params.arHeadshotBonus
            WeaponType.SHOTGUN -> params.shotgunHeadshotBonus
            else -> 1.0f
        }
        
        // Apply head aim bias
        priority *= params.headAimBias
        
        // Apply consecutive headshot bonus
        if (consecutiveHeadshots > 0) {
            priority *= (1.0f + consecutiveHeadshots * 0.1f)
        }
        
        return priority.coerceIn(0.1f, 5.0f)
    }

    fun adjustAimForHeadshot(
        currentAim: Vector3,
        target: EnemyEntity,
        deltaTime: Float,
        distance: Float
    ): Vector3 {
        if (!params.isActive) return currentAim

        var adjustedAim = currentAim
        
        // Expand head hitbox
        val expandedHeadPosition = expandHeadHitbox(target.headPosition, params.headHitboxExpansion)
        
        // Predict head movement
        val predictedHeadPosition = predictHeadMovement(
            target.headPosition,
            target.velocity,
            deltaTime,
            distance
        )
        
        // Calculate aim vector to predicted head position
        val headAimVector = Vector3.lookAt(currentAim, predictedHeadPosition)
        
        // Apply head aim bias
        adjustedAim = slerp(currentAim, headAimVector, params.headAimBias)
        
        // Add humanization jitter
        val jitter = calculateHumanizationJitter()
        adjustedAim += jitter
        
        // Apply reaction time delay
        val reactionTime = params.reactionTimeDelay.start + 
                          random.nextFloat() * (params.reactionTimeDelay.endInclusive - params.reactionTimeDelay.start)
        val delayFactor = (deltaTime / reactionTime).coerceIn(0.0f, 1.0f)
        adjustedAim = slerp(currentAim, adjustedAim, delayFactor)
        
        return adjustedAim.normalize()
    }

    fun adjustRecoilForHeadshot(
        currentRecoil: Vector3,
        consecutiveHeadshots: Int
    ): Vector3 {
        if (!params.isActive) return currentRecoil

        var adjustedRecoil = currentRecoil
        
        // Apply headshot recoil reduction
        adjustedRecoil *= params.headshotRecoilReduction
        
        // Apply sustained fire stability for consecutive headshots
        if (consecutiveHeadshots > 0) {
            val stabilityBonus = 1.0f - (params.sustainedFireStability * consecutiveHeadshots.coerceAtMost(5) * 0.1f)
            adjustedRecoil *= stabilityBonus
        }
        
        return adjustedRecoil
    }

    fun registerHeadshot() {
        val currentTime = System.currentTimeMillis()
        headshotHistory.add(currentTime)
        if (headshotHistory.size > maxHistorySize) {
            headshotHistory.removeFirst()
        }
        
        // Update consecutive headshots counter
        if (currentTime - lastHeadshotTime < 2000) { // 2 second window for consecutive headshots
            consecutiveHeadshots++
        } else {
            consecutiveHeadshots = 1
        }
        lastHeadshotTime = currentTime
    }

    fun getHeadshotStats(): HeadshotStats {
        val totalShots = headshotHistory.size * 2 // Approximation
        val headshotRate = if (totalShots > 0) headshotHistory.size.toFloat() / totalShots else 0f
        val avgTimeBetweenHeadshots = if (headshotHistory.size > 1) {
            val times = headshotHistory.windowed(2).map { it[1] - it[0] }
            times.average().toFloat() / 1000f
        } else 0f

        return HeadshotStats(
            totalHeadshots = headshotHistory.size,
            headshotRate = headshotRate,
            consecutiveHeadshots = consecutiveHeadshots,
            avgTimeBetweenHeadshots = avgTimeBetweenHeadshots
        )
    }

    private fun expandHeadHitbox(headPosition: Vector3, expansion: Float): Vector3 {
        return Vector3(
            headPosition.x * expansion,
            headPosition.y * expansion,
            headPosition.z * expansion
        )
    }

    private fun predictHeadMovement(
        headPosition: Vector3,
        velocity: Vector3,
        deltaTime: Float,
        distance: Float
    ): Vector3 {
        val predictionFactor = when {
            distance < params.closeRangeThreshold -> params.headMovementPrediction.start
            distance > params.longRangeThreshold -> params.headMovementPrediction.endInclusive
            else -> (params.headMovementPrediction.start + params.headMovementPrediction.endInclusive) / 2
        }
        
        val predictionOffset = velocity * (predictionFactor * deltaTime)
        val smoothedPrediction = predictionOffset * params.predictionSmoothing
        
        return headPosition + smoothedPrediction
    }

    private fun calculateHumanizationJitter(): Vector3 {
        return Vector3(
            (random.nextFloat() * 2 - 1) * params.humanizationJitter,
            (random.nextFloat() * 2 - 1) * params.humanizationJitter,
            0f
        )
    }

    private fun slerp(start: Vector3, end: Vector3, t: Float): Vector3 {
        val dot = start.dot(end).coerceIn(-1f, 1f)
        val theta = acos(dot) * t
        val relative = (end - start * dot).normalize()
        return start * cos(theta) + relative * sin(theta)
    }
}

// Supporting data classes
enum class WeaponType {
    SNIPER, ASSAULT_RIFLE, SHOTGUN, SMG, PISTOL
}

data class HeadshotStats(
    val totalHeadshots: Int,
    val headshotRate: Float,
    val consecutiveHeadshots: Int,
    val avgTimeBetweenHeadshots: Float
)

data class Vector3(var x: Float, var y: Float, var z: Float) {
    fun normalize(): Vector3 {
        val len = sqrt(x*x + y*y + z*z)
        return if (len == 0f) this else Vector3(x/len, y/len, z/len)
    }

    fun dot(other: Vector3): Float = x*other.x + y*other.y + z*other.z

    operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float) = Vector3(x * scalar, y * scalar, z * scalar)

    companion object {
        fun lookAt(from: Vector3, to: Vector3): Vector3 = (to - from).normalize()
    }
}

data class EnemyEntity(
    val headPosition: Vector3,
    val bodyPosition: Vector3,
    val velocity: Vector3,
    val isVisible: Boolean = true
)
