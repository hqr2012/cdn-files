import kotlin.math.abs
import kotlin.math.sqrt

class HomingBulletSystem {
    private val maxHomingAngle = 45f
    private val homingStrength = 0.95f
    private val trackingRange = 500f
    private val bulletSpeed = 85f

    fun updateBullet(
        bullet: Bullet,
        targets: List<Target>,
        deltaTime: Float
    ) {
        if (!bullet.isActive) return
        if (bullet.target == null) {
            bullet.target = findBestTarget(bullet, targets)
        }
        bullet.target?.let { target ->
            if (isValidTarget(bullet, target)) {
                applyHoming(bullet, target, deltaTime)
            } else {
                bullet.target = null
            }
        }
        moveBullet(bullet, deltaTime)
    }

    private fun findBestTarget(bullet: Bullet, targets: List<Target>): Target? {
        return targets.filter { isValidTarget(bullet, it) }
            .minByOrNull { distance(bullet.position, it.position) }
    }

    private fun isValidTarget(bullet: Bullet, target: Target): Boolean {
        val dist = distance(bullet.position, target.position)
        return dist <= trackingRange && target.isAlive
    }

    private fun applyHoming(bullet: Bullet, target: Target, deltaTime: Float) {
        val toTarget = normalize(
            target.position.x - bullet.position.x,
            target.position.y - bullet.position.y,
            target.position.z - bullet.position.z
        )
        val homing = lerp(bullet.direction, toTarget, homingStrength * deltaTime)
        bullet.direction = homing
    }

    private fun moveBullet(bullet: Bullet, deltaTime: Float) {
        bullet.position.x += bullet.direction.x * bulletSpeed * deltaTime
        bullet.position.y += bullet.direction.y * bulletSpeed * deltaTime
        bullet.position.z += bullet.direction.z * bulletSpeed * deltaTime
    }

    private fun distance(a: Vec3, b: Vec3): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun normalize(x: Float, y: Float, z: Float): Vec3 {
        val len = sqrt(x * x + y * y + z * z)
        return if (len == 0f) Vec3(0f, 0f, 0f)
        else Vec3(x / len, y / len, z / len)
    }

    private fun lerp(from: Vec3, to: Vec3, t: Float): Vec3 {
        return Vec3(
            from.x + (to.x - from.x) * t,
            from.y + (to.y - from.y) * t,
            from.z + (to.z - from.z) * t
        )
    }
}

// Data Classes
data class Bullet(
    var position: Vec3 = Vec3(),
    var direction: Vec3 = Vec3(),
    var target: Target? = null,
    var isActive: Boolean = true
)

data class Target(
    var position: Vec3 = Vec3(),
    var isAlive: Boolean = true
)

data class Vec3(
    var x: Float = 0f,
    var y: Float = 0f,
    var z: Float = 0f
)
