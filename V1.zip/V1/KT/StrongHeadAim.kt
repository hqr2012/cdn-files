import kotlin.math.sqrt
import kotlin.math.acos

class StrongHeadAim {
    private val aimForce = 1.0f
    private val smooth = 0.95f
    private val maxFov = 180.0f
    private val maxDistance = 9999.0f

    fun update(camera: Camera, targets: List<Entity>, deltaTime: Float) {
        val best = findBestHeadTarget(camera, targets) ?: return
        applyStrongHeadLock(camera, best, deltaTime)
    }

    private fun findBestHeadTarget(camera: Camera, targets: List<Entity>): Entity? {
        return targets.filter {
            it.isAlive &&
            distance(camera.pos, it.headPos) <= maxDistance &&
            fovAngle(camera.dir, camera.pos, it.headPos) <= maxFov
        }.minByOrNull {
            distance(camera.pos, it.headPos)
        }
    }

    private fun applyStrongHeadLock(camera: Camera, target: Entity, deltaTime: Float) {
        val desired = norm(target.headPos - camera.pos)
        val t = smooth * aimForce * deltaTime * 80f

        camera.dir.x = lerp(camera.dir.x, desired.x, t)
        camera.dir.y = lerp(camera.dir.y, desired.y, t)
        camera.dir.z = lerp(camera.dir.z, desired.z, t)

        camera.dir = norm(camera.dir)
    }

    private fun fovAngle(fromDir: Vec3, from: Vec3, to: Vec3): Float {
        val dir = norm(to - from)
        val dot = fromDir.dot(dir).coerceIn(-1f, 1f)
        return acos(dot) * 57.2958f
    }

    private fun distance(a: Vec3, b: Vec3): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx*dx + dy*dy + dz*dz)
    }

    private fun norm(v: Vec3): Vec3 {
        val m = sqrt(v.x*v.x + v.y*v.y + v.z*v.z)
        return if (m == 0f) Vec3(0f,0f,0f) else Vec3(v.x/m, v.y/m, v.z/m)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t.coerceIn(0f,1f)
}

data class Vec3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    operator fun minus(other: Vec3) = Vec3(x-other.x, y-other.y, z-other.z)
    fun dot(other: Vec3) = x*other.x + y*other.y + z*other.z
}

data class Camera(val pos: Vec3, val dir: Vec3)
data class Entity(val headPos: Vec3, val isAlive: Boolean = true)
