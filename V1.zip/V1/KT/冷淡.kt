import kotlin.math.*
import kotlin.random.Random

data class PeaceEliteRangeParams(
    val mapSupport: MapSupport = MapSupport.ALL,
    val modeSupport: ModeSupport = ModeSupport.RANKED,
    val weaponSupport: WeaponSupport = WeaponSupport.ALL,
    val hitDetectionRange: ClosedFloatingPointRange<Float> = 0.0f..2000.0f,
    val aimAssistStrength: ClosedFloatingPointRange<Float> = 0.85f..1.0f,
    val movementPrediction: ClosedFloatingPointRange<Float> = 0.8f..1.2f,
    val bulletDropCompensation: ClosedFloatingPointRange<Float> = 50.0f..100.0f,
    val recoilControl: ClosedFloatingPointRange<Float> = 0.9f..1.0f,
    val accuracyMultiplier: ClosedFloatingPointRange<Float> = 3.0f..5.0f,
    val priorityLevel: Int = 10,
    val isActive: Boolean = true,
    val configVersion: String = "99.0.0",
    val fovLock: Float = 30f,
    val bonePriority: List<Bone> = listOf(Bone.HEAD, Bone.SPINE, Bone.PELVIS)
) {
    enum class MapSupport { ALL, ERANGEL, MIRAMAR, VIKENDI, KARAKIN }
    enum class ModeSupport { ALL, TPP, FPP, RANKED }
    enum class WeaponSupport { ALL, ASSAULT_RIFLE, SNIPER_RIFLE, SHOTGUN, SMG }
    enum class Bone { HEAD, SPINE, PELVIS, LEFT_SHOULDER, RIGHT_SHOULDER }

    fun validate(): Boolean {
        return hitDetectionRange.start >= 0f &&
               aimAssistStrength.start in 0f..1f &&
               recoilControl.start in 0f..1f &&
               priorityLevel in 1..100
    }
}

class DivineAimbotCore(
    private val params: PeaceEliteRangeParams = PeaceEliteRangeParams(),
    private val random: Random = Random(42)
) {
    private var isAimbotActive = true
    private var targetLock: EnemyEntity? = null
    private var smoothFactor: Float = 0.95f
    private var lastUpdateTime: Long = 0
    private val aimSmoothingBuffer = mutableListOf<Vector3>()
    private val bufferSize = 5

    fun processAimbot(currentView: CameraView, enemies: List<EnemyEntity>, deltaTime: Float) {
        if (!params.isActive || !isAimbotActive) return

        val validTargets = filterValidTargets(enemies, currentView)
        val bestTarget = findBestTarget(validTargets, currentView)

        bestTarget?.let { target ->
            targetLock = target
            val aimVector = calculateAimVector(target, currentView, deltaTime)
            executeSmoothAim(currentView, aimVector, deltaTime)
        } ?: run {
            targetLock = null
            aimSmoothingBuffer.clear()
        }
    }

    private fun filterValidTargets(enemies: List<EnemyEntity>, view: CameraView): List<EnemyEntity> {
        return enemies.filter { enemy ->
            // Map and mode filtering
            (params.mapSupport == PeaceEliteRangeParams.MapSupport.ALL ||
             params.mapSupport.name == enemy.currentMap.name) &&
            (params.modeSupport == PeaceEliteRangeParams.ModeSupport.ALL ||
             params.modeSupport.name == enemy.gameMode.name) &&
            // Distance check
            calculateDistance(view.position, getTargetBone(enemy)) <= params.hitDetectionRange.endInclusive &&
            // FOV check
            isWithinFOV(view, getTargetBone(enemy))
        }
    }

    private fun findBestTarget(targets: List<EnemyEntity>, view: CameraView): EnemyEntity? {
        return targets.minByOrNull { target ->
            val distanceScore = calculateDistance(view.position, getTargetBone(target))
            val threatScore = target.threatLevel * 2.5f
            val fovScore = calculateFOVAngle(view, getTargetBone(target))
            val priorityScore = (100 - params.priorityLevel) * 0.2f

            (distanceScore * 0.25f) + (threatScore * 0.45f) + (fovScore * 0.2f) + priorityScore
        }
    }

    private fun calculateAimVector(target: EnemyEntity, view: CameraView, deltaTime: Float): Vector3 {
        val targetBone = getTargetBone(target)
        var predictedPosition = targetBone

        // Movement prediction
        val predictionOffset = target.velocity * params.movementPrediction.clamp(0.5f, 1.5f)
        predictedPosition += predictionOffset

        // Bullet drop compensation
        val distance = calculateDistance(view.position, predictedPosition)
        val dropCompensation = params.bulletDropCompensation.clamp(40f, 120f)
        val heightAdjustment = (distance * dropCompensation) * 0.0045f
        predictedPosition.y += heightAdjustment

        // Human-like jitter
        val jitter = calculateJitter(params.accuracyMultiplier.clamp(2.5f, 5.5f))
        predictedPosition += jitter

        return Vector3.lookAt(view.position, predictedPosition)
    }

    private fun executeSmoothAim(view: CameraView, aimVector: Vector3, deltaTime: Float) {
        val strength = params.aimAssistStrength.clamp(0.7f, 1.0f)
        val smoothTime = 1.0f / (strength * 25f)
        smoothFactor = (deltaTime / (smoothTime + deltaTime)).coerceIn(0.3f, 0.98f)

        // Add to smoothing buffer for natural movement
        aimSmoothingBuffer.add(aimVector)
        if (aimSmoothingBuffer.size > bufferSize) aimSmoothingBuffer.removeFirst()

        val smoothedAim = averageVectors(aimSmoothingBuffer)
        view.rotation = slerp(view.rotation, smoothedAim, smoothFactor)

        // Recoil control
        if (params.recoilControl.endInclusive > 0f) {
            view.applyRecoilCompensation(params.recoilControl.clamp(0.8f, 1.0f))
        }
    }

    private fun getTargetBone(enemy: EnemyEntity): Vector3 {
        // Prioritize bones based on config
        return when {
            params.bonePriority.contains(PeaceEliteRangeParams.Bone.HEAD) -> enemy.headPosition
            params.bonePriority.contains(PeaceEliteRangeParams.Bone.SPINE) -> enemy.bodyPosition
            else -> enemy.headPosition
        }
    }

    private fun isWithinFOV(view: CameraView, target: Vector3): Boolean {
        val angle = calculateFOVAngle(view, target)
        return angle <= params.fovLock
    }

    private fun calculateFOVAngle(view: CameraView, target: Vector3): Float {
        val directionToTarget = (target - view.position).normalize()
        val dotProduct = view.rotation.dot(directionToTarget)
        return Math.toDegrees(acos(dotProduct).toDouble()).toFloat()
    }

    private fun averageVectors(vectors: List<Vector3>): Vector3 {
        if (vectors.isEmpty()) return Vector3(0f, 0f, 0f)
        val sum = vectors.reduce { acc, vec -> acc + vec }
        return sum * (1f / vectors.size)
    }

    private fun slerp(start: Vector3, end: Vector3, t: Float): Vector3 {
        val dot = start.dot(end).coerceIn(-1f, 1f)
        val theta = acos(dot) * t
        val relative = (end - start * dot).normalize()
        return start * cos(theta) + relative * sin(theta)
    }

    private fun calculateJitter(strength: Float): Vector3 {
        val jitterScale = (6.0f - strength) * 0.08f
        return Vector3(
            (random.nextFloat() * 0.4f - 0.2f) * jitterScale,
            (random.nextFloat() * 0.4f - 0.2f) * jitterScale,
            0f
        )
    }

    private fun calculateDistance(a: Vector3, b: Vector3): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx*dx + dy*dy + dz*dz)
    }

    fun activate() {
        isAimbotActive = true
    }

    fun deactivate() {
        isAimbotActive = false
        targetLock = null
        aimSmoothingBuffer.clear()
    }

    fun getCurrentTarget(): EnemyEntity? = targetLock
}

data class Vector3(var x: Float, var y: Float, var z: Float) {
    fun normalize(): Vector3 {
        val len = sqrt(x*x + y*y + z*z)
        return if (len == 0f) this else Vector3(x/len, y/len, z/len)
    }

    fun dot(other: Vector3): Float = x*other.x + y*other.y + z*other.z

    operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float) = Vector3(x * scalar, y * scalar, z * scalar)

    companion object {
        fun lookAt(from: Vector3, to: Vector3): Vector3 = (to - from).normalize()
    }
}

data class CameraView(
    var position: Vector3,
    var rotation: Vector3,
    var fieldOfView: Float = 90f
) {
    fun applyRecoilCompensation(strength: Float) {
        val recoilReduction = 1f - strength
        this.rotation.x = (this.rotation.x * recoilReduction).coerceAtMost(0.35f)
    }
}

data class EnemyEntity(
    val headPosition: Vector3,
    val bodyPosition: Vector3,
    val velocity: Vector3,
    val currentMap: PeaceEliteRangeParams.MapSupport,
    val gameMode: PeaceEliteRangeParams.ModeSupport,
    val threatLevel: Int = 1,
    val isVisible: Boolean = true,
    val distance: Float = 0f
)
