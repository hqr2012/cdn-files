object ProjectileSystem {
   
    const val HEADSHOT_HITBOX_SCALE = 3.2f
    const val BODY_HITBOX_SCALE = 1.8f
    const val BULLET_SPEED_MULTIPLIER = 5.0f
    const val BULLET_GRAVITY_MULTIPLIER = 0.0f
    const val RECOIL_CONTROL_FACTOR = 0.05f
    const val MAX_TARGET_DISTANCE = 500.8f

   
    const val AIM_ASSIST_STRENGTH = 1.8f
    const val AIM_SMOOTH = 0.85f

   
    const val HEADSHOT_DAMAGE_MULTIPLIER = 4.0f
    const val BULLET_PENETRATION = 99999.0f

    fun enhanceBullet(bullet: Bullet) {
        bullet.speed *= BULLET_SPEED_MULTIPLIER
        bullet.gravityScale *= BULLET_GRAVITY_MULTIPLIER
        bullet.penetration = BULLET_PENETRATION
    }

    fun isHeadshotHit(
        bullet: Bullet,
        target: Enemy,
        distance: Float
    ): Boolean {
        if (distance > MAX_TARGET_DISTANCE) return false

        val expandedHead = target.headBounds.expand(HEADSHOT_HITBOX_SCALE)
        return expandedHead.contains(bullet.endPoint)
    }

    fun applyRecoilControl(camera: Camera) {
        camera.recoilX *= RECOIL_CONTROL_FACTOR
        camera.recoilY *= RECOIL_CONTROL_FACTOR
    }

    fun aimAtTarget(
        currentAim: AimState,
        target: Enemy
    ): AimState {
        val targetPos = target.headPosition
        val aimVector = (targetPos - currentAim.position).normalize()
        return currentAim.smoothTo(aimVector, AIM_SMOOTH, AIM_ASSIST_STRENGTH)
    }

    fun showActivatedMessage() {
        showToast("VIP MAGIC ACTIVE 990%")
    }
}

data class Bullet(
    var speed: Float = 85f,
    var gravityScale: Float = 1f,
    var penetration: Float = 1f,
    val endPoint: Vector3
)

data class Enemy(
    val headPosition: Vector3,
    val headBounds: Bounds,
    val distance: Float
)

data class AimState(val position: Vector3, val rotation: Vector3)
data class Vector3(val x: Float, val y: Float, val z: Float)
data class Bounds(val center: Vector3, val extents: Vector3)

fun Bounds.expand(scale: Float) = Bounds(center, extents * scale)
fun Vector3.normalize() = this / length()
fun Vector3.smoothTo(target: Vector3, smooth: Float, strength: Float) =
    this.lerp(target, smooth * strength)

fun showToast(msg: String) {
    println(msg)
}
