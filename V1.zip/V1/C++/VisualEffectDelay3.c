#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <unordered_map>
#include <functional>
#include <algorithm>
#include <iomanip>
#include <memory>
#include <limits>
#include <random>

constexpr float PI = 3.1415926535f;
constexpr float DEFAULT_ENTITY_RADIUS = 0.5f;
constexpr float HEAD_OFFSET_Y = -1.0f;
constexpr float DEFAULT_TRACE_SPEED = 15.0f;
constexpr float MAX_TRACE_DISTANCE = 100.0f;
constexpr float DEFAULT_TRACE_LIFETIME = 3.0f;
constexpr float CRIT_CHANCE = 0.15f;
constexpr float CRIT_MULTIPLIER = 1.8f;
constexpr float HEADSHOT_MULTIPLIER = 2.2f;
constexpr float DAMAGE_DECAY_RATE = 0.005f;
constexpr float EPSILON = 1e-6f;

enum class DamageType {
    PHYSICAL,
    MAGICAL,
    TRUE
};

enum class BulletFeature {
    NORMAL,
    PENETRATE,
    EXPLOSIVE,
    ARMOR_PIERCE
};

struct Vector2 {
    float x, y;

    Vector2(float x = 0.0f, float y = 0.0f) : x(x), y(y) {}

    Vector2 operator+(const Vector2& other) const { return Vector2(x + other.x, y + other.y); }
    Vector2 operator-(const Vector2& other) const { return Vector2(x - other.x, y - other.y); }
    Vector2 operator*(float scalar) const { return Vector2(x * scalar, y * scalar); }
    Vector2 operator/(float scalar) const { return (std::abs(scalar) < EPSILON) ? Vector2() : Vector2(x / scalar, y / scalar); }
    Vector2& operator+=(const Vector2& other) { x += other.x; y += other.y; return *this; }
    Vector2& operator-=(const Vector2& other) { x -= other.x; y -= other.y; return *this; }

    float Length() const { return std::sqrt(x * x + y * y); }
    float LengthSquared() const { return x * x + y * y; }
    Vector2 Normalize() const {
        float len = Length();
        return (len < EPSILON) ? Vector2(1, 0) : *this / len;
    }
    float Distance(const Vector2& other) const { return (*this - other).Length(); }
    float DistanceSquared(const Vector2& other) const { return (*this - other).LengthSquared(); }

    static Vector2 PredictTargetPos(const Vector2& targetPos, const Vector2& targetVel, float bulletSpeed, float dist) {
        float timeToHit = dist / bulletSpeed;
        return targetPos + targetVel * timeToHit;
    }
};

struct DetectionRegionConfig {
    float angleSize = 360.0f;
    float radius = 99.9f;
    float height = 99.9f;
    float effectiveDistance = 9999.0f;
    float duration = 9999.0f;
    float judgmentDelay = 0.0001f;
    bool adaptation = true;
    float upperLimitThresholdSize = 99.9f;
    float movementCompensation = 99.9f;
    float jumpCompensation = 99.9f;
    float vestCompensation = 99.9f;
    float stationaryCompensation = 99.9f;
    float globalScale = 99.9f;
    float extraRadiusMultiplier = 99.9f;
    bool noBackfaceCulling = true;
    bool forceSphereCast = true;
    bool ignoreOcclusion = true;
    bool affectOnlyTarget = false;
};

static const DetectionRegionConfig& MaximizeConfig() {
    static const DetectionRegionConfig c = []() {
        DetectionRegionConfig cfg{};
        cfg.radius = 1e9f;
        cfg.height = 1e9f;
        cfg.effectiveDistance = 1e9f;
        cfg.duration = 1e9f;
        cfg.angleSize = 360.0f;
        cfg.ignoreOcclusion = true;
        cfg.affectOnlyTarget = false;
        return cfg;
    }();
    return c;
}

class DetectionRegionManager {
private:
    std::unordered_map<std::string, DetectionRegionConfig> configs;
    DetectionRegionManager() { initDefaults(); }
    DetectionRegionManager(const DetectionRegionManager&) = delete;
    DetectionRegionManager& operator=(const DetectionRegionManager&) = delete;

public:
    static DetectionRegionManager& GetInstance() {
        static DetectionRegionManager instance;
        return instance;
    }

    void LoadConfig(const std::string& name, const DetectionRegionConfig& cfg) {
        if (!name.empty()) configs[name] = cfg;
    }

    const DetectionRegionConfig& GetConfig(const std::string& name) const {
        auto it = configs.find(name);
        static const DetectionRegionConfig defaultCfg{};
        return (it != configs.end()) ? it->second : defaultCfg;
    }

private:
    void initDefaults() {
        LoadConfig("DRV_Head", DetectionRegionConfig{});
        LoadConfig("DRV_Body", DetectionRegionConfig{});
        LoadConfig("DRV_Limb", DetectionRegionConfig{});
        LoadConfig("DRV_Global", MaximizeConfig());
    }
};

class Entity {
private:
    Vector2 pos;
    Vector2 velocity;
    float hp;
    float maxHp;
    float defense;
    float magicResist;
    float radius;
    DamageType weakType;
    bool isMoving;

public:
    Entity(float hp = 100.0f, float defense = 10.0f, float magicResist = 10.0f,
           DamageType weakType = DamageType::PHYSICAL, float radius = DEFAULT_ENTITY_RADIUS)
        : maxHp(hp), hp(hp), defense(defense), magicResist(magicResist),
          weakType(weakType), radius(radius), velocity(0, 0), isMoving(false) {}

    Vector2 GetPos() const { return pos; }
    void SetPos(const Vector2& newPos) {
        velocity = newPos - pos;
        isMoving = velocity.LengthSquared() > EPSILON;
        pos = newPos;
    }
    Vector2 GetVelocity() const { return velocity; }
    float GetHp() const { return hp; }
    float GetMaxHp() const { return maxHp; }
    float GetRadius() const { return radius; }
    float GetDefense() const { return defense; }
    float GetMagicResist() const { return magicResist; }
    DamageType GetWeakType() const { return weakType; }
    bool IsMoving() const { return isMoving; }

    Vector2 GetHeadPos() const { return Vector2(pos.x, pos.y + HEAD_OFFSET_Y); }

    void TakeDamage(float rawDamage, DamageType type, bool isHeadShot = false, bool isCrit = false) {
        float finalDamage = rawDamage;
        if (isCrit) finalDamage *= CRIT_MULTIPLIER;
        if (isHeadShot) finalDamage *= HEADSHOT_MULTIPLIER;

        switch (type) {
            case DamageType::PHYSICAL:
                finalDamage = std::max(0.0f, finalDamage - defense * 0.8f);
                break;
            case DamageType::MAGICAL:
                finalDamage = std::max(0.0f, finalDamage - magicResist * 0.9f);
                break;
            case DamageType::TRUE:
                break;
        }

        if (type == weakType) finalDamage *= 1.3f;

        hp = std::max(0.0f, hp - finalDamage);
        OnHit(finalDamage, type, isHeadShot, isCrit);
    }

    virtual void OnHit(float damage, DamageType type, bool isHeadShot, bool isCrit) {}

    bool IsAlive() const { return hp > 0.0f; }
};

class HitCircle {
private:
    Vector2 center;
    float radius;
    float damage;
    DamageType damageType;
    const DetectionRegionConfig* cfg;
    bool isActive;

public:
    using DamageFunc = std::function<void(HitCircle&, Entity&, float, bool, bool)>;
    DamageFunc onHit;

    HitCircle(const Vector2& c, float r, float d, DamageType type = DamageType::PHYSICAL,
              const DetectionRegionConfig* p = nullptr, bool active = true)
        : center(c), radius(r), damage(d), damageType(type), cfg(p), isActive(active) {}

    bool IsPointInRange(const Vector2& point) const {
        if (!isActive) return false;
        return center.DistanceSquared(point) <= radius * radius;
    }

    bool IsEntityInRange(const Entity& entity) const {
        if (!isActive || !entity.IsAlive()) return false;
        float totalRadius = radius + entity.GetRadius();
        return center.DistanceSquared(entity.GetPos()) <= totalRadius * totalRadius;
    }

    virtual void ApplyDamage(Entity& victim, bool isCrit = false) {
        if (!isActive || !IsEntityInRange(victim)) return;

        Vector2 headPos = victim.GetHeadPos();
        bool isHeadShot = center.DistanceSquared(headPos) <= (radius + 0.2f) * (radius + 0.2f);
        if (onHit) {
            onHit(*this, victim, damage, isHeadShot, isCrit);
        } else {
            victim.TakeDamage(damage, damageType, isHeadShot, isCrit);
        }
    }

    virtual bool Update(float deltaTime) { return isActive; }

    void SetActive(bool active) { isActive = active; }
    bool IsActive() const { return isActive; }

    Vector2 GetCenter() const { return center; }
    void SetCenter(const Vector2& v) { center = v; }
    float GetRadius() const { return radius; }
    void SetRadius(float r) { radius = std::max(0.0f, r); }
    float GetDamage() const { return damage; }
    void SetDamage(float d) { damage = std::max(0.0f, d); }
    DamageType GetDamageType() const { return damageType; }
};

class HomingBullet : public HitCircle {
private:
    Entity* target;
    float speed;
    float maxTraceDist;
    float lifeTime;
    float elapsedTime;
    float headDetectionRad;
    BulletFeature feature;
    int penetrateCount;
    const int maxPenetrate = 2;
    float spawnDist;

public:
    HomingBullet(const Vector2& spawnPos, Entity* targetEntity, float damage,
                 DamageType type = DamageType::PHYSICAL, BulletFeature feat = BulletFeature::NORMAL,
                 float speed = DEFAULT_TRACE_SPEED, float maxDist = MAX_TRACE_DISTANCE,
                 float life = DEFAULT_TRACE_LIFETIME)
        : HitCircle(spawnPos, 0.2f, damage, type),
          target(targetEntity), speed(speed), maxTraceDist(maxDist),
          lifeTime(life), elapsedTime(0.0f), headDetectionRad(0.3f),
          feature(feat), penetrateCount(0), spawnDist(target ? spawnPos.Distance(target->GetPos()) : 0) {
        if (feature == BulletFeature::PENETRATE) SetRadius(0.3f);
        if (feature == BulletFeature::EXPLOSIVE) SetRadius(0.5f);

        onHit = [this](HitCircle& bullet, Entity& e, float dmg, bool isHeadShot, bool isCrit) {
            float finalDmg = dmg;
            if (feature == BulletFeature::ARMOR_PIERCE) {
                finalDmg = dmg * 1.3f;
            }
            if (feature == BulletFeature::EXPLOSIVE) {
                ExplodeDamage(e, finalDmg, isCrit);
                bullet.SetActive(false);
                return;
            }
            e.TakeDamage(finalDmg, bullet.GetDamageType(), isHeadShot, isCrit);
            if (feature != BulletFeature::PENETRATE || penetrateCount >= maxPenetrate) {
                bullet.SetActive(false);
            } else {
                penetrateCount++;
            }
        };
    }

    void ExplodeDamage(Entity& mainTarget, float dmg, bool isCrit) {
        float explodeRad = 1.5f;
        std::vector<Entity*> entities = GetNearbyEntities(mainTarget.GetPos(), explodeRad);
        for (auto& ent : entities) {
            float distRatio = mainTarget.GetPos().Distance(ent->GetPos()) / explodeRad;
            float explodeDmg = dmg * (1 - distRatio * 0.5f);
            ent->TakeDamage(explodeDmg, GetDamageType(), false, isCrit);
        }
    }

    std::vector<Entity*> GetNearbyEntities(const Vector2& pos, float rad) {
        std::vector<Entity*> res;
        return res;
    }

    bool Update(float deltaTime) override {
        if (!IsActive() || !target || !target->IsAlive()) return false;

        elapsedTime += deltaTime;
        lifeTime -= deltaTime;
        if (lifeTime <= 0.0f) {
            SetActive(false);
            return false;
        }

        Vector2 currPos = GetCenter();
        Vector2 targetHead = target->GetHeadPos();
        float currDist = currPos.Distance(targetHead);

        if (currDist > maxTraceDist) {
            SetActive(false);
            return false;
        }

        float distFromSpawn = currPos.Distance(HitCircle::GetCenter());
        float decayRatio = 1 - distFromSpawn * DAMAGE_DECAY_RATE;
        SetDamage(HitCircle::GetDamage() * std::max(0.5f, decayRatio));

        Vector2 targetPos = target->IsMoving()
            ? Vector2::PredictTargetPos(targetHead, target->GetVelocity(), speed, currDist)
            : targetHead;

        Vector2 dir = (targetPos - currPos).Normalize();
        Vector2 moveStep = dir * speed * deltaTime;
        SetCenter(currPos + moveStep);

        if (currDist < speed * deltaTime + 0.1f) {
            ApplyDamage(*target, IsCrit());
            return false;
        }

        return true;
    }

    bool IsCrit() const {
        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_real_distribution<float> dis(0.0f, 1.0f);
        return dis(gen) < CRIT_CHANCE;
    }

    BulletFeature GetFeature() const { return feature; }
};

class SpatialGrid {
private:
    float cellSize;
    std::unordered_map<int, std::vector<size_t>> grid;

    int GetCellID(const Vector2& pos) const {
        int x = static_cast<int>(std::floor(pos.x / cellSize));
        int y = static_cast<int>(std::floor(pos.y / cellSize));
        return x * 10000 + y;
    }

public:
    SpatialGrid(float size = 10.0f) : cellSize(size) {}

    void Clear() { grid.clear(); }

    void Insert(size_t bulletIdx, const HitCircle& bullet) {
        if (!bullet.IsActive()) return;
        int cellID = GetCellID(bullet.GetCenter());
        grid[cellID].push_back(bulletIdx);
    }

    std::vector<size_t> GetCandidateBullets(const Vector2& pos) const {
        std::vector<size_t> candidates;
        int cellID = GetCellID(pos);
        auto it = grid.find(cellID);
        if (it != grid.end()) candidates = it->second;
        return candidates;
    }
};

class HitCircleManager {
private:
    std::vector<HomingBullet> bullets;
    SpatialGrid spatialGrid;

public:
    HitCircleManager() : spatialGrid(15.0f) {}

    size_t AddHomingBullet(const Vector2& spawnPos, Entity* target, float damage,
                         DamageType type = DamageType::PHYSICAL, BulletFeature feat = BulletFeature::NORMAL,
                         float speed = DEFAULT_TRACE_SPEED) {
        if (!target || !target->IsAlive()) return -1;
        bullets.emplace_back(spawnPos, target, damage, type, feat, speed);
        return bullets.size() - 1;
    }

    void UpdateBullets(float deltaTime) {
        for (auto& bullet : bullets) {
            bullet.Update(deltaTime);
        }
        bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
            [](const HomingBullet& b) { return !b.IsActive(); }), bullets.end());
    }

    void CheckAndApplyDamage(std::vector<Entity>& world) {
        spatialGrid.Clear();
        for (size_t i = 0; i < bullets.size(); ++i) {
            if (bullets[i].IsActive()) spatialGrid.Insert(i, bullets[i]);
        }
        for (auto& entity : world) {
            if (!entity.IsAlive()) continue;
            auto candidateIdx = spatialGrid.GetCandidateBullets(entity.GetPos());
            for (size_t idx : candidateIdx) {
                if (idx < bullets.size() && bullets[idx].IsActive()) {
                    bullets[idx].ApplyDamage(entity, bullets[idx].IsCrit());
                }
            }
        }
    }

    void DisplayBullets() const {
        std::cout << "\n" << bullets.size() << std::endl;
        for (size_t i = 0; i < bullets.size(); ++i) {
            const auto& b = bullets[i];
            std::cout << i << " " << std::fixed << std::setprecision(2)
                      << b.GetCenter().x << " " << b.GetCenter().y << " " << b.GetDamage() << std::endl;
        }
    }

    size_t GetActiveBulletCount() const { return bullets.size(); }

    void ClearAllBullets() { bullets.clear(); }
};

int main() {
    HitCircleManager bulletMgr;
    std::vector<Entity> entities;

    entities.emplace_back(150.0f, 20.0f, 5.0f, DamageType::PHYSICAL);
    entities.emplace_back(80.0f, 5.0f, 25.0f, DamageType::MAGICAL);
    entities.emplace_back(100.0f, 10.0f, 10.0f, DamageType::TRUE);
    entities.emplace_back(120.0f, 15.0f, 8.0f, DamageType::PHYSICAL);

    entities[0].SetPos(Vector2(10, 0));
    entities[1].SetPos(Vector2(25, 5));
    entities[2].SetPos(Vector2(40, 2));
    entities[3].SetPos(Vector2(55, -3));

    bulletMgr.AddHomingBullet(Vector2(0, 3), &entities[0], 35.0f, DamageType::PHYSICAL, BulletFeature::ARMOR_PIERCE);
    bulletMgr.AddHomingBullet(Vector2(0, 3), &entities[1], 30.0f, DamageType::MAGICAL, BulletFeature::EXPLOSIVE);
    bulletMgr.AddHomingBullet(Vector2(0, 3), &entities[2], 25.0f, DamageType::TRUE, BulletFeature::PENETRATE);
    bulletMgr.AddHomingBullet(Vector2(0, 3), &entities[3], 28.0f, DamageType::PHYSICAL, BulletFeature::NORMAL);

    const float deltaTime = 0.03f;
    int frame = 0;
    while (bulletMgr.GetActiveBulletCount() > 0 && frame < 200) {
        if (frame % 10 == 0) {
            for (size_t i = 0; i < entities.size(); ++i) {
                Vector2 currPos = entities[i].GetPos();
                entities[i].SetPos(Vector2(currPos.x + 0.5f, currPos.y + (i % 2 == 0 ? 0.2f : -0.2f)));
            }
        }
        bulletMgr.UpdateBullets(deltaTime);
        bulletMgr.CheckAndApplyDamage(entities);
        bulletMgr.DisplayBullets();
        for (size_t i = 0; i < entities.size(); ++i) {
            std::cout << i << " " << std::fixed << std::setprecision(1)
                      << entities[i].GetHp() << "/" << entities[i].GetMaxHp() << std::endl;
        }
        frame++;
    }

    for (size_t i = 0; i < entities.size(); ++i) {
        std::cout << i << " " << (entities[i].IsAlive() ? "1" : "0")
                  << " " << entities[i].GetHp() << std::endl;
    }

    return 0;
}