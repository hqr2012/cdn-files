    use crate::math::Vec2;

#[derive(Clone, Debug)]
pub struct ScopeTraining {
    pub enabled: bool,
    pub zoom: f32,
    pub base_fov: f32,
    pub current_fov: f32,
    pub crosshair_size: f32,
}

impl ScopeTraining {
    pub fn new(base_fov: f32) -> Self {
        Self {
            enabled: false,
            zoom: 1.0,
            base_fov,
            current_fov: base_fov,
            crosshair_size: 10.0,
        }
    }

    pub fn set_zoom(&mut self, zoom: f32) {
        self.zoom = zoom.clamp(1.0, 8.0);
        self.update_fov();
    }

    pub fn set_enabled(&mut self, enabled: bool) {
        self.enabled = enabled;
        self.update_fov();
    }

    fn update_fov(&mut self) {
        self.current_fov = if self.enabled {
            self.base_fov / self.zoom
        } else {
            self.base_fov
        };
    }

    pub fn crosshair_position(
        &self,
        width: f32,
        height: f32,
    ) -> Vec2 {
        Vec2::new(width * 0.5, height * 0.5)
    }

    pub fn current_crosshair_size(&self) -> f32 {
        self.crosshair_size / self.zoom
    }
}