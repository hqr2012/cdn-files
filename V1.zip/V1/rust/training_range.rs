use crate::math::Vec3;
use rand::Rng;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TrainingTarget {
    pub id: u32,
    pub position: Vec3,
    pub velocity: Vec3,
    pub radius: f32,
    pub active: bool,
}

#[derive(Clone, Debug)]
pub struct TrainingRange {
    pub targets: Vec<TrainingTarget>,
    pub width: f32,
    pub height: f32,
    pub depth: f32,
    next_id: u32,
}

impl TrainingRange {
    pub fn new(width: f32, height: f32, depth: f32) -> Self {
        Self {
            targets: Vec::new(),
            width: width.max(1.0),
            height: height.max(1.0),
            depth: depth.max(1.0),
            next_id: 1,
        }
    }

    pub fn spawn_target(&mut self, radius: f32) -> u32 {
        let mut rng = rand::thread_rng();

        let target = TrainingTarget {
            id: self.next_id,
            position: Vec3::new(
                rng.gen_range(-self.width / 2.0..self.width / 2.0),
                rng.gen_range(0.0..self.height),
                rng.gen_range(1.0..self.depth),
            ),
            velocity: Vec3::new(
                rng.gen_range(-2.0..2.0),
                rng.gen_range(-1.0..1.0),
                0.0,
            ),
            radius: radius.max(0.1),
            active: true,
        };

        let id = target.id;
        self.targets.push(target);
        self.next_id += 1;
        id
    }

    pub fn update(&mut self, delta_time: f32) {
        let dt = delta_time.clamp(0.0, 0.1);

        for target in &mut self.targets {
            if !target.active {
                continue;
            }

            target.position.x += target.velocity.x * dt;
            target.position.y += target.velocity.y * dt;

            let x_limit = self.width / 2.0;
            if target.position.x.abs() > x_limit {
                target.position.x =
                    target.position.x.clamp(-x_limit, x_limit);
                target.velocity.x = -target.velocity.x;
            }

            if target.position.y < 0.0
                || target.position.y > self.height
            {
                target.position.y =
                    target.position.y.clamp(0.0, self.height);
                target.velocity.y = -target.velocity.y;
            }
        }
    }

    pub fn deactivate_target(&mut self, id: u32) -> bool {
        if let Some(target) =
            self.targets.iter_mut().find(|t| t.id == id)
        {
            target.active = false;
            true
        } else {
            false
        }
    }

    pub fn active_count(&self) -> usize {
        self.targets.iter().filter(|t| t.active).count()
    }
}