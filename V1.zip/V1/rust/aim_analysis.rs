use crate::math::Vec2;

#[derive(Clone, Debug, Default)]
pub struct AimAnalysis {
    pub samples: u32,
    pub total_error: f32,
    pub max_error: f32,
    pub last_error: f32,
}

impl AimAnalysis {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn record(
        &mut self,
        crosshair: Vec2,
        target: Vec2,
    ) -> f32 {
        let error = crosshair.distance(target);

        self.samples += 1;
        self.total_error += error;
        self.max_error = self.max_error.max(error);
        self.last_error = error;

        error
    }

    pub fn average_error(&self) -> f32 {
        if self.samples == 0 {
            return 0.0;
        }

        self.total_error / self.samples as f32
    }

    pub fn reset(&mut self) {
        *self = Self::default();
    }
}