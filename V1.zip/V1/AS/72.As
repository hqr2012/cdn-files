Name of the program：“com.tencent.tmgp.pubgmhd”
Start item=app_com.tencent.tmgp.pubgmhd_files_UE4Game_ShadowTrackerExtra_ShadowTrackerExtra_Saved_Actionscript=Start_Implementation=Increased bullet damage increased bullet velo.java
{Startup function=
+Peace elite running state="100%"
+Scope of Peace Elite Model="99999999999999999"
+Peace Elite Gun Shooting Area="99999999999999999"
+Peace elites aim at themselves="99999999999999999"
+Peace Elite Gun Self-Aim="99999999999999999"
=Successful functioning of functions}
{Bullet trajectory=
+The trajectory of the peace elite bullet=Bullet locks="99999999999999999"
+Bullet and people="99999999999999999"
=Successful functioning of functions}
{Stress in the back of the gun=
+Peace Elite Gun Back Stretch="0"
+Stress as the gun moves="0"
+Steady after gun pressure="0"
=Successful functioning of functions}
={++++++++++Running state in the game="true"}   