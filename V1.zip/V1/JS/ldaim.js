
const aim = new AimAssist();

function loop(deltaTime) {
  aim.update(playerCamera, enemyList, deltaTime);
}
