const enemy = {
  isAlive: true,
  head: { x: 0, y: 1.7, z: 0 },
  body: { x: 0, y: 1.0, z: 0 }
};
