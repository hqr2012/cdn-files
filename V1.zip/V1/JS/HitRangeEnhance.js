class HitRangeEnhance {
    constructor() {
        this.HITBOX_SCALE = 1.9;
        this.HEAD_SCALE = 1.9;
        this.BODY_SCALE = 1.9;
        this.maxDistance = 500.0;
    }

   
    checkHit(camera, bulletPos, enemy) {
        if (!enemy.isAlive) return false;

        const dist = this.distance(camera.position, enemy.head);
        if (dist > this.maxDistance) return false;

        const expandedHead = this.expandBox(enemy.head, enemy.headSize, this.HEAD_SCALE);
        const expandedBody = this.expandBox(enemy.body, enemy.bodySize, this.BODY_SCALE);

        return this.pointInBox(bulletPos, expandedHead) || this.pointInBox(bulletPos, expandedBody);
    }

    
    checkHeadshot(bulletPos, enemy) {
        if (!enemy.isAlive) return false;
        const head = this.expandBox(enemy.head, enemy.headSize, this.HEAD_SCALE);
        return this.pointInBox(bulletPos, head);
    }

  
    expandBox(center, size, scale) {
        return {
            min: {
                x: center.x - size.x * scale * 0.5,
                y: center.y - size.y * scale * 0.5,
                z: center.z - size.z * scale * 0.5
            },
            max: {
                x: center.x + size.x * scale * 0.5,
                y: center.y + size.y * scale * 0.5,
                z: center.z + size.z * scale * 0.5
            }
        };
    }

    
    pointInBox(point, box) {
        return (
            point.x >= box.min.x && point.x <= box.max.x &&
            point.y >= box.min.y && point.y <= box.max.y &&
            point.z >= box.min.z && point.z <= box.max.z
        );
    }

    // 距离计算
    distance(a, b) {
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const dz = a.z - b.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
