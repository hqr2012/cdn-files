const enemy = {
    isAlive: true,
    head: { x: 0, y: 1.8, z: 0 },
    body: { x: 0, y: 1.0, z: 0 },
    headSize: { x: 0.3, y: 0.3, z: 0.3 },
    bodySize: { x: 0.6, y: 1.0, z: 0.4 }
};
