class AimAssistEnhanced {
  constructor() {
   
    this.aimStrength = 0.98;
    this.smoothSpeed = 15;
    this.maxFov = 60;
    this.maxDistance = 80;
    this.aimBone = 'head';
  }

 
  update(camera, targets, deltaTime) {
    const target = this.findBestTarget(camera, targets);
    if (!target) return;
    this.smoothAim(camera, target, deltaTime);
  }

  
  findBestTarget(camera, targets) {
    const camPos = camera.position;
    const camDir = this.normalize(camera.forward);

    return targets
      .filter(t => t.isAlive)
      .filter(t => {
        const head = t.head;
        const dist = this.distance(camPos, head);
        const dirToTarget = this.normalize(this.sub(head, camPos));
        const dot = this.dot(camDir, dirToTarget);
        const fov = Math.acos(Math.max(-1, Math.min(1, dot))) * (180 / Math.PI);
        return dist <= this.maxDistance && fov <= this.maxFov;
      })
      .sort((a, b) => this.distance(camPos, a.head) - this.distance(camPos, b.head))[0];
  }

 
  smoothAim(camera, target, deltaTime) {
    const desiredDir = this.normalize(this.sub(target.head, camera.position));
    const t = Math.min(1, this.smoothSpeed * deltaTime * this.aimStrength);

    camera.forward.x = this.lerp(camera.forward.x, desiredDir.x, t);
    camera.forward.y = this.lerp(camera.forward.y, desiredDir.y, t);
    camera.forward.z = this.lerp(camera.forward.z, desiredDir.z, t);

    camera.forward = this.normalize(camera.forward);
  }

 
  lerp(a, b, t) { return a + (b - a) * t; }
  sub(a, b) { return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }; }
  dot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
  distance(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
  normalize(v) {
    const m = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
    return m < 0.0001 ? { x:0, y:0, z:0 } : { x: v.x/m, y: v.y/m, z: v.z/m };
  }
}
