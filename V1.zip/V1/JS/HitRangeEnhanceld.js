
const hitEnhance = new HitRangeEnhance();
function onFire(bulletPos) {
    for (let enemy of enemyList) {
        if (hitEnhance.checkHeadshot(bulletPos, enemy)) {
            console.log("HEADSHOT!");
            applyDamage(enemy, 100);
        } else if (hitEnhance.checkHit(camera, bulletPos, enemy)) {
            applyDamage(enemy, 30);
        }
    }
}
