{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <Function>"bulletTracking"</Function
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
            "BulletTrackingIntensity=MAX
            "BulletTracking=MAX
            "GunBulletTracking=MAX
     "BulletTracking=MAX
     "BulletTrajectoryTracking=MAX
     "GunShootingRangeTrackingCharacter'sHead=MAX
     "FirearmTrackingArea=MAX
     "BulletTrackingArea=MAX
     "GunAndBulletTracking=MAX
     "GunAndBulletTrackingArea=head
     "CharacterMovesFirearmsFiresBullets,AndTracksTheHead=MAX
     "CharacterMovingBulletTrajectoryTrackingHead=MAX
     "BulletTrackingHeadTarget=MAX
     "FiringBulletsTrackingTheTarget'sHead=MAX
                     }:"execute"
             <Java>