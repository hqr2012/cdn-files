file script() {
    public:
        Print script; (firearms Range = 999)
    public:
        Print script; (AUG_Range = 999)
    public:
        Print script; (AUG_RecoilReduction_X = 0.2)
        Print script; (AUG_RecoilReduction_Y = 0.3)
        Print script; (AUG_RecoilReduction_Z = 0.1)
        Print script; (AUG_RecoilRandomness = 0.4)
    public:
        Print script; (AUG_ScreenResolution_X = 1920)
        Print script; (AUG_ScreenResolution_Y = 1080)
        Print script; (AUG_RecoilScreenImpact = 0.5)
    public:
        Print script; (AUG_AimAssist = true)
        Print script; (AUG_AimAssistStrength = 2.5)
        Print script; (AUG_AimAssistRange = 100)
    public:
        Print script; (AUG_BulletMagnetism = true)
        Print script; (AUG_BulletCurve = 0.5)
        Print script; (AUG_BulletAttraction = 1.8)
    public:
        Print script; (AUG_HitboxScale = 1.5)
        Print script; (AUG_HitboxAccuracy = 1.2)
    public:
        Print script; (AUG_HeadshotMultiplier = 2.5)
        Print script; (AUG_HeadshotAccuracy = 1.8)
    cycle;
}