import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter config file path: ");
        String filePath = scanner.nextLine();

        try {
            List<Config> configs = ConfigLoader.loadConfig(filePath);

            for (Config config : configs) {
                System.out.println("Name: " + config.getName());
                System.out.println("Type: " + config.getType());
                System.out.println("Value: " + config.getValue());
                // 根据配置执行相应的功能逻辑
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
