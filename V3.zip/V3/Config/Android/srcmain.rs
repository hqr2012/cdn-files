mod config;
mod player;
mod enemy;
mod aimbot;

use std::time::Instant;
use enemy::Enemy;
use player::{Player, Camera};
use aimbot::{LockingResult, Aimbot};

fn main() {
    let cfg = config::load("config.toml").unwrap();
    let mut player = Player::spawn();
    let mut enemies = Enemy::demo_vec();
    let camera = Camera::new(cfg.core.fov);
    let mut bot = Aimbot::new(cfg);

    loop {
        let _t = Instant::now();
        for e in &mut enemies { e.tick(); }

        if try_toggle_ads(&player) { player.ads = !player.ads; }

        if is_fire_pressed() {
            if let Some(LockingResult { shoot_pos, target }) = bot.fire_mode(&player, &camera, &enemies) {
                println!("FIRE {:?} {:?}", target.name, shoot_pos);
            }
        }

        if player.ads && bot.cfg.mode.auto_fire_when_aim_down_sight {
            if let Some(LockingResult { shoot_pos, target }) = bot.ads_mode(&player, &camera, &enemies) {
                println!("ADS-AUTO-FIRE {:?} {:?}", target.name, shoot_pos);
            }
        }

        std::thread::sleep(std::time::Duration::from_millis(16));
    }
}

fn try_toggle_ads(_: &Player) -> bool { (Instant::now().elapsed().as_secs() % 4) < 1 }
fn is_fire_pressed() -> bool { (Instant::now().elapsed().as_millis() % 1000) < 50 }