use glam::Vec3;

pub struct Player { pub pos: Vec3, pub ads: bool }
impl Player {
    pub fn spawn() -> Self { Self { pos: Vec3::ZERO, ads: false } }
}

pub struct Camera { pub fov: f32 }
impl Camera { pub fn new(fov: f32) -> Self { Self { fov } } }