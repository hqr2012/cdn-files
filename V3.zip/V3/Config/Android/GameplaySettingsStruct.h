#pragma once

#include "CoreMinimal.h"
#include "UObject/StructOnScope.h"
#include "GameplaySettingsStruct.generated.h"

USTRUCT(BlueprintType)
struct FWeaponConfig
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float FireRate;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float DamagePerBullet;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float BulletSpeed;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float RecoilVertical;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float RecoilHorizontal;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    int32 MagazineSize;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float AimDownSightTime;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float HipFireSpread;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float ADSZoom;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    bool bFullAuto;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float BulletDrop;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    float PenetrationPower;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    bool bBurstMode;

    UPROPERTY(BlueprintReadWrite, Category = "Weapon")
    int32 BurstCount;

    FWeaponConfig()
    {
        FireRate = 0.1f;
        DamagePerBullet = 30.0f;
        BulletSpeed = 700.0f;
        RecoilVertical = 1.0f;
        RecoilHorizontal = 1.0f;
        MagazineSize = 30;
        AimDownSightTime = 0.25f;
        HipFireSpread = 0.2f;
        ADSZoom = 1.5f;
        bFullAuto = true;
        BulletDrop = 0.15f;
        PenetrationPower = 0.7f;
        bBurstMode = false;
        BurstCount = 0;
    }
};

USTRUCT(BlueprintType)
struct FGameplayGlobalSettings
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadWrite, Category = "Aim Assist")
    bool bEnableAimAssist;

    UPROPERTY(BlueprintReadWrite, Category = "Aim Assist")
    float AimAssistStrength;

    UPROPERTY(BlueprintReadWrite, Category = "Aim Assist")
    float AimAssistMaxAngle;

    UPROPERTY(BlueprintReadWrite, Category = "Aim Assist")
    float AimAssistSmoothTime;

    UPROPERTY(BlueprintReadWrite, Category = "Hitbox")
    bool bEnableHitboxExpansion;

    UPROPERTY(BlueprintReadWrite, Category = "Hitbox")
    float HitboxScaleMultiplier;

    UPROPERTY(BlueprintReadWrite, Category = "Magic Bullet")
    bool bEnableMagicBullet;

    UPROPERTY(BlueprintReadWrite, Category = "Magic Bullet")
    float MagicBulletTurnRate;

    UPROPERTY(BlueprintReadWrite, Category = "Magic Bullet")
    float MagicBulletMaxTurnAngle;

    UPROPERTY(BlueprintReadWrite, Category = "Magic Bullet")
    float MagicBulletLifetime;

    UPROPERTY(BlueprintReadWrite, Category = "Headshot")
    bool bIncreaseHeadshotRate;

    UPROPERTY(BlueprintReadWrite, Category = "Headshot")
    float HeadshotBonusMultiplier;

    UPROPERTY(BlueprintReadWrite, Category = "Spread")
    bool bReduceBulletSpread;

    UPROPERTY(BlueprintReadWrite, Category = "Spread")
    float BulletSpreadReductionFactor;

    UPROPERTY(BlueprintReadWrite, Category = "Recoil")
    bool bDisableRecoil;

    UPROPERTY(BlueprintReadWrite, Category = "Recoil")
    float RecoilMultiplier;

    UPROPERTY(BlueprintReadWrite, Category = "Prediction")
    bool bEnableAutoAimPrediction;

    UPROPERTY(BlueprintReadWrite, Category = "Prediction")
    float PredictionTime;

    UPROPERTY(BlueprintReadWrite, Category = "Prediction")
    float MaxPredictionDistance;

    UPROPERTY(BlueprintReadWrite, Category = "Sticky Aim")
    bool bStickyAim;

    UPROPERTY(BlueprintReadWrite, Category = "Sticky Aim")
    float StickyAimPower;

    UPROPERTY(BlueprintReadWrite, Category = "Sticky Aim")
    float StickyAimRange;

    // 构造函数：默认值
    FGameplayGlobalSettings()
    {
        bEnableAimAssist = false;
        AimAssistStrength = 0.3f;
        AimAssistMaxAngle = 10.0f;
        AimAssistSmoothTime = 0.15f;

        bEnableHitboxExpansion = false;
        HitboxScaleMultiplier = 1.0f;

        bEnableMagicBullet = false;
        MagicBulletTurnRate = 360.0f;
        MagicBulletMaxTurnAngle = 15.0f;
        MagicBulletLifetime = 1.5f;

        bIncreaseHeadshotRate = false;
        HeadshotBonusMultiplier = 1.0f;

        bReduceBulletSpread = false;
        BulletSpreadReductionFactor = 1.0f;

        bDisableRecoil = false;
        RecoilMultiplier = 1.0f;

        bEnableAutoAimPrediction = false;
        PredictionTime = 0.1f;
        MaxPredictionDistance = 500.0f;

        bStickyAim = false;
        StickyAimPower = 0.5f;
        StickyAimRange = 2000.0f;
    }
};