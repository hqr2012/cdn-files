package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int GunFiringAccuracyHeartRateExpansionSpeed
 = 0.9999f;

        Firearms M416 = new Firearms();
        M416.applyShootToReduceBulletDistribution();

        Firearms AUG = new Firearms();
        AUG.applyShootToReduceBulletDistribution();

        Firearms AKM = new Firearms();
        AKM.applyShootToReduceBulletDistribution();

        Firearms M762 = new Firearms();
        M762.applyShootToReduceBulletDistribution();

        Firearms SCAR-L = new Firearms();
        SCAR-L.applyShootToReduceBulletDistribution();

        Firearms GROZA = new Firearms();
        GROZA.applyShootToReduceBulletDistribution();

        Firearms UMP45 = new Firearms();
        UMP45.applyShootToReduceBulletDistribution();

        Firearms Uzi = new Firearms();
        UZI.applyShootToReduceBulletDistribution();

        Firearms Vector = new Firearms();
        Vector.applyShootToReduceBulletDistribution();

        Firearms P90 = new Firearms();
        P90.applyShootToReduceBulletDistribution();

        Firearms Mk14 = new Firearms();
        Mk14.applyShootToReduceBulletDistribution();

        Firearms M249 = new Firearms();
        M249.applyShootToReduceBulletDistribution();

        Firearms MG3 = new Firearms();
        MG3.applyShootToReduceBulletDistribution();

        Firearms PKM = new Firearms();
        PKM.applyShootToReduceBulletDistribution();

        Firearms DP28 = new Firearms();
        DP28.applyShootToReduceBulletDistribution();

        Firearms S12k = new Firearms();
        S12k.applyShootToReduceBulletDistribution();
    }
}

class Firearms {
    void applyShootToReduceBulletDistribution() {
       
    }
}