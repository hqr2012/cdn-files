#pragma once
#include "Modules/ModuleManager.h"
class FASTHEADLOCKER_API FFastHeadLockerModule : public IModuleInterface {
public:
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;
};