import java.util.ArrayList;
import java.util.List;

class Vector2 {
    double x;
    double y;

    Vector2(double x, double y) {
        this.x = x;
        this.y = y;
    }
}

class Player {
    Vector2 position;

    Player(Vector2 position) {
        this.position = position;
    }
}

class Enemy {
    Vector2 position;

    Enemy(Vector2 position) {
        this.position = position;
    }
}

public class Main {
    public static Vector2 aimAtEnemy(Player player, Enemy enemy, double multiplier) {
        double aimX = player.position.x + (enemy.position.x - player.position.x) * multiplier;
        double aimY = player.position.y + (enemy.position.y - player.position.y) * multiplier;

        Vector2 aimPosition = new Vector2(aimX, aimY);

        if (aimPosition.x == enemy.position.x && aimPosition.y == enemy.position.y) {
            return aimAtEnemy(player, enemy, multiplier + 1);
        }

        return aimPosition;
    }

    public static void main(String[] args) {
        Player player = new Player(new Vector2(0, 0));

        List<Enemy> enemies = new ArrayList<>();
        enemies.add(new Enemy(new Vector2(10, 10)));
        enemies.add(new Enemy(new Vector2(5, 5)));
        enemies.add(new Enemy(new Vector2(8, 3)));

        double multiplier = 3.0;

        for (Enemy enemy : enemies) {
            Vector2 aimPosition = aimAtEnemy(player, enemy, multiplier);
            System.out.printf("Aiming at enemy: (%.2f, %.2f)\n", aimPosition.x, aimPosition.y);
        }
    }
}