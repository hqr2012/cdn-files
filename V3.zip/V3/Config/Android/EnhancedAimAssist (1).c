#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "EnhancedAimAssistGameInstance.generated.h"

UCLASS()
class YOURPROJECT_API UEnhancedAimAssistGameInstance : public UGameInstance
{
    GENERATED_BODY()

public:
    virtual void Init() override;

private:
    bool bEnableAimAssist;
    FString TargetType;
    bool bIgnoreSelf;
};

void UEnhancedAimAssistGameInstance::Init()
{
    Super::Init();

    // 读取配置文件
    FString ConfigPath = FPaths::ProjectConfigDir() + TEXT("EnhancedAimAssist.ini");
    TSharedPtr<IPlatformFile> PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
    if (PlatformFile->Exists(*ConfigPath))
    {
        FString FileContent;
        if (FFileHelper::LoadFileToString(FileContent, *ConfigPath))
        {
            IniParseSection(ConfigPath, "EnhancedAimAssist", FileContent);
        }
    }

    // 应用配置
    if (bEnableAimAssist)
    {
        // 启用增强瞄准辅助功能
        if (TargetType == "Head")
        {
            // 实现瞄准辅助功能，使准星吸附其他玩家的头部
        }
    }
}

bool UEnhancedAimAssistGameInstance::IniParseSection(const FString& FilePath, const FString& SectionName, const FString& Content)
{
    TArray<FString> Lines;
    Content.ParseIntoArray(Lines, TEXT("\n"), true);

    for (const FString& Line : Lines)
    {
        if (!Line.IsEmpty())
        {
            int32 EqualIndex = Line.Find(TEXT("="));
            if (EqualIndex != INDEX_NONE)
            {
                FString Key = Line.Mid(0, EqualIndex).Trim();
                FString Value = Line.Mid(EqualIndex + 1).Trim();

                if (Key.Equals("EnableAimAssist"))
                {
                    bEnableAimAssist = FCString::ToBool(Value);
                }
                else if (Key.Equals("TargetType"))
                {
                    TargetType = Value;
                }
                else if (Key.Equals("IgnoreSelf"))
                {
                    bIgnoreSelf = FCString::ToBool(Value);
                }
            }
        }
    }

    return true;
}