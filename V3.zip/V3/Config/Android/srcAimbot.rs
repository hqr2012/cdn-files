use crate::{config::Config, player::{Player, Camera}, enemy::Enemy};
use glam::Vec3;

pub struct LockingResult<'a> { pub shoot_pos: Vec3, pub target: &'a Enemy }

pub struct Aimbot { pub cfg: Config }
impl Aimbot {
    pub fn new(cfg: Config) -> Self { Self { cfg } }

    pub fn ads_mode<'a>(&self, player: &Player, cam: &Camera, enemies: &'a [Enemy]) -> Option<LockingResult<'a>> {
        self.lock_head(player, cam, enemies)
    }

    pub fn fire_mode<'a>(&self, player: &Player, cam: &Camera, enemies: &'a [Enemy]) -> Option<LockingResult<'a>> {
        self.lock_head(player, cam, enemies)
    }

    fn lock_head<'a>(&self, player: &Player, _cam: &Camera, enemies: &'a [Enemy]) -> Option<LockingResult<'a>> {
        enemies.iter()
            .min_by(|a, b| {
                let da = a.pos.distance(player.pos);
                let db = b.pos.distance(player.pos);
                da.partial_cmp(&db).unwrap()
            })
            .filter(|e| e.pos.distance(player.pos) < self.cfg.core.max_distance)
            .map(|t| LockingResult { shoot_pos: t.pos + Vec3::new(0.0, 1.6, 0.0), target: t })
    }
}