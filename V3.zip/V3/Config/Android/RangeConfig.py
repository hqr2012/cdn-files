class AutoFireRangeConfig:
    AUTO_FIRE_ENABLE = True          
    RANGE_EXPAND_ENABLE = True       
    RECOIL_COMPENSATE_ENABLE = True 
    FRIENDLY_FILTER_ENABLE = True    

    EXPAND_PIXEL = 12                
    ENABLE_RANGE_DECAY = True        
    DECAY_FACTOR = 0.2               
    MIN_EXPAND_PIXEL = 5             
    
    TRIGGER_MODE = 2             
    MIN_TRIGGER_DIST = 10.0          
    MAX_TRIGGER_DIST = 100.0        
    TARGET_LOCK_DELAY = 100          
    
    FIRE_INTERVAL = 55               
    MAX_CONTINUOUS_FIRE = 25   
    RECOIL_FACTOR = 0.5             
    SPREAD_COMPENSATE = 0.3          

    TARGET_TYPE = 1                 
    DETECT_SENSITIVITY = 80          