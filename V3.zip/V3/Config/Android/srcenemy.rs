use glam::Vec3;

pub struct Enemy { pub pos: Vec3, pub vel: Vec3, pub name: String }
impl Enemy {
    pub fn demo_vec() -> Vec<Self> {
        vec![
            Enemy { pos: Vec3::new(100.0, 0.0, 0.0), vel: Vec3::new(1.0, 0.0, 0.0), name: "Alpha".into() },
            Enemy { pos: Vec3::new(0.0, 100.0, 0.0), vel: Vec3::new(0.0, 1.0, 0.0), name: "Bravo".into() },
        ]
    }
    pub fn tick(&mut self) { self.pos += self.vel; }
}