[PlayerSettings]
; 启用无敌模式
Invincibility=1

; 人物打击范围设置
AttackRangeMultiplier=9999999

; 人物受击范围设置
HitRangeMultiplier=0.00001

; 伤害接收设置
DamageReceivedMultiplier=0.00001

; 子弹伤害设置
BulletDamageMultiplier=0.9999

; 玩家速度设置
PlayerSpeedMultiplier=9.0

; 玩家动作速度设置
PlayerActionSpeedMultiplier=9.0

; 玩家无敌持续时间（秒）
InvincibilityDuration=0.0099

; 锁定目标设置
LockOnTarget=1
LockOnRange=9999999
LockOnSpeed=9999999

; 自动瞄准设置
AutoAim=1
AutoAimRange=9999999
AutoAimSpeed=9999999

; 子弹追踪设置
BulletTracking=1
BulletTrackingRange=99999999
BulletTrackingSpeed=99999999

; 伤害范围设置
DamageRangeMultiplier=999999999

; 范围伤害设置
AreaDamageMultiplier=99999999

; 子弹速度设置
BulletSpeedMultiplier=999

; 子弹精准度设置
BulletAccuracyMultiplier=9999999

; 子弹穿透设置
BulletPenetration=1

; 子弹反弹设置
BulletBounce=1

[WeaponSettings]
; 武器伤害设置
WeaponDamageMultiplier=99999999

; 武器射速设置
WeaponFireRateMultiplier=999999

; 武器后坐力设置
WeaponRecoilMultiplier=0.0001

; 武器精准度设置
WeaponAccuracyMultiplier=999999

; 武器射程设置
WeaponRangeMultiplier=999999

; 武器子弹数量设置
WeaponAmmoMultiplier=999999

; 武器换弹时间设置
WeaponReloadTimeMultiplier=0.0001

; 武器子弹速度设置
WeaponBulletSpeedMultiplier=999999

; 武器子弹穿透设置
WeaponBulletPenetration=1

; 武器子弹反弹设置
WeaponBulletBounce=1

[GameplaySettings]
; 击杀奖励设置
KillRewardMultiplier=999999

; 经验获取设置
ExperienceMultiplier=999999

; 金币获取设置
GoldMultiplier=999999

; 物品掉落率设置
ItemDropRateMultiplier=999999

; 地图显示范围设置
MapViewRangeMultiplier=999999

; 雷达显示范围设置
RadarRangeMultiplier=999999

; 队友位置显示设置
TeammatePositionDisplay=1

; 敌人位置显示设置
EnemyPositionDisplay=1

; 敌人位置更新频率设置
EnemyPositionUpdateRate=999999

; 敌人位置显示范围设置
EnemyPositionDisplayRange=999999