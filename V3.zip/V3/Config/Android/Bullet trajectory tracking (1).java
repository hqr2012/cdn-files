{
  name: ["com.tencent.tmgp.pubgmhd"]
   <Function>"bullet tracking"</Function
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   <Numberofattacktargets>"99"
Gamescriptreadingfunction：{
"bullet tracking_FOV=360°×360=head"
"bullet tracking_FOV=360°×360°"
"bullet tracking_FOV360°×360head=MAX
"Bullet trajectory tracking_FOV=360°×360=head"
"Bullet trajectory tracking_FOV=360°×360°"
        "Bullet tracking doubled=MAX
        "Ballistic tracking doubled=MAX
        "Bullet trajectory tracking intensity=MAX
        "Bullet Range Tracking=MAX
        "Bullet Range Tracking=head
        "Gun firing range tracking=MAX
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=head
     "Bullet trajectory tracking = MAX
     "Bullet trajectory tracking = head
     "Bullet tracking hit rate=MAX
     "Bullet tracking hit area=MAX
          "Bullet tracking hit rate=MAX
     "Bullet trajectory tracking hit rate=MAX
     "Bullet tracking hit rate to the head=MAX
     "Bullet trajectory tracking hit head rate=MAX
          "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "The character moves bullets to track the enemy's head=MAX
     "Firearms fire to track character heads=MAX
     "Gun shooting range tracking character's head=MAX
     "Firearm tracking area=MAX
     "Bullet tracking area=MAX
     "Gun and bullet tracking=MAX
     "Bullet trajectory tracking hits character moving head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track and hit the character's head=MAX
     "Bullet automatic tracking moving character moving head=MAX
"Firearms fire, bullets automatically and extensively track the head=MAX
     "Bullet locked character head tracking=MAX
     "Bullet locks character's head=MAX
     "Fire to lock the character's head=MAX
     "Bullet target locking and tracking head=MAX
     "Target lock tracking character head=MAX
     "Bullet trajectory line dispersion reduces tracking head=MAX
          "Bullet impact area hit tracking head=MAX
     "Bullet head tracking head area=MAX
     "Bullets gather and hit the tracking head=MAX
     "Bullet area tracking character range=MAX
          "Head attracts bullets to hit=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Bullet Rifling Tracking Character's Head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms firing, bullets moving, characters moving, tracking heads=MAX
       "Bullet tracking head range=MAX
       "Bullet tracking hit head area=MAX
     "Bullet tracking area hit range=MAX
     "Bullet tracking area hits head range=MAX
     "Enlargethecharacter'shead=MAX
     "Firing bullets, locking and tracking enemy heads=MAX
     "Fire and lock the character's head=MAX
     "Bullet trajectory lock tracking hit head=MAX
     "Bullet trajectory locking hit head=MAX
     "Bullets automatically lock and track hits to the head=MAX
     "Bullet trajectory automatic locking tracking hits the head=MAX
     "Firearm firing range tracking hits character's head=MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Gun firing, bullet tracking speed=MAX
     "Firearm firing, bullet tracking head speed=MAX
     "Firing bullet tracking speed=MAX
                     }:"Successfullyread,executing"
GameProgress：{"com.tencent.tmgp.pubgmhd"}