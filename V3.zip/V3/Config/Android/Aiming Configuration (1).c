#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// 假设的API函数，获取玩家和敌人的位置
void getPlayerPosition(float *x, float *y, float *z);
void getEnemyPosition(float *x, float *y, float *z);
void setPlayerRotation(float yaw, float pitch);

// 读取INI文件
void readIniFile(const char *filename, float *damage, float *fireRate, float *range, float *ammo, int *lockOn, float *lockOnRange, float *lockOnSpeed) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Failed to open file: %s\n", filename);
        return;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        char *key = strtok(line, "=");
        char *value = strtok(NULL, "=");
        if (value != NULL) {
            value[strcspn(value, "\n")] = 0; // Remove newline character
            if (strcmp(key, "Damage") == 0) {
                *damage = atof(value);
            } else if (strcmp(key, "FireRate") == 0) {
                *fireRate = atof(value);
            } else if (strcmp(key, "Range") == 0) {
                *range = atof(value);
            } else if (strcmp(key, "Ammo") == 0) {
                *ammo = atof(value);
            } else if (strcmp(key, "LockOn") == 0) {
                *lockOn = atoi(value);
            } else if (strcmp(key, "LockOnRange") == 0) {
                *lockOnRange = atof(value);
            } else if (strcmp(key, "LockOnSpeed") == 0) {
                *lockOnSpeed = atof(value);
            }
        }
    }

    fclose(file);
}

// 计算两个点之间的方向向量
void calculateDirection(float x1, float y1, float z1, float x2, float y2, float z2, float *dx, float *dy, float *dz) {
    *dx = x2 - x1;
    *dy = y2 - y1;
    *dz = z2 - z1;
}

// 将方向向量转换为旋转角度
void directionToRotation(float dx, float dy, float dz, float *yaw, float *pitch) {
    *yaw = atan2(dx, dz) * (180.0 / M_PI); // Yaw (左右旋转)
    *pitch = atan2(dy, sqrt(dx * dx + dz * dz)) * (180.0 / M_PI); // Pitch (上下旋转)
}

// 主函数，实现强锁自瞄
void lockOnEnemy(float lockOnRange) {
    float playerX, playerY, playerZ;
    float enemyX, enemyY, enemyZ;
    float dx, dy, dz;
    float yaw, pitch;

    // 获取玩家和敌人的位置
    getPlayerPosition(&playerX, &playerY, &playerZ);
    getEnemyPosition(&enemyX, &enemyY, &enemyZ);

    // 计算方向向量
    calculateDirection(playerX, playerY, playerZ, enemyX, enemyY, enemyZ, &dx, &dy, &dz);

    // 将方向向量转换为旋转角度
    directionToRotation(dx, dy, dz, &yaw, &pitch);

    // 设置玩家的旋转角度
    setPlayerRotation(yaw, pitch);

    // 打印调试信息
    printf("Player Position: (%f, %f, %f)\n", playerX, playerY, playerZ);
    printf("Enemy Position: (%f, %f, %f)\n", enemyX, enemyY, enemyZ);
    printf("Yaw: %f, Pitch: %f\n", yaw, pitch);
}

int main() {
    float damage, fireRate, range, ammo;
    int lockOn;
    float lockOnRange, lockOnSpeed;

    // 读取INI文件
    readIniFile("weapon_config.ini", &damage, &fireRate, &range, &ammo, &lockOn, &lockOnRange, &lockOnSpeed);

    // 模拟游戏循环
    while (1) {
        if (lockOn) {
            lockOnEnemy(lockOnRange);
        }
        // 模拟游戏循环的延迟
        sleep(1);
    }
    return 0;
}