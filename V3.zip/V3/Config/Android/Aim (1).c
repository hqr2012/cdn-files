#include <aim>
#include <com.tencent.tmgp.pubgmhd>
#include uint unsigned int
#include uchar unsigned char
void main()
    {
ABullet::OnHitPlayer()
{
float BulletDamage = 0.0f;
    if (GConfig)
    {
        GConfig->GetFloat(TEXT("/Script/PUBG.MySettings"), TEXT("BulletDamage"), BulletDamage, GGameIni);
    }

    APlayerCharacter* HitPlayer = Cast<APlayerCharacter>(HitComponent->GetOwner());
    if (HitPlayer)
    {
        float CurrentPlayerHealth = 0.0f;
        if (GConfig)
        {
            GConfig->GetFloat(TEXT("/Script/PUBG.MySettings"), TEXT("PlayerHealth"), CurrentPlayerHealth, GGameIni);
        }
        CurrentPlayerHealth -= BulletDamage;

        GConfig->SetFloat(TEXT("/Script/PUBG.MySettings"), TEXT("PlayerHealth"), CurrentPlayerHealth, GGameIni);
if (CurrentPlayerHealth <= 0.0f)
        {
HitPlayer->Die();
        }
        else
        {
            int32 HitCount = 0;
            GConfig->GetInt(TEXT("/Script/PUBG.PUBGState"), TEXT("HitCount"), HitCount, GGameIni);
HitCount++;

            if (HitCount >= 2)
            {
HitPlayer->Die();
            }
            else
            {
                GConfig->SetInt(TEXT("/Script/PUBG.PUBGState"), TEXT("HitCount"), HitCount, GGameIni);
             }
         }
     }
  }
}