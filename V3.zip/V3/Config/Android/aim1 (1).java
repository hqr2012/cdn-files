import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class GamePanel extends JPanel {
    private Player player;
    private List<Enemy> enemies;
    private List<Bullet> bullets;

    public GamePanel(GameFrame frame) {
        player = new Player();
        enemies = new ArrayList<>();
        bullets = new ArrayList<>();
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                player.keyPressed(e);
            }
        });
        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        player.paint(g);
        for (Enemy enemy : enemies) {
            enemy.paint(g);
        }
        for (Bullet bullet : bullets) {
            bullet.paint(g);
        }
    }
}