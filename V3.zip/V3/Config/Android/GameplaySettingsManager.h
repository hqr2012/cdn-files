#pragma once

#include "CoreMinimal.h"
#include "GameplaySettingsStruct.h"
#include "GameplaySettingsManager.generated.h"

UCLASS()
class YOURGAME_API UGameplaySettingsManager : public UObject
{
    GENERATED_BODY()

public:
    static UGameplaySettingsManager* Get();

    void LoadSettings();

    const FGameplayGlobalSettings& GetGlobalSettings() const { return GlobalSettings; }

    const FWeaponConfig* GetWeaponConfig(const FString& WeaponSection) const;

private:
    void LoadGlobalSettings();
    void LoadWeaponConfig(const FString& SectionName, FWeaponConfig& OutConfig);

private:
    static UGameplaySettingsManager* Instance;

    FGameplayGlobalSettings GlobalSettings;
    TMap<FString, FWeaponConfig> WeaponConfigs;
};