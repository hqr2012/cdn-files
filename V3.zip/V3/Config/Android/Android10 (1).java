def create_sav_file(file_path):
    with open(file_path, 'wb') as file:
        data = b'和平精英数据\n安卓10\n增强效果\n'
        file.write(data)

    print("SAV文件已成功创建并写入内容鹤羽牛逼。")

if __name__ == "__main__":
    sav_file_path = "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav"
    create_sav_file(sav_file_path)