public class RangeConfig {
    public static final boolean AUTO_FIRE_ENABLE = true;      
    public static final boolean RANGE_EXPAND_ENABLE = true;    
    public static final boolean FRIENDLY_FILTER_ENABLE = true; 

    public static final int EXPAND_PIXEL = 12;                 
    public static final boolean RANGE_DECAY_ENABLE = true;     
    public static final float DECAY_FACTOR = 0.2f;          
    public static final int MIN_EXPAND_PIXEL = 5;              

    public static final int TRIGGER_MODE = 2;                  
    public static final float MIN_TRIGGER_DIST = 30.0f;        
    public static final float MAX_TRIGGER_DIST = 900.0f;      
    public static final int TARGET_LOCK_DELAY = 100;           

    public static final int FIRE_INTERVAL = 55;               
    public static final int MAX_CONTINUOUS_FIRE = 25;     
    public static final float RECOIL_COMPENSATE = 0.5f;      
    public static final float SPREAD_COMPENSATE = 0.3f;      

    public static final int TARGET_TYPE = 1;                   
    public static final int DETECT_SENSITIVITY = 80;    
}
