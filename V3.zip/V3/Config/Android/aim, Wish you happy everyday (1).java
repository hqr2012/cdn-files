import java.awt.Point;

public class Autoaim {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Autoaim");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.RED);
                g.fillOval(150, 150, 50, 50);
            }
        };

        panel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                double distance = Math.sqrt(Math.pow(x - 200, 2) + Math.pow(y - 200, 2));
                if (distance <= 75) {
                    System.out.println("Aimed at the target");
                } else {
                    panel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                }
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }
}