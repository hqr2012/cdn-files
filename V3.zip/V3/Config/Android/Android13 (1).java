import java.io.*;
import java.util.*;

public class FileModifier {

    public static void main(String[] args) {
        String iniFilePath = "path/to/your/file.ini";
        String savFilePath = "path/to/your/file.sav";

        // 调用方法修改INI文件
        modifyIniFile(iniFilePath);

        // 调用方法修改SAV文件
        modifySavFile(savFilePath);
    }

    public static void modifyIniFile(String filePath) {
        try {
            List<String> lines = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                // 在这里添加自定义的修改逻辑
                if (line.contains("someSetting")) {
                    line = "someSetting=newValue"; // 修改某个设置
                }
                lines.add(line);
            }
            reader.close();

            // 写回修改后的内容
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            for (String modifiedLine : lines) {
                writer.write(modifiedLine);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void modifySavFile(String filePath) {
        // 假设SAV文件是二进制文件，进行简单的读写操作
        try {
            RandomAccessFile raf = new RandomAccessFile(filePath, "rw");
            raf.seek(0); // 定位到文件开头
            byte[] data = new byte[4]; // 读取4个字节
            raf.read(data);
            // 在这里添加对SAV文件的处理逻辑
            raf.seek(0); // 回到开头
            raf.write(new byte[]{0x01, 0x02, 0x03, 0x04}); // 写入修改后的数据
            raf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}