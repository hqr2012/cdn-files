#include "EditorUtilityWidget.h"
#include "LevelEditor.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

static void AddToolbarButton(FToolBarBuilder& Builder) {
    Builder.AddToolButton(
        FUIAction(FExecuteAction::CreateLambda([]() {
            FVector Aim;
            if (FHeadLocker::Get().TryLock(
                    GEditor->GetEditorWorldContext().World()->GetFirstPlayerController()->PlayerCameraManager->GetCameraLocation(),
                    GEditor->GetEditorWorldContext().World()->GetFirstPlayerController()->PlayerCameraManager->GetCameraRotation(),
                    Aim)) {
                UE_LOG(LogTemp, Warning, TEXT("Locked Head: %s"), *Aim.ToString());
            }
        })),
        NAME_None,
        FText::FromString("LockHead"),
        FText::FromString("One-click headshot"),
        FSlateIcon()
    );
}

void FFastHeadLockerModule::StartupModule() {
    FLevelEditorModule& LevelModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
    TSharedPtr<FExtender> ToolbarExtender = MakeShareable(new FExtender);
    ToolbarExtender->AddToolBarExtension("Settings", EExtensionHook::After, nullptr,
        FToolBarExtensionDelegate::CreateStatic(&AddToolbarButton));
    LevelModule.GetToolBarExtensibilityManager()->AddExtender(ToolbarExtender);
}

void FFastHeadLockerModule::ShutdownModule() {}