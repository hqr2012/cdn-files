{
   "Bullet tracking head":{
      "Speed":"Lock",
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Bullet Range Tracking":"360°×360°"
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Character tracking":"360°×360°"
   }
}
{
   "Bullet tracking range":{
      "Bullet hit area tracking area":"Lock",
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Static tracking"",":"360°×360°"
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Bullet Range Tracking":"360°×360°"
   }
}