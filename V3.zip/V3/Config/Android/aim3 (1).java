import java.util.Base64;

public class Base64Decoder {
    public static void main(String[] args) {
        String base64Encoded = "你的Base64编码内容";
        byte[] decodedBytes = Base64.getDecoder().decode(base64Encoded);
        String decodedString = new String(decodedBytes);

        System.out.println("解码后的JSON内容：");
        System.out.println(decodedString);
    }
}