import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class INIReader {
    public static void main(String[] args) {
        String directoryPath = "/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/"; 
        
        Map<String, Map<String, String>> iniData = readAllINIFiles(directoryPath);
        
       
        for (String fileName : iniData.keySet()) {
            System.out.println("INI file: " + fileName);
            System.out.println("------------------------");
            
            Map<String, String> sectionData = iniData.get(fileName);
            for (String sectionName : sectionData.keySet()) {
                String value = sectionData.get(sectionName);
                System.out.println(sectionName + " = " + value);
            }
            
            System.out.println("------------------------\n");
        }
    }

    public static Map<String, Map<String, String>> readAllINIFiles(String directoryPath) {
        Map<String, Map<String, String>> iniData = new HashMap<>();

        File directory = new File(directoryPath);
        if (!directory.isDirectory()) {
            System.err.println("Invalid directory path: " + directoryPath);
            return iniData;
        }

        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".ini")) {
                    Map<String, String> fileData = readINIFile(file);
                    iniData.put(file.getName(), fileData);
                }
            }
        }

        return iniData;
    }

    public static Map<String, String> readINIFile(File file) {
        Map<String, String> data = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file)))) {

            String section = null;
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.isEmpty() || line.startsWith(";")) {
                    continue;  
                }

                if (line.startsWith("[")) {
                    section = line.substring(1, line.indexOf("]"));
                    continue;
                }

                int equalsIndex = line.indexOf("=");
                String key = line.substring(0, equalsIndex);
                String value = line.substring(equalsIndex + 1);
                data.put(section + "." + key, value);
            }

        } catch (IOException e) {
            System.err.println("Failed to read INI file: " + file.getName());
        }

        return data;
    }
}