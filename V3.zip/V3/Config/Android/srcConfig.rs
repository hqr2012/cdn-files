use serde::Deserialize;
use std::fs;

#[derive(Debug, Deserialize)]
pub struct Config { pub core: Core, pub mode: Mode }
#[derive(Debug, Deserialize)]
pub struct Core { pub aim_bone: String, pub max_distance: f32, pub lock_on_delay_ms: u64, pub fire_delay_ms: u64, pub smooth_factor: f32, pub fov: f32 }
#[derive(Debug, Deserialize)]
pub struct Mode { pub auto_fire_when_aim_down_sight: bool, pub auto_fire_on_trigger: bool }

pub fn load(path: &str) -> Result<Config, Box<dyn std::error::Error>> {
    Ok(toml::from_str(&fs::read_to_string(path)?)?)
}