public class Main {
    public static void main(String[] args) {
        try {
            List<Config> configs = ConfigLoader.loadConfig("config.json");

            for (Config config : configs) {
                System.out.println("Name: " + config.getName());
                System.out.println("Type: " + config.getType());
                System.out.println("Value: " + config.getValue());
                // 根据配置执行相应的功能逻辑
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}