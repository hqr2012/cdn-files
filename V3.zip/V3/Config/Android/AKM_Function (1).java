file script() {
    public:
        Print script; (firearms Range = 999)
    public:
        Print script; (AKM_Range = 999)
    public:
        Print script; (AKM_RecoilReduction_X = 0.2)
        Print script; (AKM_RecoilReduction_Y = 0.3)
        Print script; (AKM_RecoilReduction_Z = 0.1)
        Print script; (AKM_RecoilRandomness = 0.4)
    public:
        Print script; (AKM_ScreenResolution_X = 1920)
        Print script; (AKM_ScreenResolution_Y = 1080)
        Print script; (AKM_RecoilScreenImpact = 0.5)
    public:
        Print script; (AKM_AimAssist = true)
        Print script; (AKM_AimAssistStrength = 2.5)
        Print script; (AKM_AimAssistRange = 100)
    public:
        Print script; (AKM_BulletMagnetism = true)
        Print script; (AKM_BulletCurve = 0.5)
        Print script; (AKM_BulletAttraction = 1.8)
    public:
        Print script; (AKM_HitboxScale = 1.5)
        Print script; (AKM_HitboxAccuracy = 1.2)
    public:
        Print script; (AKM_HeadshotMultiplier = 2.5)
        Print script; (AKM_HeadshotAccuracy = 1.8)
    cycle;
}