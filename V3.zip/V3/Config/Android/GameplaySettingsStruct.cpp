#include "GameplaySettingsManager.h"
#include "Misc/ConfigCacheIni.h"
#include "Engine/Engine.h"

UGameplaySettingsManager* UGameplaySettingsManager::Instance = nullptr;

UGameplaySettingsManager* UGameplaySettingsManager::Get()
{
    if (!Instance)
    {
        Instance = NewObject<UGameplaySettingsManager>();
        Instance->AddToRoot();
        Instance->LoadSettings();
    }
    return Instance;
}

void UGameplaySettingsManager::LoadSettings()
{
    LoadGlobalSettings();

    WeaponConfigs.Empty();

    TArray<FString> WeaponSections = {
        "Weapon_M416_Base", "Weapon_M416_RedDot", "Weapon_M416_Holo", "Weapon_M416_ACOG",
        "Weapon_M416_Suppressor", "Weapon_M416_FlashHider", "Weapon_M416_Grip_Vertical",
        "Weapon_M416_Grip_Angled", "Weapon_M416_ExtendedMag", "Weapon_M416_DrumMag",
        "Weapon_AKM_Base", "Weapon_AKM_RedDot", "Weapon_AKM_Holo", "Weapon_AKM_ACOG",
        "Weapon_AKM_Suppressor", "Weapon_AKM_FlashHider", "Weapon_AKM_Grip_Vertical",
        "Weapon_AKM_Grip_Angled", "Weapon_AKM_ExtendedMag", "Weapon_AUG_Base",
        "Weapon_AUG_RedDot", "Weapon_AUG_Holo", "Weapon_AUG_ACOG", "Weapon_AUG_Suppressor",
        "Weapon_AUG_ExtendedMag", "Weapon_MK14_Base", "Weapon_MK14_ACOG", "Weapon_MK14_SniperScope",
        "Weapon_MK14_Suppressor", "Weapon_P90_Base", "Weapon_P90_RedDot", "Weapon_P90_Holo",
        "Weapon_P90_ACOG", "Weapon_P90_ExtendedMag", "Weapon_SCARL_Base", "Weapon_M16A4_Base",
        "Weapon_Vector_Base", "Weapon_UMP45_Base", "Weapon_BerylM762_Base", "Weapon_Groza_Base",
        "Weapon_DP28_Base", "Weapon_Sickle_Base", "Weapon_Pan_Base", "Weapon_M24_Base",
        "Weapon_AWM_Base", "Weapon_VSS_Base", "Weapon_QBZ_Base", "Weapon_QBU_Base",
        "Weapon_mini14_Base", "Weapon_SKS_Base", "Weapon_Win94_Base", "Weapon_Nagant_Base",
        "Weapon_R1895_Base", "Weapon_Sawnoff_Base", "Weapon_DoubleBarrel_Base", "Weapon_Mk14_EBR",
        "Weapon_AKM_Chinese", "Weapon_M416_Tactical", "Weapon_AUG_Pro", "Weapon_P90_Turbo",
        "Weapon_Groza_S", "Weapon_DP28_Heavy"
    };

    for (const FString& Section : WeaponSections)
    {
        FWeaponConfig Config;
        LoadWeaponConfig(Section, Config);
        WeaponConfigs.Add(Section, Config);
    }

    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Green, TEXT("Gameplay Settings Loaded!"));
    }
}

void UGameplaySettingsManager::LoadGlobalSettings()
{
    const FString ConfigSection = TEXT("General");
    GConfig->GetBool(*ConfigSection, TEXT("bEnableAimAssist"), GlobalSettings.bEnableAimAssist, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("AimAssistStrength"), GlobalSettings.AimAssistStrength, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("AimAssistMaxAngle"), GlobalSettings.AimAssistMaxAngle, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("AimAssistSmoothTime"), GlobalSettings.AimAssistSmoothTime, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bEnableHitboxExpansion"), GlobalSettings.bEnableHitboxExpansion, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("HitboxScaleMultiplier"), GlobalSettings.HitboxScaleMultiplier, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bEnableMagicBullet"), GlobalSettings.bEnableMagicBullet, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("MagicBulletTurnRate"), GlobalSettings.MagicBulletTurnRate, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("MagicBulletMaxTurnAngle"), GlobalSettings.MagicBulletMaxTurnAngle, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("MagicBulletLifetime"), GlobalSettings.MagicBulletLifetime, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bIncreaseHeadshotRate"), GlobalSettings.bIncreaseHeadshotRate, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("HeadshotBonusMultiplier"), GlobalSettings.HeadshotBonusMultiplier, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bReduceBulletSpread"), GlobalSettings.bReduceBulletSpread, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("BulletSpreadReductionFactor"), GlobalSettings.BulletSpreadReductionFactor, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bDisableRecoil"), GlobalSettings.bDisableRecoil, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("RecoilMultiplier"), GlobalSettings.RecoilMultiplier, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bEnableAutoAimPrediction"), GlobalSettings.bEnableAutoAimPrediction, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("PredictionTime"), GlobalSettings.PredictionTime, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("MaxPredictionDistance"), GlobalSettings.MaxPredictionDistance, GGameIni);

    GConfig->GetBool(*ConfigSection, TEXT("bStickyAim"), GlobalSettings.bStickyAim, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("StickyAimPower"), GlobalSettings.StickyAimPower, GGameIni);
    GConfig->GetFloat(*ConfigSection, TEXT("StickyAimRange"), GlobalSettings.StickyAimRange, GGameIni);
}

void UGameplaySettingsManager::LoadWeaponConfig(const FString& SectionName, FWeaponConfig& OutConfig)
{
    GConfig->GetFloat(*SectionName, TEXT("FireRate"), OutConfig.FireRate, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("DamagePerBullet"), OutConfig.DamagePerBullet, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("BulletSpeed"), OutConfig.BulletSpeed, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("RecoilVertical"), OutConfig.RecoilVertical, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("RecoilHorizontal"), OutConfig.RecoilHorizontal, GGameIni);
    GConfig->GetInt(*SectionName, TEXT("MagazineSize"), OutConfig.MagazineSize, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("AimDownSightTime"), OutConfig.AimDownSightTime, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("HipFireSpread"), OutConfig.HipFireSpread, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("ADSZoom"), OutConfig.ADSZoom, GGameIni);
    GConfig->GetBool(*SectionName, TEXT("bFullAuto"), OutConfig.bFullAuto, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("BulletDrop"), OutConfig.BulletDrop, GGameIni);
    GConfig->GetFloat(*SectionName, TEXT("PenetrationPower"), OutConfig.PenetrationPower, GGameIni);
    GConfig->GetBool(*SectionName, TEXT("bBurstMode"), OutConfig.bBurstMode, GGameIni);
    GConfig->GetInt(*SectionName, TEXT("BurstCount"), OutConfig.BurstCount, GGameIni);
}

const FWeaponConfig* UGameplaySettingsManager::GetWeaponConfig(const FString& WeaponSection) const
{
    return WeaponConfigs.Find(WeaponSection);
}