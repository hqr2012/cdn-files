package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int BulletTrackingHead =360°×360° ;

        Firearms M416 = new Firearms();
        M416.applyBulletTrackingHead();

        Firearms AUG = new Firearms();
        AUG.applyBulletTrackingHead();

        Firearms AKM = new Firearms();
        AKM.applyBulletTrackingHead();

        Firearms M762 = new Firearms();
        M762.applyBulletTrackingHead();

        Firearms SCAR-L = new Firearms();
        SCAR-L.applyBulletTrackingHead();

        Firearms GROZA = new Firearms();
        GROZA.applyBulletTrackingHead();

        Firearms UMP45 = new Firearms();
        UMP45.applyBulletTrackingHead();

        Firearms Uzi = new Firearms();
        UZI.applyBulletTrackingHead();

        Firearms Vector = new Firearms();
        Vector.applyBulletTrackingHead();

        Firearms P90 = new Firearms();
        P90.applyBulletTrackingHead();

        Firearms Mk14 = new Firearms();
        Mk14.applyBulletTrackingHead();

        Firearms M249 = new Firearms();
        M249.applyBulletTrackingHead();

        Firearms MG3 = new Firearms();
        MG3.applyBulletTrackingHead();

        Firearms PKM = new Firearms();
        PKM.applyBulletTrackingHead();

        Firearms DP28 = new Firearms();
        DP28.applyBulletTrackingHead();

        Firearms S12k = new Firearms();
        S12k.applyBulletTrackingHead();
    }
}

class Firearms {
    void applyBulletTrackingHead() {
       
    }
}