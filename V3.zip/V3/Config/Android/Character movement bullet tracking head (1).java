{
   "Gun and bullet hit range tracking head":{
      "Character movement bullet tracking head"："locking"
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Bullet tracking head"",":"360°×360°"
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Bullet tracking head":"360°×360°"
   }