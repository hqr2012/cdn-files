public class Config {
    private String name;
    private String type;
    private double value;

    // Getters and Setters
    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public double getValue() {
        return value;
    }
}