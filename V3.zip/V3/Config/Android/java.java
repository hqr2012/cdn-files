public class ADSpeedManager {
    private float baseADSSpeed = 1.2f;
    private float sniperADSSpeed = 0.8f;
    private float shotgunADSSpeed = 1.5f;
    private float smgADSSpeed = 1.4f;
    private float arADSSpeed = 1.3f;
    private float pistolADSSpeed = 1.6f;
    private float meleeADSSpeed = 2.0f;
    private float movePenalty = 0.7f;
    private float crouchBoost = 1.1f;
    private float proneBoost = 1.2f;
    private float maxADSSpeed = 2.5f;
    private float minADSSpeed = 0.5f;

    public float getFinalADSSpeed(String weaponType, String playerState) {
        float adsSpeed = baseADSSpeed;
        switch (weaponType.toLowerCase()) {
            case "sniper":
                adsSpeed = sniperADSSpeed;
                break;
            case "shotgun":
                adsSpeed = shotgunADSSpeed;
                break;
            case "smg":
                adsSpeed = smgADSSpeed;
                break;
            case "assaultrifle":
                adsSpeed = arADSSpeed;
                break;
            case "pistol":
                adsSpeed = pistolADSSpeed;
                break;
            case "melee":
                adsSpeed = meleeADSSpeed;
                break;
        }
        switch (playerState.toLowerCase()) {
            case "moving":
                adsSpeed *= movePenalty;
                break;
            case "crouching":
                adsSpeed *= crouchBoost;
                break;
            case "prone":
                adsSpeed *= proneBoost;
                break;
        }
        return Math.max(minADSSpeed, Math.min(adsSpeed, maxADSSpeed));
    }

    public void setBaseADSSpeed(float speed) {
        this.baseADSSpeed = speed;
    }

    public void setWeaponADSSpeed(String weaponType, float speed) {
        switch (weaponType.toLowerCase()) {
            case "sniper":
                this.sniperADSSpeed = speed;
                break;
            case "shotgun":
                this.shotgunADSSpeed = speed;
                break;
            case "smg":
                this.smgADSSpeed = speed;
                break;
            case "assaultrifle":
                this.arADSSpeed = speed;
                break;
            case "pistol":
                this.pistolADSSpeed = speed;
                break;
            case "melee":
                this.meleeADSSpeed = speed;
                break;
        }
    }
}
