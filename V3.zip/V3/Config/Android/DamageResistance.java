public DamageResistance() {
    prefs = Preferences.userRoot().node(NODE_PATH);
    loadDefaultSettings();
}

private void loadDefaultSettings() {
    if (prefs.get("DamageReduction", null) == null) {
        prefs.putInt("DamageReduction", 1);
        prefs.putInt("ReductionPercentage", 30);
        prefs.putInt("HeadshotProtection", 1);
        prefs.putInt("HeadshotReduction", 50);
        prefs.putInt("ChestProtection", 1);
        prefs.putInt("ChestReduction", 40);
        prefs.putInt("LimbProtection", 1);
        prefs.putInt("LimbReduction", 25);
        prefs.putInt("BackProtection", 1);
        prefs.putInt("BackReduction", 35);
        prefs.putInt("FallDamageReduce", 1);
        prefs.putInt("FallReduction", 60);
        prefs.putInt("ExplosionResist", 1);
        prefs.putInt("ExplosionReduction", 45);
        prefs.putInt("BleedResist", 1);
        prefs.putInt("BleedReduction", 70);
        prefs.putInt("StaggerResist", 1);
        prefs.putInt("StaggerReduction", 80);
        prefs.putInt("TempHealthBoost", 1);
        prefs.putInt("HealthBoostAmount", 20);
        prefs.putInt("ShieldEnhance", 1);
        prefs.putInt("ShieldCapacity", 120);
        prefs.putFloat("RegenRate", 2.5f);
        prefs.putFloat("RegenDelay", 3.0f);
        prefs.putInt("AutoMedkit", 1);
        prefs.putInt("MedkitThreshold", 40);
        prefs.putInt("OneHitProtection", 1);
        prefs.putInt("OHPHealth", 10);
        prefs.putInt("OHPCooldown", 60);
        prefs.putInt("TeamDamageBlock", 1);
        prefs.putInt("FriendlyFireBlock", 1);
    }
}

public float calculateDamageReduction(int damage, String hitZone, boolean isExplosive, boolean isHeadshot) {
    if (prefs.getInt("DamageReduction", 0) == 0) return damage;
    
    int baseReduction = prefs.getInt("ReductionPercentage", 30);
    int zoneReduction = 0;
    
    if (isHeadshot && prefs.getInt("HeadshotProtection", 0) == 1) {
        zoneReduction = prefs.getInt("HeadshotReduction", 50);
    } else if ("chest".equals(hitZone) && prefs.getInt("ChestProtection", 0) == 1) {
        zoneReduction = prefs.getInt("ChestReduction", 40);
    } else if ("limb".equals(hitZone) && prefs.getInt("LimbProtection", 0) == 1) {
        zoneReduction = prefs.getInt("LimbReduction", 25);
    } else if ("back".equals(hitZone) && prefs.getInt("BackProtection", 0) == 1) {
        zoneReduction = prefs.getInt("BackReduction", 35);
    }
    
    if (isExplosive && prefs.getInt("ExplosionResist", 0) == 1) {
        zoneReduction = Math.max(zoneReduction, prefs.getInt("ExplosionReduction", 45));
    }
    
    int totalReduction = Math.min(baseReduction + zoneReduction, 95);
    return damage * (100 - totalReduction) / 100f;
}

public int getHealthBoost() {
    return prefs.getInt("TempHealthBoost", 0) == 1 ? prefs.getInt("HealthBoostAmount", 20) : 0;
}

public int getShieldCapacity() {
    return prefs.getInt("ShieldEnhance", 0) == 1 ? prefs.getInt("ShieldCapacity", 120) : 100;
}

public boolean shouldUseMedkit(int currentHealth) {
    return prefs.getInt("AutoMedkit", 0) == 1 && currentHealth <= prefs.getInt("MedkitThreshold", 40);
}

public boolean isOneHitProtected(int currentHealth) {
    return prefs.getInt("OneHitProtection", 0) == 1 && currentHealth > prefs.getInt("OHPHealth", 10);
}

public boolean blockFriendlyFire() {
    return prefs.getInt("FriendlyFireBlock", 0) == 1;
}

public void updateSetting(String key, int value) {
    prefs.putInt(key, value);
}

public void updateSetting(String key, float value) {
    prefs.putFloat(key, value);
}

public int getIntSetting(String key) {
    return prefs.getInt(key, 0);
}

public float getFloatSetting(String key) {
    return prefs.getFloat(key, 0f);
}