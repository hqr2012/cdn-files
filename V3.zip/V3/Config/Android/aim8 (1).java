import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter config file path: ");
        String filePath = scanner.nextLine();

        try {
            List<Config> configs = ConfigLoader.loadConfig(filePath);

            for (Config config : configs) {
                logger.log(Level.INFO, "Name: {0}", config.getName());
                logger.log(Level.INFO, "Type: {0}", config.getType());
                logger.log(Level.INFO, "Value: {0}", config.getValue());
                // 根据配置执行相应的功能逻辑
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error loading config file", e);
        } finally {
            scanner.close();
        }
    }
}