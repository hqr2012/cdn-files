{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   while true
do
do
        int bulletTrackTracking = 999;
        int bulletTracking = 999;
        int Bullettrackingintensity = 999;
        int firearmsFiringBulletsTrackingHead = 999;
        int Bullettrajectorytrackinghead=999;
        int characterMovementBulletTrackingHead = 999;
        int automaticHeadTrackingOfFirearmsFiringBullets = 999;
        int firingBulletsAutomaticallyTrackHead = 999;
        "bullet tracking_FOV=360°×360=head"
"bullet tracking_FOV=360°×360°"
"Bullet tracking intensity=MAX
        "Bullet tracking intensity"："MAX"
"bullet tracking"："MAX"
"Gun Bullet Tracking"："MAX"
"Bullet Tracking"："MAX"
"Bullet trajectory tracking"："MAX"
"Automatic tracking of character bullet trajectory "："MAX"
"Gun firing, bullets automatically tracking the head"："MAX"
"Automatic tracking head for firearms and bullets"："MAX"
"The bullet automatically hits the character's head"："MAX"
"Bullet trajectory tracking hits the head"："MAX"
"Bullet warhead tracking head：MAX
"Firearm firing, bullet tracking area"："MAX"
"Firearms firing, bullets tracking character's head"："MAX"
"Gun bullets automatically hit the head"："MAX"
"Firearms firing, bullets tracking the head"："MAX"
"The character moves bullets to track the enemy's head"："MAX"
"Head attracts bullets to hit：MAX
"Bullet hit the head"："MAX"
"Gun bullets hit the head：MAX
"Bullets automatically track enemy heads"："MAX"
"Gun Bullet Tracking Head"："MAX"
"Guns and bullets tracking character heads"："MAX"
"Character moving bullet tracking head"："MAX"
"Bullet trajectory tracking character's head"："MAX"
"Bullet Rifling Tracking Character's Head"："MAX"
"Bullet trajectory tracking hits the character's head"："MAX"
"All firearms and bullets hit the tracking head=MAX
"Bullet tracking hit character range=MAX
"Gun bullets greatly enhance tracking effectiveness=MAX
"All firearms and bullets hit the tracking head=MAX
"Tracking hit area=MAX
"Bullet tracking hit character range=MAX
"Bullet detection head tracking=MAX
"Firearms fire, bullets automatically track the head=MAX
"Bullet tracking of character's head=MAX
   }:"execute"
             <Java>