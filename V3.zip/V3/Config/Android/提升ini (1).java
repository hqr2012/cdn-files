package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int AimBotLockHead = 99.99;

        Firearms M416 = new Firearms();
        M416.applyAimBotLockHead();

        Firearms AUG = new Firearms();
        AUG.applyAimBotLockHead();

        Firearms AKM = new Firearms();
        AKM.applyAimBotLockHead();

        Firearms M762 = new Firearms();
        M762.applyAimBotLockHead();

        Firearms SCAR-L = new Firearms();
        SCAR-L.applyAimBotLockHead();

        Firearms GROZA = new Firearms();
        GROZA.applyAimBotLockHead();

        Firearms UMP45 = new Firearms();
        UMP45.applyAimBotLockHead();

        Firearms Uzi = new Firearms();
        UZI.applyAimBotLockHead();

        Firearms Vector = new Firearms();
        Vector.applyAimBotLockHead();

        Firearms P90 = new Firearms();
        P90.applyAimBotLockHead();

        Firearms Mk14 = new Firearms();
        Mk14.applyAimBotLockHead();

        Firearms M249 = new Firearms();
        M249.applyAimBotLockHead();

        Firearms MG3 = new Firearms();
        MG3.applyAimBotLockHead();

        Firearms PKM = new Firearms();
        PKM.applyAimBotLockHead();

        Firearms DP28 = new Firearms();
        DP28.applyAimBotLockHead();

        Firearms S12k = new Firearms();
        S12k.applyAimBotLockHead();
    }
}

class Firearms {
    void applyAimBotLockHead() {
       
    }
}