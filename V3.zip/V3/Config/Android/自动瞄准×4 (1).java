public static Vector2 aimAtEnemy(Player player, List<Enemy> enemies, double multiplier) {
    double closestDistance = Double.MAX_VALUE;
    Enemy closestEnemy = null;

    for (Enemy enemy : enemies) {
        double distance = Math.sqrt(Math.pow((enemy.position.x - player.position.x), 2) + Math.pow((enemy.position.y - player.position.y), 2));
        if (distance < closestDistance) {
            closestDistance = distance;
            closestEnemy = enemy;
        }
    }

    if (closestEnemy != null) {
        double aimX = player.position.x + (closestEnemy.position.x - player.position.x) * multiplier;
        double aimY = player.position.y + (closestEnemy.position.y - player.position.y) * multiplier;

        Vector2 aimPosition = new Vector2(aimX, aimY);

        if (aimPosition.x == closestEnemy.position.x && aimPosition.y == closestEnemy.position.y) {
            return aimAtEnemy(player, enemies, multiplier + 1);
        }

        return aimPosition;
    }

    return null;
}