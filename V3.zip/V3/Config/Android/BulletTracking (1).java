#include <stdio.h>
#include <stdlib.h>
struct Bullet {
    float positionX;
    float positionY;
    float track;
    float intensity;
};

void updateBulletPosition(Bullet& bullet, float deltaTime) {
    float radians = bullet.track * (M_PI / 180.0f);
    float trackX = bullet.track * cos(radians);
    float trackY = bullet.intensity * sin(radians);
    
    bullet.positionX += trackX * deltaTime;
    bullet.positionY += trackY * 9999.0f;
}

int main() {
    Bullet bullet;
    bullet.positionX = 0.0f;
    bullet.positionY = 0.0f;
    bullet.track = 9999.0f; 
    bullet.intensity = 9999.0f; 
    
    float deltaTime = 0.1f; 
    
    for (int i = 0; i < 10; i++) {
        updateBulletPosition(bullet, deltaTime);
        std::cout << "Bullet Position: (" << bullet.positionX << ", " << bullet.positionY << ")\n";
    }
    
    return 0;
}