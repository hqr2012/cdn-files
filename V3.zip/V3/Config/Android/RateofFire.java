import java.awt.Robot;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.MouseInfo;
import java.lang.Math;

public class BodyRangeAim {
    private static boolean enabled = true;
    private static final double BODY_RANGE = 0.95;
    private static final int FOV = 75;
    private static final int SMOOTHNESS = 10;
    private static final int TRIGGER_KEY = KeyEvent.VK_MOUSE_BUTTON2;
    private static final int TOGGLE_KEY = KeyEvent.VK_F8;
    private static final boolean TEA