public class PlayerDamageResistance {
    private float baseResistance = 0.3f;
    private float headshotResistance = 0.15f;
    private float torsoResistance = 0.35f;
    private float limbsResistance = 0.45f;
    private float bulletResistance = 0.3f;
    private float explosionResistance = 0.2f;
    private float fireResistance = 0.5f;
    private float meleeResistance = 0.6f;
    private float fallingResistance = 0.8f;
    private float poisonResistance = 0.4f;
    private float vehicleResistance = 0.25f;
    private float teamDamageResistance = 1.0f;
    private float selfDamageResistance = 1.0f;
    private float crouchBoost = 0.1f;
    private float proneBoost = 0.15f;
    private float shieldBonus = 0.25f;
    private float perkBonus = 0.2f;
    private float maxResistance = 0.8f;
    private float minResistance = 0.05f;

    public float calculateFinalDamage(float rawDamage, String damageType, String hit部位, String playerState, boolean isTeamDamage, boolean isSelfDamage, boolean hasShield, boolean hasPerk) {
        if (isTeamDamage) {
            return rawDamage * (1 - teamDamageResistance);
        }
        if (isSelfDamage) {
            return rawDamage * (1 - selfDamageResistance);
        }

        float resistance = baseResistance;
        switch (hit部位.toLowerCase()) {
            case "head":
                resistance = headshotResistance;
                break;
            case "torso":
                resistance = torsoResistance;
                break;
            case "limbs":
                resistance = limbsResistance;
                break;
        }

        switch (damageType.toLowerCase()) {
            case "bullet":
                resistance += bulletResistance;
                break;
            case "explosion":
                resistance += explosionResistance;
                break;
            case "fire":
                resistance += fireResistance;
                break;
            case "melee":
                resistance += meleeResistance;
                break;
            case "falling":
                resistance += fallingResistance;
                break;
            case "poison":
                resistance += poisonResistance;
                break;
            case "vehicle":
                resistance += vehicleResistance;
                break;
        }

        if (playerState.equalsIgnoreCase("crouching")) {
            resistance += crouchBoost;
        } else if (playerState.equalsIgnoreCase("prone")) {
            resistance += proneBoost;
        }

        if (hasShield) {
            resistance += shieldBonus;
        }
        if (hasPerk) {
            resistance += perkBonus;
        }

        resistance = Math.max(minResistance, Math.min(resistance, maxResistance));
        return rawDamage * (1 - resistance);
    }

    public void setBaseResistance(float value) {
        this.baseResistance = Math.max(minResistance, Math.min(value, maxResistance));
    }

    public void setDamageTypeResistance(String damageType, float value) {
        float clampedValue = Math.max(minResistance, Math.min(value, maxResistance));
        switch (damageType.toLowerCase()) {
            case "bullet":
                this.bulletResistance = clampedValue;
                break;
            case "explosion":
                this.explosionResistance = clampedValue;
                break;
            case "fire":
                this.fireResistance = clampedValue;
                break;
            case "melee":
                this.meleeResistance = clampedValue;
                break;
        }
    }
}
