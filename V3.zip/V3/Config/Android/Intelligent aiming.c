#include <Model aiming>
#define uint unsigned int
#define uchar unsigned char
'sbit m'='Model data';

unsigned uchar code model1code[]={0xA3 0xCE 0x13 0x1C 0xF3 0xA9 0xD7 0xFF
0xD9 0x2A 0x71 0xF1 0x53 0xF0 0x5E 0xB8 
0x9A 0x09 0x6B 0xD2 0x1D 0xE3 0x09 0x04 
0x8D 0x27 0xBF 0xA6 0x3C 0xCF 0x35 0x5D 
0x21 0x8C 0x84 0x89 0x03 0xF6 0x67 0xC9 
0x00
};
void main()
{
Instruction=model1code[1];
Instruction=model1code[2];Instruction=model1code[3];Instruction=model1code[4];Instruction=model1code[5];Instruction=model1code[6];Instruction=model1code[7];Instruction=model1code[8];Instruction=model1code[9];Instruction=model1code[10];Instruction=model1code[11];Instruction=model1code[12];Instruction=model1code[13];Instruction=model1code[14];Instruction=model1code[15];Instruction=model1code[16];Instruction=model1code[17];Instruction=model1code[18];Instruction=model1code[19];Instruction=model1code[20];Instruction=model1code[21];Instruction=model1code[22];Instruction=model1code[23];Instruction=model1code[24];Instruction=model1code[25];Instruction=model1code[26];Instruction=model1code[27];Instruction=model1code[28];Instruction=model1code[29];Instruction=model1code[30];Instruction=model1code[31];Instruction=model1code[32];Instruction=model1code[33];Instruction=model1code[34];Instruction=model1code[35];Instruction=model1code[36];Instruction=model1code[37];Instruction=model1code[38];Instruction=model1code[39];Instruction=model1code[40];Instruction=model1code[41];Instruction=model1code[42];Instruction=model1code[43];Instruction=model1code[44];Instruction=model1code[45];
}