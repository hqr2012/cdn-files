{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <Function>"bullet tracking"</Function
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=MAX
     "Bullet Tracking = MAX
     "Bullet trajectory tracking = MAX
     "Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
          "Bullet automatic tracking of moving character's head=MAX
     "The bullet automatically chases the character's head=MAX
     "Bullet tracking target=head
     "Bullet tracking head target=MAX
     "Firing bullets tracking the target's head=MAX
                    "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "The character moves bullets to track the enemy's head=MAX
     "Head attracts bullets to hit=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Bullets automatically track enemy heads=MAX
     "Gun Bullet Tracking Head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Character head tracking=MAX
                     }:"execute"
             <Java>