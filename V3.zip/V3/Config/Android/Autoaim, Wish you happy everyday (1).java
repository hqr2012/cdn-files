import java.awt.Point;

public class AutoAim {
    private Point enemyPosition = new Point(100, 100);

    private Point characterPosition = new Point(50, 50);

    private int range = 20;

    public boolean isInRange() {
        int distance = (int) Math.sqrt(Math.pow(enemyPosition.x - characterPosition.x, 2) + Math.pow(enemyPosition.y - characterPosition.y, 2));
        return distance <= range;
    }

    public void aimAtEnemy() {
        if (isInRange()) {
            System.out.println("Enemy is in range, start targeting...");
        } else {
            System.out.println("The enemy is out of range and cannot be targeted.");
        }
    }

    public static void main(String[] args) {
        AutoAim autoAim = new AutoAim();
        autoAim.aimAtEnemy();
    }
}
