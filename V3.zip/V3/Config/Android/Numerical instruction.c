#include <Instruction>
#define uint unsigned int
#define uchar unsigned char
void ys(int x)
{char i;
   for(;x>0;x--)
   {
   for(i=0;i<100;i++);
   }
}
void main()
   {
{
'uchar' Select Doomed Character Instruction=a,i;
'a'>>=1;
}
    {
"Specify File":Hardware.ini;
"Specify File":Scalability.ini;
"Specify File":ServerSwitch.ini;
"Specify File":UserCustom.ini;
}
{
"Directive file generation root directory":/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/
    }
}