.CSS
<body>
@import "Bulletdamage";
</head>
.Damage::BulletTrackingDamage {
    BulletTrackDamage: 9999999;
    PlayerMoveBulletTrackDamage: 9999999;
    BulletTrackBodyDamage: 9999999;
}