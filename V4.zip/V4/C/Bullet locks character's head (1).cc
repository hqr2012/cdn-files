{
 name:["com.tencent.tmgp.pubgmhd"]
    
 GameReadFileName<CC>
  <DOCTYPE CC>
 <CC>
   <target>"Head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   <charactermovementmodel>
<head>
      <configuration file="(bullettracking) Head" :enlarge="head">
    </cycle>
      <public>

<attack>
    <script>
        def attack = new attack(self, target):
            damage = self.strength;{
   target.defense};
           def data:{
                name:'attack';
                enemy:automatic{
                  numberofpeople:99,
                  Attackfunction:"bullet tracking"
                  attackstrength："9999"
                }
            },
            :{
               public add script(){
                    Print(Bullet','tracking;'Finish','correct');
                    Print(Guntrackingheadattack;'Finish','correct')
                }
            }
        })
     </script>
 </head>
    name: ["Automatic tracking", "CC"]
    AddFunctionScript: [
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=MAX
     "Bullet Tracking = MAX
     "Bullet trajectory tracking = MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "The character moves bullets to track the enemy's head=MAX
     "Head attracts bullets to hit=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Bullet Rifling Tracking Character's Head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track character heads=MAX
     "Gun shooting range tracking character's head=MAX
     "Firearm tracking area=MAX
     "Bullet tracking area=MAX
     "Gun and bullet tracking=MAX
     "Gun and bullet tracking area=head
     "Bullet tracking on the character's head=MAX
          "Firearms firing, bullets moving, characters moving, tracking heads=MAX
     "Bullet locked character head tracking=MAX
     "Bullet locks character's head=MAX
     "Fire to lock the character's head=MAX
     "Bullet target locking and tracking head=MAX
     "Target lock tracking character head=MAX
]：Successfullyread,executing

GameReadingData:["com.tencent.tmgp.pubgmhd"]