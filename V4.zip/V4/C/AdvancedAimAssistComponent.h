#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AdvancedAimAssistComponent.generated.h"

UENUM(BlueprintType)
enum class EAimAssistMode : uint8
{
    Silent,     
    Standard,  
    Aggressive  
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UAdvancedAimAssistComponent : public UActorComponent
{
    GENERATED_BODY()

public:    
    UAdvancedAimAssistComponent();

protected:
    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
    void AntiDetectionMeasures();
    void RandomizeBehavior();
    void SimulateHumanInput(FRotator& TargetRotation);
    class ACharacter* FindBestTarget() const;
    TArray<class ACharacter*> GetAllValidTargets() const;
    bool IsValidTarget(class ACharacter* Target) const;
    float CalculateAimSmoothness() const;
    FVector CalculatePredictedPosition(class ACharacter* Target) const;
    float GetTargetPriority(class ACharacter* Target) const;
    void UpdateMapSpecificSettings();
    float GetCurrentMapVisibilityRange() const;
    UPROPERTY(EditAnywhere, Category = "和平精英|自瞄")
    EAimAssistMode AimMode = EAimAssistMode::Silent;
    UPROPERTY(EditAnywhere, Category = "和平精英|自瞄", meta=(ClampMin="0.1", ClampMax="2.0"))
    float BaseAimStrength = 0.8f;
    float LastAimTime = 0.0f;
    float NextRandomDelay = 0.0f;
    FRotator LastHumanInput;
    float HumanInputSimulationTimer = 0.0f;
    UPROPERTY()
    TMap<FString, float> MapVisibilityRanges;
    APlayerController* GetPlayerController() const;
    ACharacter* GetPlayerCharacter() const;
};