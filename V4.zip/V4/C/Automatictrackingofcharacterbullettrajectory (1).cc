{
 name:["com.tencent.tmgp.pubgmhd"]
    
 GameReadFileName<CC>
  <DOCTYPE CC>
 <CC>
   <target>"Head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   <charactermovementmodel>
<head>
   <application function="com.tencent.tmgp.pubgmhd">
      <configuration file="(bullettracking) Head" :enlarge="Hithead"></head>
      while true
do
done
    </cycle>
      <public>

<attack>
    <script>
        def attack = new attack(self, target):
            damage = self.strength;{
   target.defense};
           def data:{
                name:'attack';
                enemy:automatic{
                  numberofpeople:99,
                }
            },
            :{
               public add script(){
                    Print(Bullet','tracking;'Finish','correct');
                    Print(attack;'Finish','correct')
                }
            }
        })
     </script>
 </head>
    name: ["Automatic tracking", "CC"]
    set "AllOfTheAboveRnjected[com.tencent.tmgp.pubgmhd]"
    AddFunctionScript: [
               int Bullettrackingintensity = 9999;
int Automatictrackingofbulletsontheheadduringcharactermovement= 9999;
       BallisticTrackingOfFirearmsAndBullets = 9999;
        int Firearmfiringbullettrajectorytrackinghead=9999;
        int Movethecharacter,firethegun,determinethelock,andtrackthehead = 9999;
        int Bullettrackingdistance = 9999;
"bullet tracking_FOV=360°×360=head"
"bullet tracking_FOV=360°×360°"
"bullet tracking_FOV360°×360head=MAX
        "Ballistic tracking doubled=MAX
        "Bullet trajectory tracking intensity=MAX
        "Bullet Range Tracking=MAX
                "Bullet Range Tracking=head
     "Target lock tracking character head=MAX
     "Bullet trajectory line dispersion reduces tracking head=MAX
          "Bullet impact area hit tracking head=MAX
     "Bullet head tracking head area=MAX
     "Bullets gather and hit the tracking head=MAX
     "Bullet area tracking character range=MAX
          "Head attracts bullets to hit=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
          "Firing bullets, locking and tracking enemy heads=MAX
     "Fire and lock the character's head=MAX
            "Bullet tracking head range=MAX
       "Bullet tracking hit head area=MAX
     "Bullet tracking area hit range=MAX
     "Bullet tracking area hits head range=MAX
     "Enlargethecharacter'shead=MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
"Firearms fire to track character heads=MAX
     "Gun shooting range tracking character's head=MAX
     "Firearm tracking area=MAX
             "Gun firing range tracking=MAX
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=head
     "Bullet trajectory tracking = MAX
     "Bullet trajectory tracking = head
     BulletTracking=true
"Bullet tracking part=head
"Bullet tracking player=MAX
"Bullet tracking character body=MAX
"Character standing triggers bullet tracking=MAX
"The character holds a firearm and bullets automatically track the enemy's head =MAX
"Bullet hits enemy head tracking range=MAX
"Head bullet tracking=true
"Character gun bullets track the enemy's head =MAX
"The character's standing state triggers bullet tracking=MAX
"The bullet tracks the enemy's head=MAX
"Bullets trace the enemy's body=MAX
"Tracking enemy body range=MAX
"The character's crouching state triggers enemy bullet tracking=MAX
"The enemy's standing state triggers character bullet tracking=MAX
"When the character is standing, bullets are triggered to track the enemy=MAX
"Bullet tracking trigger probability=MAX
"The character holding a gun triggers enemy bullet tracking=MAX
"Character bullets track the enemy's head=MAX
"Bullet tracking character body switch=true
"The enemy's head hit range=MAX
"bullet tracking_FOV=360°×360°"
"Bullet tracking character head area=MAX
"The tracked area of ​​​​the character's head=MAX
"The hit area on the character's head=MAX
"Character holding firearm bullet tracking area=MAX
"Character bullet tracking trigger part=head
"Bullet trajectory=true
"Bullet trajectory part=head
"Bullet trajectory head=MAX
"The bullet trajectory of the character holding a firearm triggers=MAX
"Bullet tracking on the character's head=MAX
"Character moving firearms firing bullets tracking head=MAX
"Automatic tracking of characters' heads by firearms and bullets=MAX
"Character moves firearms, fires bullets, automatically tracks hits to the head=MAX
"Bullet trajectory tracking hits character moving head=MAX
"Bullet trajectory tracking hits the character's head=MAX
"Firearms fire to track and hit the character's head=MAX
"Bullet automatic tracking moving character moving head=MAX
          "Bullet tracking hit rate=MAX
     "Bullet trajectory tracking hit rate=MAX
     "Bullet tracking hit rate to the head=MAX
     "Bullet trajectory lock tracking hit head=MAX
     "Gun firing speed trackin=MAX
     "Firearms fire, bullets automatically and extensively track the head=MAX
     "Firearms fired, all hit and track the head=MAX
}
    {FileReading：<"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/>"}
<CC>
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}

set AllOfTheAboveRnjected[com.tencent.tmgp.pubgmhd]
TheRollowingInjectionPackagename=[com.tencent.tmgp.pubgmhd]     

GameReadingData:["com.tencent.tmgp.pubgmhd"]