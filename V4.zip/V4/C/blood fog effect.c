#include <com.tencent.tmgp.sgame>
  #bloodfogeffect
    #head
     #import C.kind
public script()
{
    printf("Magnify the blood fog special effect");
    printf("blood fog effect; \100");enlarge
    Effect 100; 
}
#Print
 #cycle