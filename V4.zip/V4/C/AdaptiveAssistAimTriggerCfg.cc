```cpp
#include <iostream>
#include <string>
#include <unordered_map>

// 定义一个结构体来存储所有相关参数
struct AssistAimSettings {
    // AssistAimGeneral
    bool enableAssistAim;
    float cooldownTime;

    // AssistAimTriggerFrequencySettings
    float baseTriggerProbability;
    float closeRangeTriggerBoostFactor;
    float closeRangeThreshold;
    float slowEnemyTriggerBoostFactor;
    float slowEnemySpeedThreshold;
    float continuousHitsTriggerBoostFactor;
    int continuousHitsThreshold;
    float jumpingEnemyTriggerBoostFactor;
    float crouchingEnemyTriggerReductionFactor;
    float playerRunningTriggerReductionFactor;
    float playerStationaryTriggerBoostFactor;
    float lowHealthEnemyTriggerBoostFactor;
    float lowHealthEnemyThreshold;
    float climbingEnemyTriggerAdjustFactor;
    float vehicleEnemyTriggerAdjustFactor;
    float decoyPropTriggerAdjustFactor;
    float binocularsPropTriggerBoostFactor;
    float slidingEnemyTriggerAdjustFactor;
    float swimmingEnemyTriggerAdjustFactor;
    float medicalPropTriggerAdjustFactor;
    float speedUpPropTriggerAdjustFactor;

    // EnvironmentalInfluenceOnTriggerFrequency
    float nightEnvironmentTriggerFactor;
    float smokeEnvironmentTriggerReductionFactor;
    float underwaterEnvironmentTriggerReductionFactor;
    float sandstormEnvironmentTriggerReductionFactor;
    float thunderstormEnvironmentTriggerFactor;
    float foggyEnvironmentTriggerReductionFactor;
    float snowyEnvironmentTriggerFactor;
    float volcanicAreaTriggerReductionFactor;
    float auroraAreaTriggerFactor;
    float acidRainAreaTriggerReductionFactor;
    float poisonGasAreaTriggerReductionFactor;
    float brightLightAreaTriggerFactor;
    float darkMatterAreaTriggerReductionFactor;

    // WeaponInfluenceOnTriggerFrequency
    float sniperRifleTriggerAdjustFactor;
    float submachineGunTriggerAdjustFactor;
    float shotgunTriggerAdjustFactor;
    float assaultRifleTriggerAdjustFactor;
    float machineGunTriggerAdjustFactor;
    float energyWeaponTriggerAdjustFactor;
    float grenadeLauncherTriggerAdjustFactor;
    float crossbowTriggerAdjustFactor;
    float flamethrowerTriggerAdjustFactor;
    float taserTriggerAdjustFactor;
    float railgunTriggerAdjustFactor;
    float signalGunTriggerAdjustFactor;
    float anestheticGunTriggerAdjustFactor;
    float rocketLauncherTriggerAdjustFactor;

    // VisualFeedbackForTrigger
    bool triggerVisualHintEnable;
    float triggerVisualHintBlinkFrequency;
    float multipleTriggersBlinkBoostFactor;
    int multipleTriggersThreshold;
    int lostTargetSpecialBlinkCount;
    bool eliteEnemySpecialBlinkStyle;
    float largeBossTargetBlinkDurationFactor;
    bool invincibleTargetBlinkColorMode;

    // CharacterLevelInfluence
    float levelTriggerBoostCoefficient;
    int initialPlayerLevel;
    int currentPlayerLevel;
    float specificLevelTriggerBoostFactor;
    int specificLevel;
    float maxLevelTriggerBoostFactor;
    int maxPlayerLevel;
    float levelIntervalTriggerBoostCoefficient;
    int levelInterval;

    // TeamInfluenceOnTriggerFrequency
    float teammateNearbyTriggerBoostFactor;
    float teammateInfluenceRadius;
    float enemyTeamMarkedTriggerBoostFactor;
    float teammateReconSkillTriggerBoostFactor;
    float injuredTeammateTriggerReductionFactor;
    float teammateHealSkillTriggerBoostFactor;
    float teammateDefenseSkillTriggerAdjustFactor;

    // EnemyGroupInfluence
    float enemyGroupTriggerBoostFactor;
    int enemyGroupThreshold;
    float specialFormationTriggerBoostFactor;
    float enemyAirUnitTriggerBoostFactor;
    float defensiveFormationTriggerBoostFactor;
    float offensiveFormationTriggerBoostFactor;
    float largeEnemyGroupTriggerBoostFactor;
    int largeEnemyGroupThreshold;
};

// 初始化函数
void InitializeAssistAimSettings(AssistAimSettings& settings) {
    // AssistAimGeneral
    settings.enableAssistAim = true;
    settings.cooldownTime = 1.0f;

    // AssistAimTriggerFrequencySettings
    settings.baseTriggerProbability = 0.6f;
    settings.closeRangeTriggerBoostFactor = 1.3f;
    settings.closeRangeThreshold = 15.0f;
    settings.slowEnemyTriggerBoostFactor = 1.2f;
    settings.slowEnemySpeedThreshold = 8.0f;
    settings.continuousHitsTriggerBoostFactor = 1.4f;
    settings.continuousHitsThreshold = 3;
    settings.jumpingEnemyTriggerBoostFactor = 1.1f;
    settings.crouchingEnemyTriggerReductionFactor = 0.9f;
    settings.playerRunningTriggerReductionFactor = 0.8f;
    settings.playerStationaryTriggerBoostFactor = 1.1f;
    settings.lowHealthEnemyTriggerBoostFactor = 1.3f;
    settings.lowHealthEnemyThreshold = 0.3f;
    settings.climbingEnemyTriggerAdjustFactor = 0.8f;
    settings.vehicleEnemyTriggerAdjustFactor = 0.9f;
    settings.decoyPropTriggerAdjustFactor = 0.7f;
    settings.binocularsPropTriggerBoostFactor = 1.2f;
    settings.slidingEnemyTriggerAdjustFactor = 0.8f;
    settings.swimmingEnemyTriggerAdjustFactor = 0.7f;
    settings.medicalPropTriggerAdjustFactor = 0.9f;
    settings.speedUpPropTriggerAdjustFactor = 1.1f;

    // EnvironmentalInfluenceOnTriggerFrequency
    settings.nightEnvironmentTriggerFactor = 0.8f;
    settings.smokeEnvironmentTriggerReductionFactor = 0.6f;
    settings.underwaterEnvironmentTriggerReductionFactor = 0.7f;
    settings.sandstormEnvironmentTriggerReductionFactor = 0.7f;
    settings.thunderstormEnvironmentTriggerFactor = 0.9f;
    settings.foggyEnvironmentTriggerReductionFactor = 0.7f;
    settings.snowyEnvironmentTriggerFactor = 0.8f;
    settings.volcanicAreaTriggerReductionFactor = 0.6f;
    settings.auroraAreaTriggerFactor = 1.1f;
    settings.acidRainAreaTriggerReductionFactor = 0.7f;
    settings.poisonGasAreaTriggerReductionFactor = 0.6f;
    settings.brightLightAreaTriggerFactor = 1.05f;
    settings.darkMatterAreaTriggerReductionFactor = 0.7f;

    // WeaponInfluenceOnTriggerFrequency
    settings.sniperRifleTriggerAdjustFactor = 0.9f;
    settings.submachineGunTriggerAdjustFactor = 1.1f;
    settings.shotgunTriggerAdjustFactor = 1.2f;
    settings.assaultRifleTriggerAdjustFactor = 1.05f;
    settings.machineGunTriggerAdjustFactor = 1.15f;
    settings.energyWeaponTriggerAdjustFactor = 1.2f;
    settings.grenadeLauncherTriggerAdjustFactor = 0.8f;
    settings.crossbowTriggerAdjustFactor = 0.9f;
    settings.flamethrowerTriggerAdjustFactor = 0.8f;
    settings.taserTriggerAdjustFactor = 0.7f;
    settings.railgunTriggerAdjustFactor = 1.3f;
    settings.signalGunTriggerAdjustFactor = 0.7f;
    settings.anestheticGunTriggerAdjustFactor = 0.8f;
    settings.rocketLauncherTriggerAdjustFactor = 1.1f;

    // VisualFeedbackForTrigger
    settings.triggerVisualHintEnable = true;
    settings.triggerVisualHintBlinkFrequency = 1.5f;
    settings.multipleTriggersBlinkBoostFactor = 1.2f;
    settings.multipleTriggersThreshold = 3;
    settings.lostTargetSpecialBlinkCount = 5;
    settings.eliteEnemySpecialBlinkStyle = true;
    settings.largeBossTargetBlinkDurationFactor = 1.3f;
    settings.invincibleTargetBlinkColorMode = true;

    // CharacterLevelInfluence
    settings.levelTriggerBoostCoefficient = 0.01f;
    settings.initialPlayerLevel = 1;
    settings.currentPlayerLevel = 1;
    settings.specificLevelTriggerBoostFactor = 1.2f;
    settings.specificLevel = 20;
    settings.maxLevelTriggerBoostFactor = 1.5f;
    settings.maxPlayerLevel = 50;
    settings.levelIntervalTriggerBoostCoefficient = 0.05f;
    settings.levelInterval = 5;

    // TeamInfluenceOnTriggerFrequency
    settings.teammateNearbyTriggerBoostFactor = 1.1f;
    settings.teammateInfluenceRadius = 20.0f;
    settings.enemyTeamMarkedTriggerBoostFactor = 1.2f;
    settings.teammateReconSkillTriggerBoostFactor = 1.3f;
    settings.injuredTeammateTriggerReductionFactor = 0.8f;
    settings.teammateHealSkillTriggerBoostFactor = 1.2f;
    settings.teammateDefenseSkillTriggerAdjustFactor = 1.1f;

    // EnemyGroupInfluence
    settings.enemyGroupTriggerBoostFactor = 1.1f;
    settings.enemyGroupThreshold = 3;