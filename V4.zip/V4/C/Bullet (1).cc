#include <stdio.h>

// 子弹结构体
typedef struct {
    float x; // 子弹的x坐标
    float y; // 子弹的y坐标
    float velocity; // 子弹的速度
    float direction; // 子弹的方向（角度）
} Bullet;

void updateBulletPosition(Bullet *bullet, float deltaTime) {
    // 根据速度和方向更新子弹的位置
    bullet->x += bullet->velocity * deltaTime * cos(bullet->direction);
    bullet->y += bullet->velocity * deltaTime * sin(bullet->direction);
}

int main() {
    Bullet bullet;
    bullet.x = 0.0;
    bullet.y = 0.0;
    bullet.velocity = 100.0;
    bullet.direction = M_PI / 4; // 45度角
    
    float deltaTime = 0.1; // 时间步长
    
    for (int i = 0; i < 10; i++) {
        updateBulletPosition(&bullet, deltaTime);
        printf("Bullet position: (%f,%f)\n", bullet.x, bullet.y);
    }
    
    return 0;
}