{
 name:["com.tencent.tmgp.pubgmhd"]
    
 GameReadFileName<CC>
  <DOCTYPE CC>
 <CC>
   <target>"Head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
      Bullet Tracking="True"
   "Ballistic Tracking Head"
    bullettrace="head"
    ballistic-tracking-head="90.0"
    Gun Shot Tracking="True"
   Bullet Tracking = 99.0f
 (bullet Tracking Area Settings{
    "Minimum bullet tracking area=20.9
        "Maximum bullet tracking area=99.9)
}
{
     "Gun firing tracking=MAX
     "Bullet tracking=MAX
     "Tracking the trajectory of firearms and bullets=MAX
     "Gun warhead trajectory tracking=MAX
     "Bullet tracking=Head
     "Bullet trajectory tracking=head
     "GunBulletLandingPoint=Head
     "BulletTrackingArea=MAX
     "BulletAutomaticTrackingRange=MAX
     "BulletWalkingAreaTracking=MAX
     "BulletTraceRange=MAX
     "BulletAutomaticallyLandsOnTheHead=MAX
     "BulletAutomaticTrackingRange=MAX
     "BulletBallisticDispersionArea=-40%
     "Bullet automatically tracks the head=MAX
     "Bullet trajectory automatic tracking of characters=MAX
     "Automatic tracking of characters by bullet warheads=MAX
     "Automatic head tracking of firearms and bullets=MAX
     "Automatic bullet tracking head=MAX
     "Bullet trajectory automatic tracking head=MAX
     "Bullet warhead tracking head=MAX
     "AutomaticTrackingOfFirearmsAndBulletsWithinTheRangeOfThe=MAX
     "AutomaticTrackingOfFiringBullets=MAX
     "FiringBulletTracking=MAX
     "FirearmFiringTrackingArea=MAX
     "GunTrackingHeadRange=MAX
     "Tracking area of firearms and bullets=MAX
     "GunFiringBulletTracking=MAX
     "GunFiringBulletTrackingHeadRate=MAX
      "GunTracking=MAX
     "GunFiringBulletAreaTracking=MAX
     "CharacterMovementTrackingHead=MAX
     "TheCharacterStopsMovingAndTracksTheHead=MAX
     "AutomaticHeadTrackingOfFirearmsAndBullets=MAX
     "FirearmsFireBulletsAutomaticallyTrackThe=MAX
     "AutomaticHeadTrackingOfFiringBullets=MAX
     "Firearms fire, bullets automatically track the head=MAX
     "Automatic tracking head for firearms and bullets=MAX
     "Firing bullets automatically lock the head=MAX
     "Automatic tracking of characters' heads by firearms and bullets=MAX
     "Automatic bullet tracking and head hit during character movement=MAX
     "Bullet tracking the head while the character is moving=MAX
}
    {FileReading：<"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/>"}
<CC>
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}

GameReadingData:["com.tencent.tmgp.pubgmhd"]