{
 name:["com.tencent.tmgp.pubgmhd"]
    
 GameReadFileName<CC>
  <DOCTYPE CC>
 <CC>
   <target>"Head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   <charactermovementmodel>
<head>
   <application function="com.tencent.ig">
      <configuration file="(bullettracking) Head" :enlarge="Hithead"></head>
    </cycle>
      <public>

<attack>
    <script>
        def attack = new attack(self, target):
            damage = self.strength;{
   target.defense};
           def data:{
                name:'attack';
                enemy:automatic{
                  numberofpeople:99,
                }
            },
            :{
               public add script(){
                    Print(Bullet','tracking;'Finish','correct');
                    Print(attack;'Finish','correct')
                }
            }
        })
     </script>
 </head>
    name: ["Automatic tracking", "CC"]
    AddFunctionScript: [
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=MAX
     "Bullet Tracking = MAX
     "Bullet trajectory tracking = MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "The character moves bullets to track the enemy's head=MAX
     "Head attracts bullets to hit=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Bullets automatically track enemy heads=MAX
     "Gun Bullet Tracking Head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Bullet Rifling Tracking Character's Head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track character heads=MAX
     "Gun shooting range tracking character's head=MAX
     "Firearm tracking area=MAX
     "Bullet tracking area=MAX
     "Gun and bullet tracking=MAX
     "Gun and bullet tracking area=head
     "Character moves firearms, fires bullets, and tracks the head=MAX
     "Character moving bullet trajectory tracking head=MAX
     "Character moves bullets and warheads to track the head=MAX
     "Character moves firearms, fires bullets, and tracks the head=MAX
     "Automatic tracking of character's head by moving bullets=MAX
     "Automatic tracking of character's head with moving firearms and firing bullets=MAX
     "Character head tracking=MAX
     "Bullet tracking on the character's head=MAX
     "Character moving firearms firing bullets tracking head=MAX
     "Automatic tracking of characters' heads by firearms and bullets=MAX
     "Character moves firearms, fires bullets, automatically tracks hits to the head=MAX
     "Bullet trajectory tracking hits character moving head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track and hit the character's head=MAX
     "Bullet automatic tracking moving character moving head=MAX
     "Bullet automatic tracking of moving character's head=MAX
     "The bullet automatically chases the character's head=MAX
          "Bullet tracking target=head
     "Bullet tracking head target=MAX
]：[completionofenforcement]
    {FileReading：<"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/>"}
       <application function="com.tencent.ig">
       <"Hithead">
<CC>
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}

GameReadingData:["com.tencent.tmgp.pubgmhd"]