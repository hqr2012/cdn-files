#include <stdio.h>
{
int main():
    Aim head == "lock":
        print("Body")
    Other:
        print("Lockbody")
    shot head == "body"
        print("Lock")
}