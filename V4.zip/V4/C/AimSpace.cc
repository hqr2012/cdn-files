#include <iostream>
#include <string>

// 定义一个结构体用于表示不同武器类型的瞄准辅助加成
struct WeaponAimAssistBonuses {
    int rifleBonus;
    int sniperRifleBonus;
    int submachineGunBonus;
    int shotgunBonus;
};

// 定义一个结构体用于表示不同场景的瞄准辅助范围系数
struct ScenarioAimAssistCoefficients {
    double indoorBattle;
    double outdoorBattle;
    double longRangeShooting;
    double closeRangeCombat;
};

// 定义一个类用于表示瞄准辅助设置
class AimAssistSettings {
public:
    // 基础瞄准辅助设置
    int aimAssistGeneralSwitch;
    int aimAssistRangeWhenNotFiring;
    int aimAssistRangeIncreaseMultipleWhenFiring;

    // 其他相关瞄准辅助设置
    int aimAssistSensitivity;
    int autoLockTarget;
    double aimAssistAndWeaponRecoilCorrelation;
    int aimAssistEffectiveDistance;
    int firstPersonAimAssist;
    int thirdPersonAimAssist;

    // 不同武器类型的瞄准辅助加成
    WeaponAimAssistBonuses weaponBonuses;

    // 不同场景的瞄准辅助范围系数
    ScenarioAimAssistCoefficients scenarioCoefficients;

    // 构造函数
    AimAssistSettings() {
        // 初始化基础瞄准辅助设置
        aimAssistGeneralSwitch = 1;
        aimAssistRangeWhenNotFiring = 50;
        aimAssistRangeIncreaseMultipleWhenFiring = 10;

        // 初始化其他相关瞄准辅助设置
        aimAssistSensitivity = 70;
        autoLockTarget = 0;
        aimAssistAndWeaponRecoilCorrelation = 0.4;
        aimAssistEffectiveDistance = 150;
        firstPersonAimAssist = 1;
        thirdPersonAimAssist = 1;

        // 初始化不同武器类型的瞄准辅助加成
        weaponBonuses.rifleBonus = 20;
        weaponBonuses.sniperRifleBonus = 30;
        weaponBonuses.submachineGunBonus = 15;
        weaponBonuses.shotgunBonus = 10;

        // 初始化不同场景的瞄准辅助范围系数
        scenarioCoefficients.indoorBattle = 1.2;
        scenarioCoefficients.outdoorBattle = 0.8;
        scenarioCoefficients.longRangeShooting = 1.5;
        scenarioCoefficients.closeRangeCombat = 0.6;
    }

    // 打印设置函数
    void printSettings() const {
        std::cout << "Aim Assist General Switch: " << aimAssistGeneralSwitch << std::endl;
        std::cout << "Aim Assist Range When Not Firing: " << aimAssistRangeWhenNotFiring << std::endl;
        std::cout << "Aim Assist Range Increase Multiple When Firing: " << aimAssistRangeIncreaseMultipleWhenFiring << std::endl;
        std::cout << "Aim Assist Sensitivity: " << aimAssistSensitivity << std::endl;
        std::cout << "Auto-lock Target: " << autoLockTarget << std::endl;
        std::cout << "Aim Assist and Weapon Recoil Correlation: " << aimAssistAndWeaponRecoilCorrelation << std::endl;
        std::cout << "Aim Assist Effective Distance: " << aimAssistEffectiveDistance << std::endl;
        std::cout << "First-person Aim Assist: " << firstPersonAimAssist << std::endl;
        std::cout << "Third-person Aim Assist: " << thirdPersonAimAssist << std::endl;
        std::cout << "Rifle Aim Assist Bonus: " << weaponBonuses.rifleBonus << std::endl;
        std::cout << "Sniper Rifle Aim Assist Bonus: " << weaponBonuses.sniperRifleBonus << std::endl;
        std::cout << "Submachine Gun Aim Assist Bonus: " << weaponBonuses.submachineGunBonus << std::endl;
        std::cout << "Shotgun Aim Assist Bonus: " << weaponBonuses.shotgunBonus << std::endl;
        std::cout << "Indoor Battle Aim Assist Range Coefficient: " << scenarioCoefficients.indoorBattle << std::endl;
        std::cout << "Outdoor Battle Aim Assist Range Coefficient: " << scenarioCoefficients.outdoorBattle << std::endl;
        std::cout << "Long-range Shooting Aim Assist Range Coefficient: " << scenarioCoefficients.longRangeShooting << std::endl;
        std::cout << "Close-range Combat Aim Assist Range Coefficient: " << scenarioCoefficients.closeRangeCombat << std::endl;
    }
};

int main() {
    // 创建一个AimAssistSettings对象
    AimAssistSettings settings;

    // 打印设置
    settings.printSettings();

    return 0;
}