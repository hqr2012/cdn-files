{
 Name: ["com.tencent.tmgp.pubgmhd"]
    
 Game read filename <CC>
  <document type CC>
 <cc>
   <target>"head"</target>
   <execute> com.tencent.tmgp.pubgmhd <"execute">
{
   Bullet Tracking="True"
   "Ballistic Tracking Head"
    bullettrace="head"
    ballistic-tracking-head="90.0"
  Bullet Tracking Head Intensity="99.0F
    Gun Shot Tracking="True"
   Bullet Tracking = 99.0f
 (bullet Tracking Area Settings{
    "Minimum bullet tracking area=20.9
        "Maximum bullet tracking area=99.9)
}
   "tracking range = max
   "GunAndBulletTracking=MAX
"BallisticTrackingOfFirearmsAndBullets=MAX
   "GunBulletLandingPoint=Head
   "Bullet Tracking Area = MAX
   "Bullet automatic tracking = MAX
   "BulletWalkingAreaTracking=MAX
   "BulletTraceRange=MAX
"Bullet automatic landing = MAX
 "Auto Tracking Shooting Bullets = Max
 "Shoot Bullet Tracking = Max
    "Gun shooting tracking area = MAX
  "Automatically track enemy heads with guns and bullets = MAX
  
  "Automatically track guns and bullets to characters = MAX
  
 "Automatic tracking of guns and bullets at range = max
 "Automatic character tracking through guns and bullets = MAX
"Gun Tracking": Execution: "99999"
"Bullet Tracking
}
    {FileReading: <"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/>"}
<cc>
{identify game package name=com.tencent.tmgp.pubgmhd}

GameReadingData:["com.tencent.tmgp.pubgmhd"]