#include <iostream>
#include <string>
#include <unordered_map>

// 定义一个结构体用于表示不同武器类型的瞄准辅助效果
struct WeaponAimAssistEffects {
    int rifle;
    int sniperRifle;
    int submachineGun;
    int shotgun;
};

// 定义一个结构体用于表示不同场景的瞄准辅助效果
struct ScenarioAimAssistEffects {
    int indoorBattle;
    int outdoorBattle;
    int longRangeShooting;
    int closeRangeBattle;
};

// 定义一个结构体用于表示不同地图的瞄准辅助效果
struct MapAimAssistEffects {
    int desertMap;
    int rainforestMap;
    int snowMap;
    int islandMap;
};

// 定义一个结构体用于表示不同瞄准镜的瞄准辅助效果
struct SightAimAssistEffects {
    int lowMagnification;
    int highMagnification;
    int holographic;
    int redDot;
    int sideSight;
};

// 定义一个类用于表示全局瞄准辅助设置
class GlobalAimAssistSettings {
public:
    bool enableInGameLobby;
    int aimAssistIncreasePercentageInGame;
    std::string firingAimAssist;

    GlobalAimAssistSettings()
        : enableInGameLobby(false),
          aimAssistIncreasePercentageInGame(100),
          firingAimAssist("MAX") {}
};

// 定义一个类用于表示瞄准辅助开关设置
class AimAssistSwitchSettings {
public:
    bool aimAssistOn;
    bool aimAssistOff;
    bool mildAimAssist;
    bool powerfulAimAssist;
    bool autoLockTarget;

    AimAssistSwitchSettings()
        : aimAssistOn(false),
          aimAssistOff(true),
          mildAimAssist(false),
          powerfulAimAssist(false),
          autoLockTarget(false) {}
};

// 定义一个类用于表示瞄准辅助微调设置
class AimAssistFineTuningSettings {
public:
    int crosshairFineTuning;
    int aimPrecisionImprovement;
    int shootingErrorReduction;

    AimAssistFineTuningSettings()
        : crosshairFineTuning(0),
          aimPrecisionImprovement(10),
          shootingErrorReduction(10) {}
};

// 定义一个类用于表示瞄准辅助目标效果
class AimAssistTargetEffect {
public:
    int targetEffect;
    int aimAssistSensitivity;
    bool highSensitivityAimAssist;
    bool lowSensitivityAimAssist;
    bool aimAssistSuitableForNewcomers;
    bool aimAssistSettingsSuitableForVeterans;

    AimAssistTargetEffect()
        : targetEffect(50),
          aimAssistSensitivity(80),
          highSensitivityAimAssist(false),
          lowSensitivityAimAssist(false),
          aimAssistSuitableForNewcomers(false),
          aimAssistSettingsSuitableForVeterans(true) {}
};

// 定义一个类用于表示设备相关的瞄准辅助设置
class DeviceRelatedAimAssist {
public:
    bool touchscreenMobilePhoneAimAssist;
    bool externalGamepadAimAssist;

    DeviceRelatedAimAssist()
        : touchscreenMobilePhoneAimAssist(true),
          externalGamepadAimAssist(false) {}
};

// 定义一个类用于表示视角相关的瞄准辅助设置
class PerspectiveRelatedAimAssist {
public:
    bool firstPersonAimAssist;
    bool thirdPersonAimAssist;

    PerspectiveRelatedAimAssist()
        : firstPersonAimAssist(true),
          thirdPersonAimAssist(true) {}
};

// 定义一个类用于表示战斗场景相关的瞄准辅助设置
class BattleSceneRelatedAimAssist {
public:
    int indoorBattleAimAssist;
    int outdoorBattleAimAssist;
    int longRangeShootingAimAssist;
    int closeRangeBattleAimAssist;

    BattleSceneRelatedAimAssist()
        : indoorBattleAimAssist(60),
          outdoorBattleAimAssist(40),
          longRangeShootingAimAssist(70),
          closeRangeBattleAimAssist(30) {}
};

// 定义一个类用于表示武器类型相关的瞄准辅助设置
class WeaponTypeRelatedAimAssist {
public:
    WeaponAimAssistEffects weaponEffects;

    WeaponTypeRelatedAimAssist()
        : weaponEffects{80, 90, 70, 50} {}
};

// 定义一个类用于表示瞄准辅助协调策略
 ‌‍