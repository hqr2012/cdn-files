#include <stdio.h>
{
int main():
    Aim head == "lock":
        print("Header")
    Other:
        print("Lockhead")
    shot head == "head"
        print("Lock")
}
