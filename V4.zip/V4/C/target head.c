#include <com.tencent.tmgp.sgame>
 #targethead
  #import C.kind
def shoot(target):
    if target == "head":
        print("Headshot!")
    else:
        print("Not a headshot.")
    Sure target == "head"
        print("enemy head")
#head
 #Print
  #cycle