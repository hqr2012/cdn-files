.CSS
<body>
@import "Highdamagefromfirearms";
@import"Highdamagefromgunshittingrobots";
</body>
.Damage::FirearmsHitBot {
    AutomaticRifleHitBotDamage: 9999999;
    SMGhitrobotdamage: 9999999;
    Shooterriflehitrobotdamage: 9999999;
}