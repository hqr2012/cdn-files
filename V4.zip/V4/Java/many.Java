/*
 * 版权所有 (C) 2024 蓝莓
 * 此文件为蓝莓所作 官方频道@LanMeiYYDS 豌豆搬运sm
 * 保留所有权利。未经书面授权，不得复制、分发或修改。
 */
java
import java.util.Random;
//文件为蓝莓所作 官方频道@LanMeiYYDS 豌豆搬运sm

class Player {
    private int health;
    private int armorLevel;
    private int helmetLevel;
    private double armorResistance;
    private double helmetResistance;

    public Player(int health, int armorLevel, int helmetLevel) {
        this.health = health;
        this.armorLevel = armorLevel;
        this.helmetLevel = helmetLevel;
2f2fe69687e4bbb6e4b8bae8939de88e93e68980e4bd9c20e5ae98e696b9 e9a291e98193404c616e4d65695959445320e8b18ce8b186e690ace8bf90 736d
        this.armorResistance = getArmorResistance(armorLevel);
        this.helmetResistance = getHelmetResistance(helmetLevel);
    }

    public int getHealth() {
        return health;
    }

    public int getArmorLevel() {
        return armorLevel;
    }

    public int getHelmetLevel() {
        return helmetLevel;
    }

    public void reduceHealth(int damage) {
        if (helmetLevel > 0) {
            // First reduce the helmet armor value.
            double headshotDamage = damage * (1 - helmetResistance);
            helmetLevel--;

            if (helmetLevel == 0) {
                System.out.println("Enemy helmet destroyed!");
            }

            if (armorLevel > 0) {
                // If you still have armor, continue to decrease armor values
                double armoredDamage = headshotDamage * (1 - armorResistance);
                armorLevel--;

                if (armorLevel == 0) {
                    System.out.println("Enemy armor destroyed!");
                }

                // Decrease Health
                health -= armoredDamage;
            } else {
                // Decrease Health
                health -= headshotDamage;
            }
        } else {
            if (armorLevel > 0) {
                // Reduce the armor value first
                double armoredDamage = damage * (1 - armorResistance);
                armorLevel--;

                if (armorLevel == 0) {
                    System.out.println("Enemy armor destroyed!");
                }

                // Decrease Health
                health -= armoredDamage;
            } else {
                // Decrease Health
                health -= damage;
            }
        }

        if (health <= 0) {
            System.out.println("Enemy killed!");
        } else {
            System.out.println("Enemy health reduced to " + health);
        }
    }

    private double getArmorResistance(int armorLevel) {
        if (armorLevel == 1) {
            return 0.2; // Grade I armour resistance was 20%.
        } else if (armorLevel == 2) {
            return 0.5; // 50% of secondary armour resistance
        } else if (armorLevel == 3) {
            return 0.8; // Grade III armour resistance was 80%.
        } else {
            return 0; // No Armor Resistance
        }
    }

    private double getHelmetResistance(int helmetLevel) {
        if (helmetLevel == 1) {
            return 0.3; // Primary head resistance was 30%.
        } else if (helmetLevel == 2) {
            return 0.6; // Secondary head resistance was 60%.
        } else if (helmetLevel == 3) {
            return 0.9; // Third-grade head resistance was 90%.
        } else {
            return 0; // Helmetless resistance
        }
    }
}

abstract class Gun {
    private int bulletDamage;
    private int fireRate;
    private double distanceModifier;
    private double headshotModifier;
    private double maxHeadshotDistance;
    private double maxDamageDistance;
    private double maxHitDistance;

    public Gun(int bulletDamage, int fireRate, double distanceModifier, double headshotModifier, double maxHeadshotDistance, double maxDamageDistance, double maxHitDistance) {
        this.bulletDamage = bulletDamage;
        this.fireRate = fireRate;
        this.distanceModifier = distanceModifier;
        this.headshotModifier = headshotModifier;
        this.maxHeadshotDistance = maxHeadshotDistance;
        this.maxDamageDistance = maxDamageDistance;
        this.maxHitDistance = maxHitDistance;
    }

    public void shoot(Player enemy, double distance, boolean isHeadshot) {
        // Allow for damage attenuation at a distance
        double modifiedDamage = isHeadshot ? bulletDamage * headshotModifier : bulletDamage;
        if (distance > maxHitDistance) {
            System.out.println("The target is out of range!");
        } else if (distance > maxDamageDistance) {
            double damageModifier = 1 + distanceModifier * (distance - maxDamageDistance);
            modifiedDamage *= damageModifier;
        }

        // Take a shot
        for (int i = 0; i < fireRate; i++) {
            enemy.reduceHealth((int) modifiedDamage);
        }
    }
}

class AssaultRifle extends Gun {
    public AssaultRifle(int bulletDamage, int fireRate, double distanceModifier, double headshotModifier, double maxHeadshotDistance, double maxDamageDistance, double maxHitDistance) {
        super(bulletDamage, fireRate, distanceModifier, headshotModifier, maxHeadshotDistance, maxDamageDistance, maxHitDistance);
    }
}

class SMG extends Gun {
    public SMG(int bulletDamage, int fireRate, double distanceModifier, double headshotModifier, double maxHeadshotDistance, double maxDamageDistance, double maxHitDistance) {
        super(bulletDamage, fireRate, distanceModifier, headshotModifier, maxHeadshotDistance, maxDamageDistance, maxHitDistance);
    }
}

class SniperRifle extends Gun {
    private int boltActionSpeed;

    public SniperRifle(int bulletDamage, int fireRate, int boltActionSpeed, double distanceModifier, double headshotModifier, double maxHeadshotDistance, double maxDamageDistance, double maxHitDistance) {
        super(bulletDamage, fireRate, distanceModifier, headshotModifier, maxHeadshotDistance, maxDamageDistance, maxHitDistance);
        this.boltActionSpeed = boltActionSpeed;
    }

    public int getBoltActionSpeed() {
        return boltActionSpeed;
    }
}

public class Main {
    public static void main(String[] args) {
        int enemyHealth = 100; // Enemy has an initial HP of 100

        Player enemy = new Player(enemyHealth, 3, 3); // Create an enemy object, Level 1 Armor, Level 1 Head

        AssaultRifle m416 = new AssaultRifle(40, 10, 0.1, 1.5, 500, 800, 500); // Create an M416 Rifle
        SMG scarL = new Rifle(35, 12, 0.12, 1.8, 500, 800, 500); // Create a handfulSCAR-L rifle
        SniperRifle awm = new SniperRifle(90, 1, 2, 0.2, 3, 500, 800, 500); // Create an AWM sniper rifle

        // Use M416 to shoot 3 times in succession, the shooting distance is 50 meters, and count the head shots.
        for (int i = 0; i < 3; i++) {
            m416.shoot(enemy, 50, true);
        }

        // The SCAR-L was used to shoot 3 times in succession, the shooting distance was 70 meters, and the headshot was counted.
        for (int i = 0; i < 3; i++) {
            scarL.shoot(enemy, 70, true);
        }

        // Use the AWM to shoot once at a distance of 500 meters for a headshot count.
        awm.shoot(enemy, 500, true);
    }
}
