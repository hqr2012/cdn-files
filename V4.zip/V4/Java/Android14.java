import java.io.*;

public class IniFileCreator {
    public static void main(String[] args) {
        String iniFilePath = "storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Game.ini";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(iniFilePath))) {
            writer.write("[Settings]");
            writer.newLine();
            writer.write("Version=安卓14");
            writer.newLine();
            writer.write("Enhancement=Enabled");
            writer.newLine();
            System.out.println("INI文件已成功创建并写入内容。");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}