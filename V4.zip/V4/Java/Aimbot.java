package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int FireAndLockTheHead = 99.99;

        Firearms m416 = new Firearms();
        m416.applyFireAndLockTheHead();

        Firearms aug = new Firearms();
        aug.applyFireAndLockTheHead();

        Firearms ak47 = new Firearms();
        ak47.applyFireAndLockTheHead();

        Firearms m762 = new Firearms();
        m762.applyFireAndLockTheHead();

        Firearms scarL = new Firearms();
        scarL.applyFireAndLockTheHead();

        Firearms groza = new Firearms();
        groza.applyFireAndLockTheHead();

        Firearms ump45 = new Firearms();
        ump45.applyFireAndLockTheHead();

        Firearms uzi = new Firearms();
        uzi.applyFireAndLockTheHead();

        Firearms vector = new Firearms();
        vector.applyFireAndLockTheHead();

        Firearms p90 = new Firearms();
        p90.applyFireAndLockTheHead();

        Firearms mk14 = new Firearms();
        mk14.applyFireAndLockTheHead();

        Firearms m249 = new Firearms();
        m249.applyFireAndLockTheHead();

        Firearms mg3 = new Firearms();
        mg3.applyFireAndLockTheHead();

        Firearms pkm = new Firearms();
        pkm.applyFireAndLockTheHead();

        Firearms dp28 = new Firearms();
        dp28.applyFireAndLockTheHead();

        Firearms s12k = new Firearms();
        s12k.applyFireAndLockTheHead();
    }
}

class Firearms {
    void applyFireAndLockTheHead() {
       
    }
}