import java.util.Scanner;
public data();
 public class Main{Head damage valua; 
damage valua=999,
999: true 
Head Bullet tacking; 
bullet Range;
bullet Range=999,
999=true
 }