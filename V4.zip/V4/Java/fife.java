package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int Reduce lens shake when opening the camera and firing = 0;

        Firearms m416 = new Firearms();
        m416.applyReduce lens shake when opening the camera and firing();

        Firearms aug = new Firearms();
        aug.applyReduce lens shake when opening the camera and firing();

        Firearms ak47 = new Firearms();
        ak47.applyReduce lens shake when opening the camera and firing();

        Firearms m762 = new Firearms();
        m762.applyReduce lens shake when opening the camera and firing();

        Firearms scarL = new Firearms();
        scarL.applyReduce lens shake when opening the camera and firing();

        Firearms groza = new Firearms();
        groza.applyReduce lens shake when opening the camera and firing();

        Firearms ump45 = new Firearms();
        ump45.applyReduce lens shake when opening the camera and firing();

        Firearms uzi = new Firearms();
        uzi.applyReduce lens shake when opening the camera and firing();

        Firearms vector = new Firearms();
        vector.applyReduce lens shake when opening the camera and firing();

        Firearms p90 = new Firearms();
        p90.applyReduce lens shake when opening the camera and firing();

        Firearms mk14 = new Firearms();
        mk14.applyReduce lens shake when opening the camera and firing();

        Firearms m249 = new Firearms();
        m249.applyReduce lens shake when opening the camera and firing();

        Firearms mg3 = new Firearms();
        mg3.applyReduce lens shake when opening the camera and firing();

        Firearms pkm = new Firearms();
        pkm.applyReduce lens shake when opening the camera and firing();

        Firearms dp28 = new Firearms();
        dp28.applyReduce lens shake when opening the camera and firing();

        Firearms s12k = new Firearms();
        s12k.applyReduce lens shake when opening the camera and firing();
    }
}

class Firearms {
    void applyFireselfaimingLockingHead() {
       
    }
}