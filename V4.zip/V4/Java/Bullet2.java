[start]
"implantation" > "com.tencent.tmgp.pubgmhd"
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ AKM damage value;
            Damage value = 500,
            500: true
        AKM bullet rate of fire;
            7.62 bullet firing speed = 3/s
            3/s: true
        }
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ M416 damage value;
            Damage value = 500,
            500: true
        M416 bullet rate of fire;
            5.56 bullet firing speed = 3/s
            3/s: true
        }
}

Start file script(){
import java.util.Scanner;
public data();
 public class Main{ M762 damage value;
            Damage value = 500,
            500: true
        M762 bullet rate of fire;
            5.56 bullet firing speed = 3/s
            3/s: true
        }
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ AUG damage value;
            Damage value = 500,
            500: true
        AUG bullet rate of fire;
            5.56 bullet firing speed = 3/s
            3/s: true
        }       
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ GROZA damage value;
            Damage value = 500,
            500: true
        GROZA bullet rate of fire;
            7.62 bullet firing speed = 3/s
            3/s: true
        }
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ UMP45 damage value;
            Damage value = 500,
            500: true
        UMP45 bullet rate of fire;
            .45caliber bullet firing speed = 3/s
            3/s: true
        }
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ UZI damage value;
            Damage value = 500,
            500: true
        UZI bullet rate of fire;
            9mm bullet firing speed = 3/s
            3/s: true
        }     
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ Vector damage value;
            Damage value = 500,
            500: true
        Vector bullet rate of fire;
            9mm bullet firing speed = 3/s
            3/s: true
        }
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ P90 damage value;
            Damage value = 500,
            500: true
        P90 bullet rate of fire;
            5.7 bullet firing speed = 3/s
            3/s: true
        }  
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ MG3 damage value;
            Damage value = 500,
            500: true
        MG3 bullet rate of fire;
            7.62 bullet firing speed = 3/s
            3/s: true
        }      

