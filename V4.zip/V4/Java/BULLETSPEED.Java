/*
 * 版权所有 (C) 2024 蓝莓
 * 此文件为蓝莓所作 官方频道@LanMeiYYDS 豌豆搬运sm
 * 保留所有权利。未经书面授权，不得复制、分发或修改。
 */
java
public class RapidFire {
//文件为蓝莓所作 官方频道@LanMeiYYDS 豌豆搬运sm
    private boolean isFiring; // Is it shooting?
    private int fireRate; // Firing interval in millisecond

    public RapidFire(int fireRate) {
        this.fireRate = fireRate;
    }

    public void startFiring() {
        isFiring = true;
        // Create a shooting thread and start it
        Thread firingThread = new Thread(new FiringRunnable());
        firingThread.start();
2f2fe69687e4bbb6e4b8bae8939de88e93e68980e4bd9c20e5ae98e696b9 e9a291e98193404c616e4d65695959445320e8b18ce8b186e690ace8bf90 736d
    }

    public void stopFiring() {
        isFiring = false;
    }

    private void fire() {
        // Execute Firing Logic
        System.out.println("Bang!");
    }

    private class FiringRunnable implements Runnable {
        @Override
        public void run() {
            while (isFiring) {
                fire();
                try {
                    Thread.sleep(fireRate);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        int fireRate = 200Millisecond; // The firing interval is 200 milliseconds.        
        RapidFire rapidFire = new RapidFire(fireRate);
        rapidFire.startFiring();
        
        // Simulate shooting for 5 seconds
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        rapidFire.stopFiring();
    }
}

java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BulletFastFlight {
    private int bulletSpeed=1000m/s; // Bullet velocity in m/s

    public BulletFastFlight(int bulletSpeed) {
        this.bulletSpeed = bulletSpeed;
    }

    public void startFlight() {
        // Create a thread pool, specifying the number of threads
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        
        // Simulate firing 10 bullets.
        for (int i = 0; i < 10; i++) {
            Bullet bullet = new Bullet(i + 1); // Bullet identification number
            executorService.execute(new BulletFlightRunnable(bullet));
        }
        
        // Turn off thread pool
        executorService.shutdown();
    }

    private class Bullet {
        private int id;

        public Bullet(int id) {
            this.id = id;
        }

        public int getId() {
            return id;
        }
    }

    private class BulletFlightRunnable implements Runnable {
        private Bullet bullet;

        public BulletFlightRunnable(Bullet bullet) {
            this.bullet = bullet;
        }

        @Override
        public void run() {
            try {
                // Calculate the time it takes a bullet to fly.
                int flightTime = (int) (bullet.getId() * 1000 / bulletSpeed); // Suppose each bullet is fired one second apart.
                Thread.sleep(flightTime);
                System.out.println("Bullet " + bullet.getId() + " reached the target!");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        int bulletSpeed = 500; // The bullet speed is 500 m/s.

        BulletFastFlight bulletFastFlight = new BulletFastFlight(bulletSpeed);
        bulletFastFlight.startFlight();
    }
}
