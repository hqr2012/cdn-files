{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   "Bullet tracking=MAX
   "When the gun fires, the bullet trajectory tracks the target=MAX
   "Bullet tracking target model=MAX
   "Bullet tracking target head=MAX
   "Bullet tracking target lower limbs=MAX
   "Bullet tracking target's whole body=MAX
  "Bullet tracking range=999
 "Passive body direct fire fire tracking=MAX
 "The fire effect triggered by the bullet hitting the enemy =MAX
 "Strike effects=MAX
 "Crouch down to trigger bullet tracking=MAX
 "Standing on oneself triggers bullet tracking=MAX
 "Bullet tracking when crouching = when weapon is scoped
 "When opening the lens, the entire aperture content includes head tracking = MAX
 "Bullet tracking while standing = when weapon is scoped
 "When opening the lens, the entire aperture content includes head tracking = MAX
 "Bullets always track head damage = doubled
 "Distance that triggers bullet tracking = 300 meters
              }:"execute"
             <Java>
 