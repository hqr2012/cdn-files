package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int Reduce the walking of firearms and bullets when firing = 0;

        Firearms M416 = new Firearms();
        M416Automatic Rifle.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms AUG = new Firearms();
        AUGAutomatic Rifle.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms AKM = new Firearms();
        AKMAutomatic Rifle.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms SCAR-L = new Firearms();
        SCAR-LAutomatic Rifle.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms groza = new Firearms();
        GROZAAutomatic Rifle.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms UMP45 = new Firearms();
        UMP45Submachine Gun.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms UZI = new Firearms();
        UZISubmachine Gun.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms Vector = new Firearms();
        VectorSubmachine Gun.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms P90 = new Firearms();
        P90Submachine Gun.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms Mk14 = new Firearms();
        Mk14Designated Marksman Rifle
.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms MG3 = new Firearms();
        MG3LightMachine Gun.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();

        Firearms PKM = new Firearms();
        PKMLightMachine Gun.applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring();
    }
}

class Firearms {
    void applyReduceTheWalkingOfFirearmsAndBulletsWhenFiring() {
       
    }
}