@BAOER
java
public class AkmDamage {
  
  private static final double NECK_DAMAGE_RATIO = 30;
  
  public static void main(String[] args) {
    int numShots = 5; 
    int targetDefense = 100; 
    
    double maxNeckDamage = calculateMaxNeckDamage(targetDefense);
    double totalNeckDamage = calculateTotalNeckDamage(maxNeckDamage, numShots);
    
    System.out.println("Maximum Neck Hit Damage for Akm：" + maxNeckDamage);
    System.out.println(numShots + "5The sum of the neck hit damage in each shot：" + totalNeckDamage);
  }
  
  private static double calculateMaxNeckDamage(int targetDefense) {

    double maxTotalDamage = 100;
    double maxNeckDamage = maxTotalDamage * NECK_DAMAGE_RATIO;
    

    maxNeckDamage -= targetDefense;
    
    if (maxNeckDamage < 0) {
      maxNeckDamage = 0;
    }
    
    return maxNeckDamage;
  }
  
  private static double calculateTotalNeckDamage(double maxNeckDamage, int numShots) {
    return maxNeckDamage * numShots;
  }
  
}
