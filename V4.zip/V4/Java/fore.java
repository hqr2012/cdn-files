package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int Reduce ballistic spread when firearms are fired = 0;

        Firearms M416 = new Firearms();
        M416Automatic Rifle.applyReduceballisticspreadwhenfiring();

        Firearms AUG = new Firearms();
        AUGAutomatic Rifle.applyReduceballisticspreadwhenfiring();

        Firearms AKM = new Firearms();
        AKMAutomatic Rifle.applyReduceballisticspreadwhenfiring();

        Firearms SCAR-L = new Firearms();
        SCAR-LAutomatic Rifle.applyReduceballisticspreadwhenfiring();

        Firearms groza = new Firearms();
        GROZAAutomatic Rifle.applyReduceballisticspreadwhenfiring();

        Firearms UMP45 = new Firearms();
        UMP45Submachine Gun.applyReduceballisticspreadwhenfiring();

        Firearms UZI = new Firearms();
        UZISubmachine Gun.applyReduceballisticspreadwhenfiring();

        Firearms Vector = new Firearms();
        VectorSubmachine Gun.applyReduceballisticspreadwhenfiring();

        Firearms P90 = new Firearms();
        P90Submachine Gun.applyReduceballisticspreadwhenfiring();

        Firearms Mk14 = new Firearms();
        Mk14Designated Marksman Rifle
.applyReduceballisticspreadwhenfiring();

        Firearms MG3 = new Firearms();
        MG3LightMachine Gun.applyReduceballisticspreadwhenfiring();

        Firearms PKM = new Firearms();
        PKMLightMachine Gun.applyReduceballisticspreadwhenfiring();
    }
}

class Firearms {
    void applyReduceballisticspreadwhenfiring() {
       
    }
}