package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int Reduce recoil when firing firearms = 0;

        Firearms M416 = new Firearms();
        M416Automatic Rifle.applyReducerecoilwhenfiring();

        Firearms AUG = new Firearms();
        AUGAutomatic Rifle.applyReducerecoilwhenfiring();

        Firearms AKM = new Firearms();
        AKMAutomatic Rifle.applyReducerecoilwhenfiring();

        Firearms SCAR-L = new Firearms();
        SCAR-LAutomatic Rifle.applyReducerecoilwhenfiring();

        Firearms groza = new Firearms();
        GROZAAutomatic Rifle.applyReducerecoilwhenfiring();

        Firearms UMP45 = new Firearms();
        UMP45Submachine Gun.applyReducerecoilwhenfiring();

        Firearms UZI = new Firearms();
        UZISubmachine Gun.applyReducerecoilwhenfiring();

        Firearms Vector = new Firearms();
        VectorSubmachine Gun.applyReducerecoilwhenfiring();

        Firearms P90 = new Firearms();
        P90Submachine Gun.applyReducerecoilwhenfiring();

        Firearms Mk14 = new Firearms();
        Mk14Designated Marksman Rifle
.applyReducerecoilwhenfiring();

        Firearms MG3 = new Firearms();
        MG3LightMachine Gun.applyReducerecoilwhenfiring();

        Firearms PKM = new Firearms();
        PKMLightMachine Gun.applyReducerecoilwhenfiring();
    }
}

class Firearms {
    void applyReducerecoilwhenfiring() {
       
    }
}