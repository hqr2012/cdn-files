{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
     "The character shoots the enemy with a gun = in the head
     "Shooting enemy range=MAX
     "Range=999
   "Reduce the crosshair spread of firearms when shooting=minimum
   "The probability that the bullet will be concentrated on the subject's head = maximum
"Center spread = small
   "Fire aim spread=previous line
  "Shooting horizon = the part above the target's body
 "Bullets fired from passive subjects: always track in the direction of the subject
 "Bullet concentration=MAX
 "The triggering time limit = when the passive object fires
 "The aim of the firearm when firing is reduced = MAX
       "The character shoots the enemy with a gun = in the head
     "Shooting enemy range=MAX
     "Range=999
   "Reduce the crosshair spread of firearms when shooting=minimum
   "The probability that the bullet will be concentrated on the subject's head = maximum
"Center spread = small
   "Fire aim spread=previous line
  "Shooting horizon = the part above the target's body
 "Bullets fired from passive subjects: always track in the direction of the subject
 "Bullet concentration=MAX
 "The triggering time limit = when the passive object fires
 "The aim of the firearm when firing is reduced = MAX          
            }:"execute"
                 <Java>
     