package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int Firearms firing reduces recoil = 0;

        Firearms M416 = new Firearms();
        M416Automatic Rifle.applyReduceRecoil();

        Firearms AUG = new Firearms();
        AUGAutomatic Rifle.applyReduceRecoil();

        Firearms AKM = new Firearms();
        AKMAutomatic Rifle.applyReduceRecoil();

        Firearms SCAR-L = new Firearms();
        SCAR-LAutomatic Rifle.applyReduceRecoil();

        Firearms groza = new Firearms();
        GROZAAutomatic Rifle.applyReduceRecoil();

        Firearms UMP45 = new Firearms();
        UMP45Submachine Gun.applyReduceRecoil();

        Firearms UZI = new Firearms();
        UZISubmachine Gun.applyReduceRecoil();

        Firearms Vector = new Firearms();
        VectorSubmachine Gun.applyReduceRecoil();

        Firearms P90 = new Firearms();
        P90Submachine Gun.applyReduceRecoil();

        Firearms Mk14 = new Firearms();
        Mk14Designated Marksman Rifle
.applyReduceRecoil();

        Firearms MG3 = new Firearms();
        MG3LightMachine Gun.applyReduceRecoil();

        Firearms PKM = new Firearms();
        PKMLightMachine Gun.applyReduceRecoil();
    }
}

class Firearms {
    void applyReduceRecoil() {
       
    }
}