import java.io.FileInputStream;
int main ()
{
	System.out.println=("com.tencent.tmgp.pubgmhd");
long address=getfile("Wing_aimassist.java");

	for (;;)
	{
	    public aimassist= (999+9);
	    if (Obtain(aimassist+head)>=999.9) 
	    {
	    Print(aimassist,99);
	    }start{; (overlay=aimassist;999)
	    
	    
	        	Finish(aimassist);
	        }
	         	    	
        }     
      
}