import java.io.FileInputStream;

public class HeadDamage {
    private int bodyOffset;

    public HeadDamage() {
        loadConfig();
    }

public class ModifyDefaultHeadDamage{
    HeadModelDamage=9999
    HeadInjury=9999
}
public printComplete;