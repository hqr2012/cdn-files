import java.awt.*;
import java.awt.event.InputEvent;

public class Aimlock {

    private Robot robot;

    public Aimlock() {
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void aimAtTarget(int targetX, int targetY) {
        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        int deltaX = targetX - centerX;
        int deltaY = targetY - centerY;

        robot.mouseMove(centerX, centerY);
        robot.mousePress(InputEvent.BUTTON1_MASK);
        robot.mouseMove(centerX + deltaX, centerY + deltaY);
        robot.mouseRelease(InputEvent.BUTTON1_MASK);
    }

    public static void main(String[] args) {
        Aimlock aimlock = new Aimlock();
        aimlock.aimAtTarget(500, 300);
    }
}