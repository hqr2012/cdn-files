@BAOER
public class M416BulletTrackingMaximizer {

  public static void main(String[] args) {

    int bulletSpeed = 900; 
    int targetTracking = 4; 

    int maxBulletTracking = calculateMaxBulletTracking(bulletSpeed, targetTracking);
    
    System.out.println("The bullet tracking of the Akm is maximized to: " + maxBulletTracking);
  }
  
  private static int calculateMaxBulletTracking(int bulletSpeed, int targetTracking) {
    int maxBulletTracking = 0;
    
    maxBulletTracking = bulletSpeed * targetTracking;
    
    return maxBulletTracking;
  }
}