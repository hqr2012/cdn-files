package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int opening the Magnifying glass and firing Reduce lens shake = 0;

        Firearms m416 = new Firearms();
        m416.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms aug = new Firearms();
        aug.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms ak47 = new Firearms();
        ak47.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms m762 = new Firearms();
        m762.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms scarL = new Firearms();
        scarL.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms groza = new Firearms();
        groza.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms ump45 = new Firearms();
        ump45.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms uzi = new Firearms();
        uzi.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms vector = new Firearms();
        vector.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms p90 = new Firearms();
        p90.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms mk14 = new Firearms();
        mk14.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms m249 = new Firearms();
        m249.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms mg3 = new Firearms();
        mg3.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms pkm = new Firearms();
        pkm.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms dp28 = new Firearms();
        dp28.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();

        Firearms s12k = new Firearms();
        s12k.applyReduce lens shake when OpeningTheMagnifyingGlassAndFiringReduceLensShake();
    }
}

class Firearms {
    void applyFireselfaimingLockingHead() {
       
    }
}