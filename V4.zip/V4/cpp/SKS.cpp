#include <iostream>
#include "SKSConfig.h"

int main() {
    auto config = PeaceElite::SKS_BulletTrack::GetDefaultSKSConfig();

    // 读取 SKS 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::SKS_BulletTrack::SKS_CoreTrack::Range)];
    std::cout << "SKS tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::SKS_BulletTrack::SKS_BulletCorrect::ADS_Factor)] = 1.3f;

    return 0;
}