#ifndef SCARL_CONFIG_H
#define SCARL_CONFIG_H

#include <array>

namespace PeaceElite {
namespace SCARL_BulletTrack {

// SCAR-L核心追踪参数枚举
enum class SCARL_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// SCAR-L弹道修正参数枚举
enum class SCARL_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// SCAR-L弹道配置结构体
struct SCARLConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取SCAR-L默认配置
inline SCARLConfig GetDefaultSCARLConfig() {
    SCARLConfig config;

    // 核心追踪参数 - SCAR-L使用5.56mm子弹
    config.coreTrack[static_cast<size_t>(SCARL_CoreTrack::Range)] = 450.0f;       // 有效射程450米
    config.coreTrack[static_cast<size_t>(SCARL_CoreTrack::Velocity)] = 625.0f;    // 子弹初速625m/s
    config.coreTrack[static_cast<size_t>(SCARL_CoreTrack::Gravity)] = 9.8f;       // 重力影响
    config.coreTrack[static_cast<size_t>(SCARL_CoreTrack::MaxTrajectory)] = 700.0f; // 最大弹道距离

    // 弹道修正参数 - SCAR-L后坐力较稳定
    config.bulletCorrect[static_cast<size_t>(SCARL_BulletCorrect::ADS_Factor)] = 1.5f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(SCARL_BulletCorrect::Hip_Factor)] = 2.2f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(SCARL_BulletCorrect::Move_Factor)] = 1.9f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(SCARL_BulletCorrect::Crouch_Factor)] = 1.2f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(SCARL_BulletCorrect::Prone_Factor)] = 0.95f; // 趴姿修正

    return config;
}

} // namespace SCARL_BulletTrack
} // namespace PeaceElite

#endif // SCARL_CONFIG_H