#include <iostream>
#include "Kar98kConfig.h"

int main() {
    auto config = PeaceElite::Kar98k_BulletTrack::GetDefaultKar98kConfig();

    // 读取 Kar98k 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::Kar98k_BulletTrack::Kar98k_CoreTrack::Range)];
    std::cout << "Kar98k tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::Kar98k_BulletTrack::Kar98k_BulletCorrect::ADS_Factor)] = 1.1f;

    return 0;
}