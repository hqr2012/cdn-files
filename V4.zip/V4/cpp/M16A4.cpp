#include <iostream>
#include "M16A4Config.h"

int main() {
    auto config = PeaceElite::M16A4_BulletTrack::GetDefaultM16A4Config();

    // 读取 M16A4 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::M16A4_BulletTrack::M16A4_CoreTrack::Range)];
    std::cout << "M16A4 tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::M16A4_BulletTrack::M16A4_BulletCorrect::ADS_Factor)] = 1.5f;

    return 0;
}