#include <iostream>
#include "Mini14Config.h"

int main() {
    auto config = PeaceElite::Mini14_BulletTrack::GetDefaultMini14Config();

    // 读取 Mini14 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::Mini14_BulletTrack::Mini14_CoreTrack::Range)];
    std::cout << "Mini14 tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::Mini14_BulletTrack::Mini14_BulletCorrect::ADS_Factor)] = 0.9f;

    return 0;
}