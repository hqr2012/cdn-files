#ifndef MINI14_CONFIG_H
#define MINI14_CONFIG_H

#include <array>

namespace PeaceElite {
namespace Mini14_BulletTrack {

// Mini14核心追踪参数枚举
enum class Mini14_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// Mini14弹道修正参数枚举
enum class Mini14_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// Mini14弹道配置结构体
struct Mini14Config {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取Mini14默认配置
inline Mini14Config GetDefaultMini14Config() {
    Mini14Config config;

    // 核心追踪参数 - Mini14使用5.56mm子弹
    config.coreTrack[static_cast<size_t>(Mini14_CoreTrack::Range)] = 600.0f;       // 有效射程600米
    config.coreTrack[static_cast<size_t>(Mini14_CoreTrack::Velocity)] = 854.0f;    // 子弹初速854m/s
    config.coreTrack[static_cast<size_t>(Mini14_CoreTrack::Gravity)] = 9.8f;        // 重力影响
    config.coreTrack[static_cast<size_t>(Mini14_CoreTrack::MaxTrajectory)] = 1000.0f; // 最大弹道距离

    // 弹道修正参数 - Mini14后坐力较小，射速快
    config.bulletCorrect[static_cast<size_t>(Mini14_BulletCorrect::ADS_Factor)] = 0.8f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(Mini14_BulletCorrect::Hip_Factor)] = 3.5f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(Mini14_BulletCorrect::Move_Factor)] = 2.8f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(Mini14_BulletCorrect::Crouch_Factor)] = 0.6f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(Mini14_BulletCorrect::Prone_Factor)] = 0.5f;   // 趴姿修正

    return config;
}

} // namespace Mini14_BulletTrack
} // namespace PeaceElite

#endif // MINI14_CONFIG_H