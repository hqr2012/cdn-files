#ifndef GROZA_CONFIG_H
#define GROZA_CONFIG_H

#include <array>

namespace PeaceElite {
namespace Groza_BulletTrack {

// Groza核心追踪参数枚举
enum class Groza_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// Groza弹道修正参数枚举
enum class Groza_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// Groza弹道配置结构体
struct GrozaConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取Groza默认配置
inline GrozaConfig GetDefaultGrozaConfig() {
    GrozaConfig config;

    // 核心追踪参数 - Groza使用7.62mm子弹
    config.coreTrack[static_cast<size_t>(Groza_CoreTrack::Range)] = 400.0f;       // 有效射程400米
    config.coreTrack[static_cast<size_t>(Groza_CoreTrack::Velocity)] = 715.0f;   // 子弹初速715m/s
    config.coreTrack[static_cast<size_t>(Groza_CoreTrack::Gravity)] = 9.8f;       // 重力影响
    config.coreTrack[static_cast<size_t>(Groza_CoreTrack::MaxTrajectory)] = 650.0f; // 最大弹道距离

    // 弹道修正参数 - Groza后坐力大但射速极快
    config.bulletCorrect[static_cast<size_t>(Groza_BulletCorrect::ADS_Factor)] = 1.7f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(Groza_BulletCorrect::Hip_Factor)] = 2.4f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(Groza_BulletCorrect::Move_Factor)] = 2.1f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(Groza_BulletCorrect::Crouch_Factor)] = 1.3f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(Groza_BulletCorrect::Prone_Factor)] = 1.0f; // 趴姿修正

    return config;
}

} // namespace Groza_BulletTrack
} // namespace PeaceElite

#endif // GROZA_CONFIG_H