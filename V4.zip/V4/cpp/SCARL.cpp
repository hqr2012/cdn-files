#include <iostream>
#include "SCARLConfig.h"

int main() {
    auto config = PeaceElite::SCARL_BulletTrack::GetDefaultSCARLConfig();

    // 读取 SCAR-L 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::SCARL_BulletTrack::SCARL_CoreTrack::Range)];
    std::cout << "SCAR-L tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::SCARL_BulletTrack::SCARL_BulletCorrect::ADS_Factor)] = 1.6f;

    return 0;
}