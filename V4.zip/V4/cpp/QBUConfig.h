#ifndef QBU_CONFIG_H
#define QBU_CONFIG_H

#include <array>

namespace PeaceElite {
namespace QBU_BulletTrack {

// QBU核心追踪参数枚举
enum class QBU_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// QBU弹道修正参数枚举
enum class QBU_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// QBU弹道配置结构体
struct QBUConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取QBU默认配置
inline QBUConfig GetDefaultQBUConfig() {
    QBUConfig config;

    // 核心追踪参数 - QBU使用5.56mm子弹
    config.coreTrack[static_cast<size_t>(QBU_CoreTrack::Range)] = 550.0f;       // 有效射程550米
    config.coreTrack[static_cast<size_t>(QBU_CoreTrack::Velocity)] = 825.0f;   // 子弹初速825m/s
    config.coreTrack[static_cast<size_t>(QBU_CoreTrack::Gravity)] = 9.8f;       // 重力影响
    config.coreTrack[static_cast<size_t>(QBU_CoreTrack::MaxTrajectory)] = 920.0f; // 最大弹道距离

    // 弹道修正参数 - QBU后坐力小，有支架辅助
    config.bulletCorrect[static_cast<size_t>(QBU_BulletCorrect::ADS_Factor)] = 0.6f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(QBU_BulletCorrect::Hip_Factor)] = 2.8f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(QBU_BulletCorrect::Move_Factor)] = 2.2f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(QBU_BulletCorrect::Crouch_Factor)] = 0.5f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(QBU_BulletCorrect::Prone_Factor)] = 0.4f;  // 趴姿修正

    return config;
}

} // namespace QBU_BulletTrack
} // namespace PeaceElite

#endif // QBU_CONFIG_H