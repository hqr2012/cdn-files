#ifndef SLR_CONFIG_H
#define SLR_CONFIG_H

#include <array>

namespace PeaceElite {
namespace SLR_BulletTrack {

// SLR核心追踪参数枚举
enum class SLR_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// SLR弹道修正参数枚举
enum class SLR_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// SLR弹道配置结构体
struct SLRConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取SLR默认配置
inline SLRConfig GetDefaultSLRConfig() {
    SLRConfig config;

    // 核心追踪参数 - SLR使用7.62mm子弹
    config.coreTrack[static_cast<size_t>(SLR_CoreTrack::Range)] = 550.0f;       // 有效射程550米
    config.coreTrack[static_cast<size_t>(SLR_CoreTrack::Velocity)] = 840.0f;     // 子弹初速840m/s
    config.coreTrack[static_cast<size_t>(SLR_CoreTrack::Gravity)] = 9.8f;        // 重力影响
    config.coreTrack[static_cast<size_t>(SLR_CoreTrack::MaxTrajectory)] = 880.0f; // 最大弹道距离

    // 弹道修正参数 - SLR后坐力持续时间较长
    config.bulletCorrect[static_cast<size_t>(SLR_BulletCorrect::ADS_Factor)] = 1.1f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(SLR_BulletCorrect::Hip_Factor)] = 3.0f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(SLR_BulletCorrect::Move_Factor)] = 2.4f;    // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(SLR_BulletCorrect::Crouch_Factor)] = 0.8f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(SLR_BulletCorrect::Prone_Factor)] = 0.6f;   // 趴姿修正

    return config;
}

} // namespace SLR_BulletTrack
} // namespace PeaceElite

#endif // SLR_CONFIG_H