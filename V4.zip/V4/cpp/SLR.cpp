#include <iostream>
#include "SLRConfig.h"

int main() {
    auto config = PeaceElite::SLR_BulletTrack::GetDefaultSLRConfig();

    // 读取 SLR 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::SLR_BulletTrack::SLR_CoreTrack::Range)];
    std::cout << "SLR tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::SLR_BulletTrack::SLR_BulletCorrect::ADS_Factor)] = 1.2f;

    return 0;
}