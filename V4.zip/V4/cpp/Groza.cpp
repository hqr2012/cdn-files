#include <iostream>
#include "GrozaConfig.h"

int main() {
    auto config = PeaceElite::Groza_BulletTrack::GetDefaultGrozaConfig();

    // 读取 Groza 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::Groza_BulletTrack::Groza_CoreTrack::Range)];
    std::cout << "Groza tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::Groza_BulletTrack::Groza_BulletCorrect::ADS_Factor)] = 1.8f;

    return 0;
}