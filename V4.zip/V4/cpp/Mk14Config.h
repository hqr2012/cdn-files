#ifndef MK14_CONFIG_H
#define MK14_CONFIG_H

#include <array>

namespace PeaceElite {
namespace Mk14_BulletTrack {

// Mk14核心追踪参数枚举
enum class Mk14_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// Mk14弹道修正参数枚举
enum class Mk14_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// Mk14弹道配置结构体
struct Mk14Config {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取Mk14默认配置
inline Mk14Config GetDefaultMk14Config() {
    Mk14Config config;

    // 核心追踪参数 - Mk14使用7.62mm子弹
    config.coreTrack[static_cast<size_t>(Mk14_CoreTrack::Range)] = 600.0f;       // 有效射程600米
    config.coreTrack[static_cast<size_t>(Mk14_CoreTrack::Velocity)] = 853.0f;   // 子弹初速853m/s
    config.coreTrack[static_cast<size_t>(Mk14_CoreTrack::Gravity)] = 9.8f;       // 重力影响
    config.coreTrack[static_cast<size_t>(Mk14_CoreTrack::MaxTrajectory)] = 950.0f; // 最大弹道距离

    // 弹道修正参数 - Mk14有枪托模式后坐力较小
    config.bulletCorrect[static_cast<size_t>(Mk14_BulletCorrect::ADS_Factor)] = 0.9f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(Mk14_BulletCorrect::Hip_Factor)] = 3.2f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(Mk14_BulletCorrect::Move_Factor)] = 2.6f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(Mk14_BulletCorrect::Crouch_Factor)] = 0.7f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(Mk14_BulletCorrect::Prone_Factor)] = 0.5f;  // 趴姿修正

    return config;
}

} // namespace Mk14_BulletTrack
} // namespace PeaceElite

#endif // MK14_CONFIG_H