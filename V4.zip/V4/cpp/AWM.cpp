#include <iostream>
#include "AWMConfig.h"

int main() {
    auto config = PeaceElite::AWM_BulletTrack::GetDefaultAWMConfig();

    // 读取 AWM 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::AWM_BulletTrack::AWM_CoreTrack::Range)];
    std::cout << "AWM tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::AWM_BulletTrack::AWM_BulletCorrect::ADS_Factor)] = 0.6f;

    return 0;
}