#ifndef SKS_CONFIG_H
#define SKS_CONFIG_H

#include <array>

namespace PeaceElite {
namespace SKS_BulletTrack {

// SKS核心追踪参数枚举
enum class SKS_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// SKS弹道修正参数枚举
enum class SKS_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// SKS弹道配置结构体
struct SKSConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取SKS默认配置
inline SKSConfig GetDefaultSKSConfig() {
    SKSConfig config;

    // 核心追踪参数 - SKS使用7.62mm子弹
    config.coreTrack[static_cast<size_t>(SKS_CoreTrack::Range)] = 550.0f;       // 有效射程550米
    config.coreTrack[static_cast<size_t>(SKS_CoreTrack::Velocity)] = 800.0f;     // 子弹初速800m/s
    config.coreTrack[static_cast<size_t>(SKS_CoreTrack::Gravity)] = 9.8f;      // 重力影响
    config.coreTrack[static_cast<size_t>(SKS_CoreTrack::MaxTrajectory)] = 900.0f; // 最大弹道距离

    // 弹道修正参数 - SKS后坐力较大，需要托腮板
    config.bulletCorrect[static_cast<size_t>(SKS_BulletCorrect::ADS_Factor)] = 1.2f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(SKS_BulletCorrect::Hip_Factor)] = 3.0f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(SKS_BulletCorrect::Move_Factor)] = 2.5f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(SKS_BulletCorrect::Crouch_Factor)] = 0.9f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(SKS_BulletCorrect::Prone_Factor)] = 0.7f;  // 趴姿修正

    return config;
}

} // namespace SKS_BulletTrack
} // namespace PeaceElite

#endif // SKS_CONFIG_H