#ifndef AWM_CONFIG_H
#define AWM_CONFIG_H

#include <array>

namespace PeaceElite {
namespace AWM_BulletTrack {

// AWM核心追踪参数枚举
enum class AWM_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// AWM弹道修正参数枚举
enum class AWM_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// AWM弹道配置结构体
struct AWMConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取AWM默认配置
inline AWMConfig GetDefaultAWMConfig() {
    AWMConfig config;

    // 核心追踪参数 - AWM使用.300马格南子弹
    config.coreTrack[static_cast<size_t>(AWM_CoreTrack::Range)] = 1000.0f;      // 有效射程1000米
    config.coreTrack[static_cast<size_t>(AWM_CoreTrack::Velocity)] = 910.0f;    // 子弹初速910m/s
    config.coreTrack[static_cast<size_t>(AWM_CoreTrack::Gravity)] = 9.8f;       // 重力影响
    config.coreTrack[static_cast<size_t>(AWM_CoreTrack::MaxTrajectory)] = 1500.0f; // 最大弹道距离

    // 弹道修正参数 - AWM后坐力极大但精准度极高
    config.bulletCorrect[static_cast<size_t>(AWM_BulletCorrect::ADS_Factor)] = 0.5f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(AWM_BulletCorrect::Hip_Factor)] = 5.0f;     // 腰射修正
    config.bulletCorrect[static_cast<size_t>(AWM_BulletCorrect::Move_Factor)] = 4.0f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(AWM_BulletCorrect::Crouch_Factor)] = 0.4f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(AWM_BulletCorrect::Prone_Factor)] = 0.3f;   // 趴姿修正

    return config;
}

} // namespace AWM_BulletTrack
} // namespace PeaceElite

#endif // AWM_CONFIG_H