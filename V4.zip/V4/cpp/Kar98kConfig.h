#ifndef KAR98K_CONFIG_H
#define KAR98K_CONFIG_H

#include <array>

namespace PeaceElite {
namespace Kar98k_BulletTrack {

// Kar98k核心追踪参数枚举
enum class Kar98k_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// Kar98k弹道修正参数枚举
enum class Kar98k_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// Kar98k弹道配置结构体
struct Kar98kConfig {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取Kar98k默认配置
inline Kar98kConfig GetDefaultKar98kConfig() {
    Kar98kConfig config;

    // 核心追踪参数 - Kar98k使用7.62mm子弹
    config.coreTrack[static_cast<size_t>(Kar98k_CoreTrack::Range)] = 500.0f;       // 有效射程500米
    config.coreTrack[static_cast<size_t>(Kar98k_CoreTrack::Velocity)] = 760.0f;    // 子弹初速760m/s
    config.coreTrack[static_cast<size_t>(Kar98k_CoreTrack::Gravity)] = 9.8f;      // 重力影响
    config.coreTrack[static_cast<size_t>(Kar98k_CoreTrack::MaxTrajectory)] = 850.0f; // 最大弹道距离

    // 弹道修正参数 - Kar98k单发伤害高但后坐力大
    config.bulletCorrect[static_cast<size_t>(Kar98k_BulletCorrect::ADS_Factor)] = 1.0f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(Kar98k_BulletCorrect::Hip_Factor)] = 4.0f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(Kar98k_BulletCorrect::Move_Factor)] = 3.5f;   // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(Kar98k_BulletCorrect::Crouch_Factor)] = 0.8f; // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(Kar98k_BulletCorrect::Prone_Factor)] = 0.6f;  // 趴姿修正

    return config;
}

} // namespace Kar98k_BulletTrack
} // namespace PeaceElite

#endif // KAR98K_CONFIG_H