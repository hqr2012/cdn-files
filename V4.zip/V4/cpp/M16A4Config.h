#ifndef M16A4_CONFIG_H
#define M16A4_CONFIG_H

#include <array>

namespace PeaceElite {
namespace M16A4_BulletTrack {

// M16A4核心追踪参数枚举
enum class M16A4_CoreTrack {
    Range,           // 有效射程
    Velocity,        // 子弹初速
    Gravity,         // 重力影响系数
    MaxTrajectory    // 最大弹道距离
};

// M16A4弹道修正参数枚举
enum class M16A4_BulletCorrect {
    ADS_Factor,       // 开镜修正因子
    Hip_Factor,       // 腰射修正因子
    Move_Factor,      // 移动射击修正因子
    Crouch_Factor,    // 蹲姿修正因子
    Prone_Factor      // 趴姿修正因子
};

// M16A4弹道配置结构体
struct M16A4Config {
    std::array<float, 4> coreTrack;      // 核心追踪参数
    std::array<float, 5> bulletCorrect;  // 弹道修正参数
};

// 获取M16A4默认配置
inline M16A4Config GetDefaultM16A4Config() {
    M16A4Config config;

    // 核心追踪参数 - M16A4使用5.56mm子弹
    config.coreTrack[static_cast<size_t>(M16A4_CoreTrack::Range)] = 420.0f;       // 有效射程420米
    config.coreTrack[static_cast<size_t>(M16A4_CoreTrack::Velocity)] = 630.0f;     // 子弹初速630m/s
    config.coreTrack[static_cast<size_t>(M16A4_CoreTrack::Gravity)] = 9.8f;        // 重力影响
    config.coreTrack[static_cast<size_t>(M16A4_CoreTrack::MaxTrajectory)] = 680.0f; // 最大弹道距离

    // 弹道修正参数 - M16A4后坐力适中，单发精准
    config.bulletCorrect[static_cast<size_t>(M16A4_BulletCorrect::ADS_Factor)] = 1.4f;    // 开镜修正
    config.bulletCorrect[static_cast<size_t>(M16A4_BulletCorrect::Hip_Factor)] = 2.0f;    // 腰射修正
    config.bulletCorrect[static_cast<size_t>(M16A4_BulletCorrect::Move_Factor)] = 1.7f;    // 移动射击修正
    config.bulletCorrect[static_cast<size_t>(M16A4_BulletCorrect::Crouch_Factor)] = 1.1f;  // 蹲姿修正
    config.bulletCorrect[static_cast<size_t>(M16A4_BulletCorrect::Prone_Factor)] = 0.9f;   // 趴姿修正

    return config;
}

} // namespace M16A4_BulletTrack
} // namespace PeaceElite

#endif // M16A4_CONFIG_H