#include <iostream>
#include "QBUConfig.h"

int main() {
    auto config = PeaceElite::QBU_BulletTrack::GetDefaultQBUConfig();

    // 读取 QBU 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::QBU_BulletTrack::QBU_CoreTrack::Range)];
    std::cout << "QBU tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::QBU_BulletTrack::QBU_BulletCorrect::ADS_Factor)] = 0.7f;

    return 0;
}