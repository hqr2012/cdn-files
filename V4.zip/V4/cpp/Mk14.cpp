#include <iostream>
#include "Mk14Config.h"

int main() {
    auto config = PeaceElite::Mk14_BulletTrack::GetDefaultMk14Config();

    // 读取 Mk14 核心追踪范围
    float range = config.coreTrack[static_cast<size_t>(PeaceElite::Mk14_BulletTrack::Mk14_CoreTrack::Range)];
    std::cout << "Mk14 tracking range: " << range << " meters\n";

    // 动态修改开镜修正因子
    config.bulletCorrect[static_cast<size_t>(PeaceElite::Mk14_BulletTrack::Mk14_BulletCorrect::ADS_Factor)] = 1.0f;

    return 0;
}