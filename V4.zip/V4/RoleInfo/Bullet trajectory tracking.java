{
   "Bullet trajectory tracking hits the head":{
      "Bullet range tracking head"："locking"
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Character Movement Tracking"",":"360°×360°"
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Character Movement Tracking":"360°×360°"
   }